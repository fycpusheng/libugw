
#ifndef UVW_STRING_H
#define UVW_STRING_H

#include "../uvw_tools_export.h"
#include <string.h>


export_uvw_tools int uvw_memcpy_s(void * dst, size_t sizeInBytes, const void * src, size_t count);
export_uvw_tools int uvw_strcpy_s(void * dst, size_t sizeInBytes, const void * src, size_t count);
export_uvw_tools int uvw_sprintf_s(char *dst_ptr, int dst_size, const char *fmt, ...);



#endif
