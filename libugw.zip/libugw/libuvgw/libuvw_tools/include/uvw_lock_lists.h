
#ifndef UVW_LOCK_LIST_H
#define UVW_LOCK_LIST_H

#include <mutex>
#include <list>
#include <plat_support_class.h>


template <typename dtclass>
class uvw_lock_lists
{
public:
    void push_back(dtclass& val)
    {
        m_mutex.lock();
        m_lists.push_back(val);
        m_mutex.unlock();
    }

    void clear()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_lists.clear();
    }

    //每个任务都必须从 DB 池中获取到 DB 指针; 否则就无限制等待;
    //若始终获取不到证明 程序的相关代码逻辑 存在问题!!!
    bool take_header_util_ok(dtclass &dt)
    {
        while(true) {
            if(try_take_header(dt))
                return true;

            plat_support_class::Instance()->sleep_ms(10);
        }
    }

    bool take_header(dtclass &dt)
    {
        return try_take_header(dt);
    }

    int size() {
        std::lock_guard<std::mutex> lk(m_mutex);
        return m_lists.size();
    }

    bool try_take_header(dtclass &dt)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        typename std::list<dtclass>::iterator iter = m_lists.begin();
        if(iter != m_lists.end())
        {
            dt = (*iter);
            m_lists.erase(iter);
            return true;
        }

        return false;
    }

protected:
    std::mutex  m_mutex;
    std::list<dtclass> m_lists;
};

#endif
