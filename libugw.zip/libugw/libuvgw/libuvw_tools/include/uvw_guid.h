
#ifndef UVW_GUID_H
#define UVW_GUID_H

#include <string>
#include "../uvw_tools_export.h"


#endif
