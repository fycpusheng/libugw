#ifndef UVW_LOG_H
#define UVW_LOG_H


#include <string>
#include <cctype>
#include <algorithm>
#include "uvw_file.h"
#include "../uvw_tools_export.h"


class export_uvw_tools uvw_log
{
    enum { lvl_debug = 1, lvl_warning = 2, lvl_critial = 4, lvl_abort = 8 };
public:
    uvw_log();

public:
    void debug_tbuffer(const char *buffer);
    void debug_tlogA(const int level, const char *fmt, ...);
    void debug_tlogA_lv_abort(const char *fmt,  ...);
    void debug_tlogA_lv_debug(const char *fmt, ...);
    void debug_tlogA_lv_warning(const char *fmt,  ...);

public:
    void set_dir(std::string dir) {
        m_dir = dir;
    }
    void set_level(int log_level) {
        m_log_level = log_level;
    }
    void set_to_file(bool bfile) {
        m_to_file = bfile;
    }
    void set_to_tty(bool btty) {
        m_to_tty = btty;
    }
    void set_show_line(bool bline) {
        m_show_line = bline;
    }

protected:
    unsigned int m_log_level;
    std::string  m_dir;
    uvw_file     m_file;
    bool         m_to_file;
    bool         m_to_tty;
    bool         m_show_line;
};


class export_uvw_tools uvw_log_real : public uvw_log
{
public:
    uvw_log_real();

public:
    void start();
    void stop();

private:
    bool m_is_stop;
};




#define  debug_log_lvl_lineA(lvl, format, ...)   {   \
    uvw_log::debug_tlogA(lvl, "file : %s, fun: %s, line : %d", __FILE__, __FUNCTION__, __LINE__);  \
    uvw_log::debug_tlogA(lvl, format, __VA_ARGS__);  }




#endif
