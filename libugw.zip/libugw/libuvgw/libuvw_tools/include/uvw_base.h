#ifndef UVW_BASE_H
#define UVW_BASE_H

#include <string>

class uvw_base
{
public:
    //app had run time !!!
    //get_time  : utc date time;
    //get_now_ms: current app run time;
    static void get_time(long long &utc_ms);
    static long get_now_ms();
    static void ms_sleep(long ms);

public:
    static std::string get_app_pathA();
    static std::string get_app_dirA();
};

#endif
