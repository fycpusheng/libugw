#ifndef UVW_FILE_H
#define UVW_FILE_H

#include <stdio.h>
#include <string>


class uvw_file
{
public:
    uvw_file();
    ~uvw_file() {
        close();
    }

public:
    //r/w/a; b is windows falg
    bool is_open();
    bool open(std::string path, std::string flag);
    int  write(const char *data, int size);
    int  read(char *data, int size);
    void close();

private:
    FILE *m_file;
    std::string m_path;
};

#endif
