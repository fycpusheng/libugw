//#include "uvw_task_pool.h"
//#include "uvw_task_queue.h"
//#include "../include/uvw_crash_tools.h"


//void uvw_task_thread::ms_sleep(long ms)
//{
//    std::chrono::milliseconds dura(ms);
//    std::this_thread::sleep_for(dura);
//}

//void uvw_task_exec()
//{
//    for(int lv=0; lv<UVW_TASK_END; lv++)
//    {
//        uvw_task_queue& task_lists = uvw_task_queue_mgr::Instance()->get_queue(lv);
//        while(task_lists.size()>0)
//        {
//            uvw_task_item *task = task_lists.take_item();
//            if(task)
//            {
//                if(!task->is_cancel())
//                    task->work(0);

//                task->after_work(0);
//                delete task;
//            }
//        }
//    }
//}

//void uvw_task_thread::start()
//{
//    m_bstop = false;
//    m_brunning = true;
//    std::thread([=]()
//    {
//        while(m_brunning)
//        {
//#ifdef Q_OS_WIN
//            __try{
//                uvw_task_exec();
//            }
//            __except(unhandled_exception_filter_tools(GetExceptionInformation()))
//            {
//            }
//#else
//#endif
//            ms_sleep(2);
//        }

//        m_bstop = true;
//    }).detach();
//}


//uvw_task_thread_lists  g_uvw_task_thread_lists;
//uvw_task_thread_lists* uvw_task_thread_lists::Instance()
//{
//    return &g_uvw_task_thread_lists;
//}

//void uvw_task_thread_lists::start(int num)
//{
//    for(int i=0; i<num; i++)
//    {
//        uvw_task_thread *task_trd = new uvw_task_thread;
//        task_trd->start();
//        m_task_thread_lists.push_back(task_trd);
//    }
//}

//void uvw_task_thread_lists::stop()
//{
//    int size = m_task_thread_lists.size();
//    for(int i=0; i<size; i++)
//    {
//        uvw_task_thread *trd = m_task_thread_lists.at(i);
//        trd->stop_til_ok();
//        delete trd;
//    }

//    m_task_thread_lists.clear();
//}
