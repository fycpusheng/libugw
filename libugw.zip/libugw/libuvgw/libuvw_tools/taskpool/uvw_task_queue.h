#ifndef UVW_TASK_QUEUE_H
#define UVW_TASK_QUEUE_H


#include <list>
#include <mutex>
#include <thread>
#include "uvw_task_item.h"
#include "../uvw_tools_export.h"


class export_uvw_tools uvw_task_queue
{
public:
    typedef std::list<uvw_task_item*>  def_task_lists;

public:
    uvw_task_item* take_item();
    void take_all(def_task_lists& lists);
    void push_item(uvw_task_item* item);
    void erase_item(uvw_task_item* item);
    void cancel();

    void clear();
    int  size();

private:
    def_task_lists m_task_lists;
    std::mutex m_mutex;
};

enum  TaskLV{ UVW_TASK_LV1 = 0, UVW_TASK_LV2, UVW_TASK_LV3, UVW_TASK_END };
class export_uvw_tools uvw_task_queue_lv
{
public:
    uvw_task_queue& get_queue_highest() {
        return m_tqueue_lists[UVW_TASK_LV1];
    }

    uvw_task_queue& get_queue_normal() {
        return m_tqueue_lists[UVW_TASK_LV2];
    }

    uvw_task_queue& get_queue_lowest() {
        return m_tqueue_lists[UVW_TASK_LV3];
    }

    uvw_task_queue& get_queue(int lv) {
        return m_tqueue_lists[lv];
    }

private:
    uvw_task_queue m_tqueue_lists[UVW_TASK_END];
};

class export_uvw_tools uvw_task_queue_mgr : public uvw_task_queue_lv
{
public:
    static uvw_task_queue_mgr* Instance();

public:
    uvw_task_queue_mgr() {
        m_is_stop = true;
        m_exec_by_race = false;
    }

public:
    void start(int num);
    void start_by_race(int num);
    void stop();

public:
    typedef std::vector<std::thread*> def_task_thread_lists;

private:
    def_task_thread_lists m_task_thread_lists;
    bool m_is_stop;
    bool m_exec_by_race;
};

#endif
