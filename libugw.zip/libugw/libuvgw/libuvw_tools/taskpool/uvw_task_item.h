#ifndef UVM_TASK_ITEM_H
#define UVM_TASK_ITEM_H

#include <list>
#include <vector>


#define  ull64 unsigned long long


class uvw_task_item
{
public:
    uvw_task_item() {
        m_cancel = false;
    }

    virtual ~uvw_task_item() {}

public:
    virtual void work(void *data) = 0;
    virtual void after_work(void *data) = 0;

    //is_cancel 返回 true, 则work不被调用; 但 after_work 依然调用!!!
public:
    bool is_cancel()  { return m_cancel; }
    void cancel()     { m_cancel = true; }

private:
    bool  m_cancel;
};


#endif
