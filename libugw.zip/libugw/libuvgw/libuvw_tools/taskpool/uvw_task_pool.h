//#ifndef UVM_TASK_THREAD_POOL_H
//#define UVM_TASK_THREAD_POOL_H

//#include <list>
//#include <vector>
//#include <mutex>
//#include <thread>
//#include "uvw_task_queue.h"
//#include "../uvw_tools_export.h"


//class export_uvw_tools uvw_task_thread
//{
//public:
//    uvw_task_thread() {
//    }

//public:
//    void start();
//    void stop()        { m_brunning = false; }
//    bool is_stop_ok()  { return m_bstop; }
//    void stop_til_ok() {
//        while(!m_bstop) ms_sleep(2);
//    }

//public:
//    void ms_sleep(long ms);

//private:
//    bool m_brunning;
//    bool m_bstop;
//};


//class export_uvw_tools uvw_task_thread_lists
//{
//public:
//    static uvw_task_thread_lists* Instance();

//public:
//    void start(int num);
//    void stop();

//public:
//    typedef std::vector<uvw_task_thread*> def_task_thread_lists;

//private:
//    def_task_thread_lists m_task_thread_lists;
//};

//#endif
