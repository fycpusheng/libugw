#include "uvw_task_queue.h"


void uvw_task_queue::push_item(uvw_task_item* item)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    m_task_lists.push_back(item);
}

void uvw_task_queue::erase_item(uvw_task_item* item)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    def_task_lists::iterator iter = m_task_lists.begin();
    while(iter != m_task_lists.end())
    {
        uvw_task_item* task = (*iter);
        if(task == item) {
            m_task_lists.erase(iter);
            return;
        }
        else
            iter++;
    }
}

uvw_task_item* uvw_task_queue::take_item()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    def_task_lists::iterator iter = m_task_lists.begin();
    if(iter != m_task_lists.end())
    {
        uvw_task_item* task = (*iter);
        m_task_lists.erase(iter);
        return task;
    }

    return 0;
}

void uvw_task_queue::take_all(def_task_lists& lists)
{
    std::lock_guard<std::mutex> lk(m_mutex);

    def_task_lists::iterator iter = m_task_lists.begin();
    while(iter != m_task_lists.end())
    {
        uvw_task_item* task = (*iter);
        iter = m_task_lists.erase(iter);
        lists.push_back(task);
    }
}

void uvw_task_queue::cancel()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    def_task_lists::iterator iter = m_task_lists.begin();
    while(iter != m_task_lists.end())
    {
        uvw_task_item* task = (*iter);
        task->cancel();
        iter++;
    }
}

void uvw_task_queue::clear()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    m_task_lists.clear();
}

int uvw_task_queue::size()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    return (int)m_task_lists.size();
}

// ///////////////////////////////////////////////////////////////////////////////////// //
// ///////////////////////////////////////////////////////////////////////////////////// //
// ///////////////////////////////////////////////////////////////////////////////////// //
//
uvw_task_queue_mgr  g_uvw_task_queue_mgr;
uvw_task_queue_mgr* uvw_task_queue_mgr::Instance()
{
    return &g_uvw_task_queue_mgr;
}

static void ms_sleep(long ms)
{
    std::chrono::milliseconds dura(ms);
    std::this_thread::sleep_for(dura);
}


void uvw_task_queue_mgr::start(int num)
{
    m_is_stop = false;
    for(int i=0; i<num; i++)
    {
        std::thread *trd = new std::thread([=]()
        {
            while(!m_is_stop)
            {
                for(int lv=0; lv<UVW_TASK_END; lv++)
                {
                    uvw_task_queue& task_lists = get_queue(lv);
                    while(task_lists.size()>0)
                    {
                        //任务项, 由将任务添加到队列的操作者在 after_work 中执行释放!!!
                        uvw_task_item *task = task_lists.take_item();
                        if(task)
                        {
                            if(!task->is_cancel()) {
                                task->work(0);
                            }

                            //uvw_task_item 可在 after_work 函数中处理自身的释放问题!!!
                            task->after_work(0);
                            //delete task;
                        }

                        //支持任务抢占?? 有更高级任务时, 优先执行更高级任务!!
                        if(m_exec_by_race)
                        {
                            bool has_higher = false;
                            for(int j=0; j<lv; j++)
                            {
                                uvw_task_queue& tlists = get_queue(j);
                                if(tlists.size()>0) {
                                    has_higher = true;
                                    break;
                                }
                            }

                            if(has_higher)
                                break;
                        }
                    }
                }

                ms_sleep(1);
            }
        });

        m_task_thread_lists.push_back(trd);
    }
}

void uvw_task_queue_mgr::start_by_race(int num)
{
    m_exec_by_race = true;
    start(num);
}

void uvw_task_queue_mgr::stop()
{
    m_is_stop = true;
    for(def_task_thread_lists::iterator iter = m_task_thread_lists.begin(); iter != m_task_thread_lists.end(); iter++)
    {
        std::thread *trd = (*iter);
        trd->join();
        delete trd;
    }

    m_task_thread_lists.clear();
}
