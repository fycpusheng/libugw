
#include <uvw_string.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <stdio.h>


int uvw_memcpy_s(void * dst, size_t sizeInBytes, const void * src, size_t count)
{
    if(count == 0)
    {
        /* nothing to do */
        return 0;
    }

    if(src == 0)
        return EINVAL;

    if(sizeInBytes < count)
    {
        /* zeroes the destination buffer */
        //memset(dst, 0, sizeInBytes); //msvc
        /* here is mycode */
        *(char *)dst = 0;
        return ERANGE;
    }

    memcpy(dst, src, count);
    return 0;
}

//return bytes was copy
int uvw_strcpy_s(void * dst, size_t sizeInBytes, const void * src, size_t count)
{
    if(sizeInBytes <= count)
        count = sizeInBytes-1;

    memcpy(dst, src, count);
    char *dst_ptr = (char*)(dst);
    dst_ptr[count] = 0;

    return count;
}

int uvw_sprintf_s(char *dst_ptr, int dst_size, const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    int need_sz = vsnprintf(0, 0, fmt, args);
    if(need_sz >= dst_size)
    {
        char *buffer = new char[need_sz+2];
        int rc2 = vsprintf(buffer, fmt, args);
        if(rc2>0)
        {
            uvw_memcpy_s(dst_ptr, dst_size-1, buffer, rc2);
        }
        delete []buffer;

        va_end(args);
        return rc2;
    }

    int rc2 = vsprintf(dst_ptr, fmt, args);
    va_end(args);
    return rc2;
}

