#include "uvw_file.h"


uvw_file::uvw_file()
{
    m_file = 0;
}

bool uvw_file::is_open()
{
    return (m_file!=0);
}

bool uvw_file::open(std::string path, std::string flag)
{
    m_file = fopen(path.c_str(), flag.c_str());
    if(m_file != 0)
        m_path = path;

    return (m_file != 0);
}

int  uvw_file::write(const char* data, int size)
{
    return fwrite(data, 1, size, m_file);
}

int  uvw_file::read(char *data, int size)
{
    if(m_file)
        return fread(data, 1, size, m_file);

    return 0;
}

void uvw_file::close()
{
    if(m_file) {
        fclose(m_file);
        m_file = 0;
    }
}
