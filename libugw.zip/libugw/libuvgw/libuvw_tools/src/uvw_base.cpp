#include "uvw_base.h"
#include "time.h"
#include <locale.h>
#include <thread>

#ifdef Q_OS_WIN
#include "windows/uvw_base.hcc"
#else
#include "unix/uvw_base.hcc"
#endif


void uvw_base::get_time(long long &utc_ms)
{
    utc_ms = time(0);
}

long uvw_base::get_now_ms()
{
    long tick_per_ms = CLOCKS_PER_SEC/1000;
    clock_t cur_tms = clock()/tick_per_ms;
    return cur_tms;
}

void uvw_base::ms_sleep(long ms)
{
    std::chrono::milliseconds dura(ms);
    std::this_thread::sleep_for(dura);
}
