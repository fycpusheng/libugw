
#include "uvw_config.h"


using namespace std;
uvw_config::uvw_config( string filename, string delimiter, string comment )
               : m_Delimiter(delimiter), m_Comment(comment)
{
    // Construct a Config, getting keys and values from given file
    std::ifstream in( filename.c_str() );
    if( !in ) throw File_not_found( filename );
    in >> (*this);
}


uvw_config::uvw_config() : m_Delimiter( string(1,'=') ), m_Comment( string(1,'#') )
{
    // Construct a Config without a file; empty
}


bool uvw_config::KeyExists( const string& key ) const
{
    // Indicate whether key is found
    mapci p = m_Contents.find( key );
    return ( p != m_Contents.end() );
}


/* static */
void uvw_config::Trim( string& inout_s )
{
    // Remove leading and trailing whitespace
    static const char whitespace[] = " \n\t\v\r\f";
    inout_s.erase( 0, inout_s.find_first_not_of(whitespace) );
    inout_s.erase( inout_s.find_last_not_of(whitespace) + 1U );
}


std::ostream& operator<<( std::ostream& os, const uvw_config& cf )
{
    // Save a Config to os
    for( uvw_config::mapci p = cf.m_Contents.begin();
        p != cf.m_Contents.end(); ++p )
    {
        os << p->first << " " << cf.m_Delimiter << " ";
        os << p->second << std::endl;
    }
    return os;
}

void uvw_config::Remove( const string& key )
{
    // Remove key and its value
    m_Contents.erase( m_Contents.find( key ) );
    return;
}

std::istream& operator>>( std::istream& is, uvw_config& cf )
{
    // Load a Config from is
    // Read in keys and values, keeping internal whitespace
    typedef string::size_type pos;
    const string& delim  = cf.m_Delimiter;  // separator
    const string& comm   = cf.m_Comment;    // comment
    const pos skip = delim.length();        // length of separator

    string nextline = "";  // might need to read ahead to see where value ends

    while( is || nextline.length() > 0 )
    {
        // Read an entire line at a time
        string line;
        if( nextline.length() > 0 )
        {
            line = nextline;  // we read ahead; use it now
            nextline = "";
        }
        else
        {
            std::getline( is, line );
        }

        // Ignore comments
        line = line.substr( 0, line.find(comm) );

        // Parse the line if it contains a delimiter
        pos delimPos = line.find( delim );
        if( delimPos != string::npos )
        {
            // Extract the key
            string key = line.substr( 0, delimPos );
            line.replace( 0, delimPos+skip, "" );

            // See if value continues on the next line
            // Stop at blank line, next line with a key, end of stream,
            // or end of file sentry
            bool terminate = false;
            while( !terminate && is )
            {
                std::getline( is, nextline );
                terminate = true;

                //Remove comments!
                nextline = nextline.substr( 0, nextline.find(comm) );
                if( nextline.find(delim) != string::npos )
                    continue;

                //Is null line?
                string nlcopy = nextline;
                uvw_config::Trim(nlcopy);
                if( nlcopy == "" ) continue;

                //上一行的值延续到本行, 其首尾空格进行移除!
                //Is value? go down to this line!
                //Remove the blank space for continuous line!
                line += "\n";
                line += nlcopy;
                terminate = false;
            }

            // Store key and value
            uvw_config::Trim(key);
            uvw_config::Trim(line);
            cf.m_Contents[key] = line;  // overwrites if key is repeated
        }
    }

    return is;
}

bool uvw_config::FileExist(std::string filename)
{
    bool exist= false;
    std::ifstream in( filename.c_str() );
    if(in)
        exist = true;

    return exist;
}

void uvw_config::ReadFile( string filename, string delimiter, string comment )
{
    m_Delimiter = delimiter;
    m_Comment = comment;
    std::ifstream in( filename.c_str() );

    if( !in ) throw File_not_found( filename );

    in >> (*this);
}


#if 0
void main(int argc, char *argv)
{
    int port;
    std::string ipAddress;
    std::string username;
    std::string password;
    const char ConfigFile[]= "config.txt";
    uvw_config configSettings(ConfigFile);

    port = configSettings.Read("port", 0);
    ipAddress = configSettings.Read("ipAddress", ipAddress);
    username = configSettings.Read("username", username);
    password = configSettings.Read("password", password);
    std::cout<<"port:"<<port<<std::endl;
    std::cout<<"ipAddress:"<<ipAddress<<std::endl;
    std::cout<<"username:"<<username<<std::endl;
    std::cout<<"password:"<<password<<std::endl;
    //
    double level = configSettings.Read("level", level);
    std::cout<<"level:"<<level<<std::endl;
}
#endif
