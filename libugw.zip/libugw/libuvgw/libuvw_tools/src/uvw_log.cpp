#include "uvw_log.h"
#include <stdio.h>
#include <time.h>
#include <thread>
#include <stdarg.h>
#include "uvw_config.h"
#include "uvw_base.h"
//for linux
#include "string.h"


#ifdef Q_OS_WIN
#define tty_printf   printf
#else
#define tty_printf   printf
#endif

uvw_log::uvw_log()
{
    m_log_level = uvw_log::lvl_debug;
    m_dir = "./";
    m_to_tty = true;
    m_to_file = false;
}

void uvw_log::debug_tbuffer(const char* buffer)
{
    char lcache[1200] = {0};
    if(m_show_line) {
        sprintf(lcache, "file : %s, fun: %s, line : %d", __FILE__, __FUNCTION__, __LINE__);
    }

    if(m_to_tty)
    {
        tty_printf(lcache);
        tty_printf(buffer);
        tty_printf("\r\n");
    }

    if(m_to_file)
    {
        if(!m_file.is_open())
        {
            char name[20];
            sprintf(name, "%08lX", uvw_base::get_now_ms());

            std::string fpath = m_dir + "/" + std::string(name) + ".log";
            m_file.open(fpath.c_str(), "aw");
        }

        if(m_file.is_open())
        {
            m_file.write(lcache, strlen(lcache));
            m_file.write(buffer, strlen(buffer));
            m_file.write("\r\n", 2);
        }
    }
}

void uvw_log::debug_tlogA(const int level, const char *fmt, ...)
{
    if((m_log_level & level) == 0)
        return;

    va_list args;
    va_start(args, fmt);
    char buf[3500];
    int rc2 = vsprintf(buf, fmt, args);
    va_end(args);

    if(rc2 > 0)
        debug_tbuffer(buf);
    else
        debug_tbuffer("string too long");
}


void uvw_log::debug_tlogA_lv_abort(const char *fmt,  ...)
{
    if((m_log_level & uvw_log::lvl_abort) == 0)
        return;

    va_list args;
    va_start(args, fmt);
    char buf[3500];
    int rc2 = vsprintf(buf, fmt, args);
    va_end(args);

    if(rc2 > 0)
        debug_tbuffer(buf);
    else
        debug_tbuffer("string too long");
}

void uvw_log::debug_tlogA_lv_debug(const char *fmt,  ...)
{
    if((m_log_level & uvw_log::lvl_debug) == 0)
        return;

    va_list args;
    va_start(args, fmt);
    char buf[3500];
    int rc2 = vsprintf(buf, fmt, args);
    va_end(args);

    if(rc2 > 0)
        debug_tbuffer(buf);
    else
        debug_tbuffer("string too long");
}

void uvw_log::debug_tlogA_lv_warning(const char *fmt, ...)
{
    if((m_log_level & uvw_log::lvl_warning) == 0)
        return;

    va_list args;
    va_start(args, fmt);
    char buf[3500];
    int rc2 = vsprintf(buf, fmt, args);
    va_end(args);

    if(rc2 > 0)
        debug_tbuffer(buf);
    else
        debug_tbuffer("string too long");
}

// ///////////////////////////////////////////////////////////////////////////////// //
// ///////////////////////////////////////////////////////////////////////////////// //
//
uvw_log_real::uvw_log_real()
{
    m_is_stop = true;
}

void uvw_log_real::start()
{
    m_is_stop = false;
    std::thread([=](){
        while(!m_is_stop)
        {
            const char ConfigFile[]= "./../conf/print.ini";
            uvw_config configSettings(ConfigFile);

            std::string to_tty  = configSettings.Read("to_tty",    std::string("true"));
            std::string to_file = configSettings.Read("to_file",   std::string("true"));
            std::string to_lv   = configSettings.Read("to_lv",     std::string("3"));
            std::string sh_line = configSettings.Read("show_line", std::string("true"));

            if(to_tty == "true") {
                set_to_tty(true);
            }

            if(to_file == "true") {
                set_to_file(true);
            }

            if(sh_line == "true") {
                set_show_line(true);
            }

            set_level(std::stoi(to_lv));

            for(int i=0; i<500; i++) {
                uvw_base::ms_sleep(10);
                if(m_is_stop) break;
            }
        }
    }).detach();
}

void uvw_log_real::stop()
{

}
