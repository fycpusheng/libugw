
#ifndef UVW_TOOLS_EXPORT_H
#define UVW_TOOLS_EXPORT_H


#ifdef _WIN32
  /* Windows - set up dll import/export decorators. */
# if defined(BUILDING_UVW_TOOLS_SHARED)
    /* Building shared library. */
#   define export_uvw_tools __declspec(dllexport)
# elif defined(USING_UVW_TOOLS_SHARED)
    /* Using shared library. */
#   define export_uvw_tools __declspec(dllimport)
# else
    /* Building static library. */
#   define export_uvw_tools /* nothing */
# endif

#elif __GNUC__ >= 4
# define export_uvw_tools __attribute__((visibility("default")))
#else
# define export_uvw_tools /* nothing */
#endif


#endif
