
#ifndef  _UVM_NOTIFY_MGR_H_
#define  _UVM_NOTIFY_MGR_H_

#include <list>
#include <mutex>
#include <uvw.h>



class uvw_notify_cb;
class UVW_EXTERN uvw_notify_cb_lists
{
public:
    uvw_notify_cb_lists() {
    }

public:
    void push_item(uvw_notify_cb* cb)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_notify_cb_mgr.push_back(cb);
    }

    void free();

private:
    std::mutex m_mutex;
    std::list<uvw_notify_cb*> m_notify_cb_mgr;
};



//uvw_notify_cb_mgr:
//用来释放, socket 被关闭时的回调类(uvw_notify_cb)
class uvw_notify_cb;
class UVW_EXTERN uvw_notify_cb_mgr : public uvw_notify_cb_lists
{
public:
    uvw_notify_cb_mgr() {
        m_bquit = false;
    }

public:
    static uvw_notify_cb_mgr* Instance();

public:
    //start freee thread, cb will free if uvw_notify_cb::is_can_free return true;
    void start_free();
    void stop_free() { m_bquit = true; }

private:
    bool m_bquit;
};

#endif
