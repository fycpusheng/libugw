
#ifndef  _UVM_CRASH_CORE_H_
#define  _UVM_CRASH_CORE_H_

#ifdef _WIN32
#include <Windows.h>
#include <DbgHelp.h>
#pragma comment(lib, "DbgHelp")
long unhandled_exception_filter(EXCEPTION_POINTERS *pException)
{
    //创建 Dump 文件
    TCHAR path[MAX_PATH];
    GetModuleFileName(NULL, path, MAX_PATH);
    //(wcsrchr(path, TEXT('\\')))[1] = 0; // 删除文件名，只获得路径字串..
    wcscat(path, TEXT("__crash_exe.dmp"));


    HANDLE hDumpFile = CreateFile(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if( hDumpFile != INVALID_HANDLE_VALUE)
    {
        MINIDUMP_EXCEPTION_INFORMATION dumpInfo;
        dumpInfo.ExceptionPointers = pException;
        dumpInfo.ThreadId = GetCurrentThreadId();
        dumpInfo.ClientPointers = TRUE;

        if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hDumpFile, MiniDumpNormal, &dumpInfo, NULL, NULL))
        {
        }
        else
        {
            DWORD err = GetLastError();
        }

        CloseHandle(hDumpFile);
    }
    else
    {
        DWORD err = GetLastError();
    }

    return EXCEPTION_EXECUTE_HANDLER;
}
#else
#endif

#endif
