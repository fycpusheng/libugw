
#ifndef  _UVM_TCP_INSTANCE_H_
#define  _UVM_TCP_INSTANCE_H_

#include <stdio.h>
#include <uv.h>
#include <uvw.h>
#include <unordered_map>
#include <mutex>
#include "uvw_timer.h"
#include "stdx/uvw_list_t.h"


class uvw_notify_cb;
class UVW_EXTERN uvw_tcp_instance final : public uvw_timer_heartbeat
{
    friend class uvw_tcp_svr;

public:
    uvw_tcp_instance(uv_loop_t *loop_t);

    //Inheritance is not allowed
    ~uvw_tcp_instance();

private:
    //init 应尽可能的仅初始化数据, 而不触发事件!!
    void init(uv_loop_t *loop_t);

public:
    uv_tcp_t *get_instance() { return m_instance; }

public:
    void set_notify_cb(uvw_notify_cb* cb) { m_notify_cb = cb; }

public:
    //read_start/heartbeat 应当在同一个 loop!
    //heartbeat : 启动心跳事件!
    void heartbeat();
    void read_start();

public:
    //write_if_has_data:
    //uvw_loop_async::async_send will call it
    bool write_if_has_data();

    //-- write_buffer 负责释放, 传递进来的数据, 传递者不能再使用/释放此数据//
    bool write_buffer(char* data, int size); //will exclusive to data
    bool write_buffer(std::string str);      //will copy str memory

    void close();
    void shutdown();
    bool is_close() {
        return m_can_close && (!m_is_writing);
    }

private:
    bool write_to_uv(char* data, int size); //will exclusive to data

public:
    virtual void timer_cb();

private:
    uv_tcp_t*      m_instance;
    uvw_notify_cb* m_notify_cb;
    bool           m_can_close;
    bool           m_is_writing;
};


class uvw_tcp_instance_lists : public uvw_list_t<uvw_tcp_instance*>
{
public:
    bool async_send()
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        bool has_write = false;
        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_instance *to_client = (*iter);
            if(to_client)
            {
                bool has_wr = to_client->write_if_has_data();
                if(has_wr && (!has_write))
                    has_write = true;
            }

            iter++;
        }

        return has_write;
    }

    void async_read_start()
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_instance *to_client = (*iter);
            if(to_client) {
                to_client->heartbeat();
                to_client->read_start();
            }

            iter++;
        }

        m_tlists.clear();
    }

    void erase_invalid_instance()
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_instance *to_client = (*iter);
            if(to_client && to_client->is_close())
            {
                delete to_client;
                iter = m_tlists.erase(iter);
            }
            else
                iter++;
        }
    }

};



#endif
