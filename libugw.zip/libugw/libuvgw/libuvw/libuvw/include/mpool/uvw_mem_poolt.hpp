﻿#ifndef MEMORY_POOLT_H
#define MEMORY_POOLT_H

#include <unordered_map>
#include <queue>
#include <atomic>
#include <memory>


//-- -------------------------------------------------------- --//
//-- ********** 内存池的模板类实现, 用于单线程中.   ************
//-- -------------------------------------------------------- --//
//-- VAR_SIZE : 一个变量块的大小.
//-- INIT_NUM : 初始化时分配多少个变量块.
//-- 注意: 每个子内存池的大小为　VAR_SIZE*INIT_NUM.
//--
//-- memory_pool 包含多个小池, 小池的对象块是一次性分配的, 可以对小池进行释放;
//-- 注: 分成小池 可以对 内存块 进行更好的分配释放 !!
//-- -------------------------------------------------------- --//

namespace uvwpool {

template<int VAR_SIZE, std::size_t INIT_NUM>
class memory_pool
{
public:
    //子内存池类//
    template<int VAR_SIZE, std::size_t INIT_NUM>
    class pool_item
    {
    public:
        pool_item()  { init(); }
        ~pool_item() { fini(); }

    public:
        void* get_element()
        {
            if(m_free_lists.size()>0)
            {
                void* t1 = m_free_lists.front();
                m_free_lists.pop();
                return t1;
            }

            return 0;
        }

        void free_element(void* t1)
        {
            m_free_lists.push(t1);
        }

        bool is_can_free()
        {
            return (m_free_lists.size() == INIT_NUM);
        }

        bool is_range(void *addr)
        {
            char *end_ptr = (char*)m_mem_ptr + VAR_SIZE*INIT_NUM;
            return ((m_mem_ptr<=addr) && (addr<end_ptr));
        }

        long var_size() { return VAR_SIZE; }

    private:
        void init()
        {
            m_mem_ptr = (void*)malloc(VAR_SIZE*INIT_NUM);

            char* t1 = (char*)m_mem_ptr;
            for (size_t i=0; i<INIT_NUM; i++)
            {
                t1 += VAR_SIZE;
                m_free_lists.push(t1);
            }
        }

        void fini()
        {
            if (m_mem_ptr)
            {
                free(m_mem_ptr);
                m_mem_ptr = 0;
            }

            m_free_lists = memory_map_lists();
        }

    protected:
        typedef std::queue<void*> memory_map_lists;

    protected:
        memory_map_lists m_free_lists;
        void *m_mem_ptr;
    };

public:
    memory_pool() {
        m_free_cnt = 0;
        m_pool_lists.push_back(new pool_item_t);
    }

    void* get_element()
    {
        m_free_cnt--;

        void *ret_ptr = 0;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item)
            {
                ret_ptr = item->get_element();
                if(ret_ptr) break;
            }
            iter++;
        }

        if(!ret_ptr)
        {
            pool_item_t *new_ptr = new pool_item_t;
            m_pool_lists.push_back(new_ptr);
            ret_ptr = new_ptr->get_element();
        }

        return ret_ptr;
    }

    bool free_element(void* t1)
    {
        bool ret = false;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item && item->is_range(t1))
            {
                ret = true;
                item->free_element(t1);
                break;
            }
            iter++;
        }

        //释放指定次数后判断是否有多余的子内存池可以释放//
        m_free_cnt++;
        if(m_free_cnt > INIT_NUM*3)
            free_pool_item_if_idle();

        return ret;
    }

    void free_pool_item_if_idle()
    {
        //仅保留3个空闲的子内存池//
        int size = m_pool_lists.size();
        if(size <= 3)
            return;

        int call_free_num = size - 3;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item && item->is_can_free())
            {
                iter = m_pool_lists.erase(iter);
                m_free_cnt -= INIT_NUM;
                delete item;

                call_free_num--;
                if(call_free_num <= 0)
                    break;
            }
            else {
                iter++;
            }
        }
    }

    bool is_can_free()
    {
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(!item->is_can_free())
                return false;
            iter++;
        }

        return true;
    }

public:
    typedef pool_item<VAR_SIZE, INIT_NUM> pool_item_t;
    typedef std::list<pool_item_t*>       item_lists;

private:
    item_lists m_pool_lists;
    long       m_free_cnt;
};


template<typename TOBJ, std::size_t INIT_NUM>
class object_pool
{
    TOBJ* get_element()
    {
        void *ptr = m_obj_pool.get_element();
        return new TOBJ(ptr);
    }

    void free_element(TOBJ* t1)
    {
        t1->~TOBJ();
        m_obj_pool.free_element((void*)(t1));
    }

public:
    typedef memory_pool<sizeof(TOBJ), INIT_NUM>  mobj_pool;

private:
    mobj_pool  m_obj_pool;
};

}


#endif

