#ifndef MEMORY_POOL_H
#define MEMORY_POOL_H


#include "uvw_mem_poolv.hpp"

namespace uvwpool
{
class memory_pool_lists
{
public:
    memory_pool_lists(){}

public:
    void init_pool()
    {
        //对象大小最大不超过4KB; 否则将向系统申请内存//
        new_pool(0x0020, 20000);
        new_pool(0x0040, 10000);
        new_pool(0x0080, 5000);
        new_pool(0x0100, 5000);
        new_pool(0x0200, 2500);
        new_pool(0x0400, 2500);
        new_pool(0x0800, 2500);
        new_pool(0x1000, 1200);
    }

public:
    void* new_pool(int var_size, int init_num)
    {
        void* pool = new memory_pool(var_size, init_num);
        m_pool_lists.push_back(pool);
        return pool;
    }

    //必须没有任何内存块被使用才能保证释放成功//
    void try_delete_pool(void* pool)
    {
        mpool_tlists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            if(*iter == pool)
            {
                memory_pool* mpool = (memory_pool*)(pool);
                if(mpool->is_can_free())
                {
                    m_pool_lists.erase(iter);
                    delete mpool;
                }
                break;
            }
            iter++;
        }
    }

    void* get_element(int var_size)
    {
        //必定成功分配//
        memory_pool* mpool = (memory_pool*)(get_pool(var_size));
        if(mpool)
            return mpool->get_element();

        return malloc(var_size);
    }

    void free_element(void *ptr)
    {
        mpool_tlists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            memory_pool* mpool = (memory_pool*)(*iter);
            if(mpool && mpool->free_element(ptr))
            {
                return;
            }
            iter++;
        }

        //不是我们分配的?? 那就用系统函数直接free//
        free(ptr);
    }

    void *get_pool(int var_size)
    {
        mpool_tlists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            memory_pool* mpool = (memory_pool*)(*iter);
            if(mpool)
            {
                if(mpool->var_size() >= var_size)
                {
                    return mpool;
                }
            }

            iter++;
        }

        return 0;
    }

public:
    typedef std::list<void*> mpool_tlists;

private:
    mpool_tlists m_pool_lists;
};


// ////////////////////////////////////////////////////////////////////////////////////////// //
// object_pool_safe_mgr:
// ////////////////////////////////////////////////////////////////////////////////////////// //
// 注意:
// -- 建议在稳定运行的线程中使用多线程内存池, 运行时间较短的线程, 不建议使用内存池;
// -- 因为线程终止, 其关联内存池需要释放; 释放将会导致内存池效率降低 //
// ////////////////////////////////////////////////////////////////////////////////////////// //
template<typename pool_lists>
class memory_pool_safe_mgr
{
public:
    memory_pool_safe_mgr(){
    }
    ~memory_pool_safe_mgr() { }

    pool_lists* find_pool(pool_thread_id id)
    {
        pool_lists_ptr iptr = 0;
        map_pool_tlists::iterator iter = m_pool_lists.find(id);
        if(iter != m_pool_lists.end())
        {
            iptr = (iter->second);
        }

        if(!iptr)
        {
            iptr = new pool_lists;
            iptr->init_pool();
            m_pool_lists[id] = iptr;
        }

        return iptr;
    }

    template<typename TOBJ>
    TOBJ* get_element_t()
    {
        void* ptr = get_element(sizeof(TOBJ));
        return new (ptr)TOBJ();
    }

    template<typename TOBJ>
    void free_element_t(TOBJ* tobj)
    {
        tobj->~TOBJ();
        free_element(tobj);
    }

    void* get_element(int el_size)
    {
        pool_thread_id cur_id = pool_get_thread_id();
        pool_lists_ptr ptr = find_pool(cur_id);
        return ptr->get_element(el_size);
    }

    void free_element(void* tobj)
    {
        pool_thread_id cur_id = pool_get_thread_id();
        pool_lists_ptr ptr = find_pool(cur_id);
        ptr->free_element(tobj);
    }

protected:
    typedef pool_lists*  pool_lists_ptr;

protected:
    //if(!std::atomic_exchange(&m_new_item, true));
    typedef std::unordered_map<pool_thread_id, pool_lists_ptr> map_pool_tlists;
    map_pool_tlists  m_pool_lists;
};


//固定内存池, 仅支持变量大小固定的跨线程分配//
template<typename FIXED_POOL, typename TOBJ, int TOBJ_NUM>
class memory_pool_safe_mgr_fixed
{
public:
    memory_pool_safe_mgr_fixed() {
    }
    ~memory_pool_safe_mgr_fixed() {
    }

public:
    FIXED_POOL* find_pool(pool_thread_id id)
    {
        fixed_pool_ptr iptr = 0;
        map_pool_tlists::iterator iter = m_pool_lists.find(id);
        if(iter != m_pool_lists.end())
        {
            iptr = (iter->second);
        }

        if(!iptr)
        {
            iptr = new FIXED_POOL(sizeof(TOBJ), TOBJ_NUM);
            m_pool_lists[id] = iptr;
        }

        return iptr;
    }

    TOBJ* get_element()
    {
        pool_thread_id cur_id = pool_get_thread_id();
        fixed_pool_ptr pool_ptr = find_pool(cur_id);
        void* ptr = pool_ptr->get_element();
        if(ptr)
            return new (ptr)TOBJ();

        return new TOBJ();
    }

    void free_element(TOBJ* tobj)
    {
        tobj->~TOBJ();
        pool_thread_id cur_id = pool_get_thread_id();
        fixed_pool_ptr ptr = find_pool(cur_id);
        if(!ptr->free_element(tobj))
            delete tobj;
    }

protected:
    typedef FIXED_POOL*  fixed_pool_ptr;

protected:
    //if(!std::atomic_exchange(&m_new_item, true));
    typedef std::unordered_map<pool_thread_id, fixed_pool_ptr> map_pool_tlists;
    map_pool_tlists  m_pool_lists;
};
}


#if 0
class testclass
{
    public:
    int a, b;
    int c, d;
};

using namespace uvwpool;

typedef memory_pool_safe_mgr<memory_pool_lists> obj_pool_lists;
obj_pool_lists thread_pool_lists;

typedef memory_pool_safe_mgr_fixed<memory_pool, int, 1000>  obj_pool_mrg;
obj_pool_mrg   obj_pool_mgr;

void test()
{
    thread_pool_lists.get_element(52);
    thread_pool_lists.get_element_t<std::string>();

    obj_pool_mgr.get_element();
}
#endif

#endif

