#ifndef MEMORY_POOL_REAL_H
#define MEMORY_POOL_REAL_H

#include <unordered_map>
#include <queue>
#include <atomic>
#include <memory>

//-- uvw_mem_poolv.hpp/uvw_mem_poolt.hpp
//-- 为模块类与非模块类的关系, 实现是一样的!!
//
//#include "uvw_mem_poolt.hpp"
#include "uvw_mem_poolv.hpp"
#include <mutex>


namespace uvwpool {

class object_pool_bytes
{
public:
    void* get_element(int need_size)
    {
        void *ptr = 0;
        if(need_size < 3*1024*1024)
            ptr = m_obj_pool_3M_lists.get_element();
        else if(need_size < 5*1024*1024)
            ptr = m_obj_pool_5M_lists.get_element();

        return ptr;
    }

    void free_element(void* t1)
    {
        if(m_obj_pool_3M_lists.free_element((void*)(t1)))
            return;

        m_obj_pool_5M_lists.free_element(t1);
    }

    object_pool_bytes() {
        m_obj_pool_3M_lists.init(3*1024*1024, 50);
        m_obj_pool_5M_lists.init(5*1024*1024, 30);
    }

public:
    typedef memory_pool  mobj_pool;

private:
    mobj_pool  m_obj_pool_3M_lists;
    mobj_pool  m_obj_pool_5M_lists;
};
}



#endif

