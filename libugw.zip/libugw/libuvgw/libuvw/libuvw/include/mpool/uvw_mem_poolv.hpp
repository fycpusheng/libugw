#ifndef MEMORY_POOL_V_H
#define MEMORY_POOL_V_H

#include <unordered_map>
#include <queue>
#include <atomic>
#include <memory>

//-- uvw_mem_poolv.hpp/uvw_mem_poolt.hpp
//-- 为模块类与非模块类的关系, 实现是一样的!!
//
//-- -------------------------------------------------------- --//
//-- ********** 内存池的变量类实现, 用于单/多线程中.   ************
//-- -------------------------------------------------------- --//
//-- m_obj_size : 一个变量块的大小.
//-- m_obj_num  : 初始化时分配多少个变量块.
//-- 注意: 每个子内存池的byte值为　m_obj_size*m_obj_num.
//-- -------------------------------------------------------- --//
namespace uvwpool {

class memory_pool
{
public:
    //子内存池类;  m_vsize: 变量占内存大小; m_vnum: 变量个数//
    class pool_item
    {
    private:
        pool_item() {}

    public:
        pool_item(int obj_size, int obj_num)
        {
            m_vsize = obj_size;
            m_vnum  = obj_num;
            init();
        }

        ~pool_item() { fini(); }

    public:
        void* get_element()
        {
            if(m_free_lists.size()>0)
            {
                void* t1 = m_free_lists.front();
                m_free_lists.pop();
                return t1;
            }

            return 0;
        }

        void free_element(void* t1)
        {
            m_free_lists.push(t1);
        }

        bool is_can_free()
        {
            return (m_free_lists.size() == m_vnum);
        }

        bool is_range(void *addr)
        {
            char *end_ptr = (char*)m_mem_ptr + m_vsize*m_vnum;
            return ((m_mem_ptr<=addr) && (addr<end_ptr));
        }

    private:
        void init()
        {
            m_mem_ptr = (void*)malloc(m_vsize*m_vnum);

            char* t1 = (char*)m_mem_ptr;
            for (size_t i=0; i<m_vnum; i++)
            {
                t1 += m_vsize;
                m_free_lists.push(t1);
            }
        }

        void fini()
        {
            if (m_mem_ptr)
            {
                free(m_mem_ptr);
                m_mem_ptr = 0;
            }

            m_free_lists = memory_map_lists();
        }

    protected:
        typedef std::queue<void*> memory_map_lists;

    protected:
        memory_map_lists m_free_lists;
        void *m_mem_ptr;
        long  m_vsize;
        long  m_vnum;
    };

public:
    memory_pool() {}

public:
    memory_pool(int obj_size, int obj_num)
    {
        init(obj_size, obj_num);
    }

    void init(int obj_size, int obj_num)
    {
        s_obj_size = obj_size;
        s_obj_num_for_pool  = obj_num;

        m_free_cnt  = 0;
        m_pool_lists.push_back(new pool_item_t(obj_size, obj_num));
    }

    void* get_element()
    {
        m_free_cnt--;

        void *ret_ptr = 0;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item)
            {
                ret_ptr = item->get_element();
                if(ret_ptr) break;
            }
            iter++;
        }

        if(!ret_ptr)
        {
            pool_item_t *new_ptr = new pool_item_t(s_obj_size, s_obj_num_for_pool);
            m_pool_lists.push_back(new_ptr);
            ret_ptr = new_ptr->get_element();
        }

        return ret_ptr;
    }

    bool free_element(void* t1)
    {
        bool ret = false;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item && item->is_range(t1))
            {
                ret = true;
                item->free_element(t1);
                break;
            }
            iter++;
        }

        //释放指定次数后判断是否有多余的子内存池可以释放//
        m_free_cnt++;
        if(m_free_cnt > s_obj_num_for_pool*3)
            free_pool_item_if_idle();

        return ret;
    }

    void free_pool_item_if_idle()
    {
        //仅保留3个空闲的子内存池//
        int size = m_pool_lists.size();
        if(size <= 3)
            return;

        int call_free_num = size - 3;
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(item && item->is_can_free())
            {
                iter = m_pool_lists.erase(iter);
                m_free_cnt -= elem_size();
                delete item;

                call_free_num--;
                if(call_free_num <= 0)
                    break;
            }
            else {
                iter++;
            }
        }
    }

    bool is_can_free()
    {
        item_lists::iterator iter = m_pool_lists.begin();
        while(iter != m_pool_lists.end())
        {
            pool_item_t* item = (pool_item_t*)(*iter);
            if(!item->is_can_free())
                return false;
            iter++;
        }

        return true;
    }

    bool has_pool() {
        return m_pool_lists.size() > 0;
    }

    //-- 返回变量块大小 --//
    long var_size()  { return s_obj_size; }
    int  elem_size() {
        return s_obj_num_for_pool;
    }

public:
    typedef pool_item pool_item_t;
    typedef std::list<pool_item_t*> item_lists;

private:
    item_lists m_pool_lists;
    long       m_free_cnt;

    //s_obj_size: 子池中每个对象块的大小;
    //s_obj_num_for_pool: 每个子池中有多少对象; 各个子池的对象数量是一致的!!
    long       s_obj_size;
    long       s_obj_num_for_pool;
};



template<typename TOBJ, std::size_t INIT_NUM>
class object_pool
{
public:
    TOBJ* get_element()
    {
        void *ptr = m_obj_pool.get_element();
        return new (ptr)TOBJ();
    }

    bool free_element(TOBJ* t1)
    {
        t1->~TOBJ();
        return m_obj_pool.free_element((void*)(t1));
    }

    object_pool() : m_obj_pool(sizeof(TOBJ), INIT_NUM) { }

public:
    typedef memory_pool  mobj_pool;

private:
    mobj_pool  m_obj_pool;
};

}

/*
void testobj()
{
    object_pool<int, 100> aa;
    aa.get_element();
}
*/


#endif

