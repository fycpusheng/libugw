
#ifndef  _UVM_DEF_H_
#define  _UVM_DEF_H_


#define  UVW_TIMER_START_MS       15000
#define  UVW_TIMER_REPEAT_MS      50*1000


#endif
