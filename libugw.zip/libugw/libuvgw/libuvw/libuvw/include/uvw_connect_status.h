
#ifndef  _UVM_CONNECT_STATUS_H_
#define  _UVM_CONNECT_STATUS_H_

struct uvw_connect_status
{
public:
    uvw_connect_status() {
        status = 0;
    }

private:
    int status;

public:
    //1: connect ing;
    void set_ing() {
        status = 0;
    }

    //<0 is fail
    void set_error() {
        status = -1;
    }

    //>0 is ok
    void set_ok() {
        status = 1;
    }

public:
    bool is_ok() {
        return status > 0;
    }

    bool is_error() {
        return status < 0;
    }

    bool is_ing() {
        return status == 0;
    }
};


#endif
