
#ifndef UVW_LOOP_CALLBACK_HPP
#define UVW_LOOP_CALLBACK_HPP


class uvw_call_by_loop
{
public:
    //event_handler 在 loop 线程调用;
    //对象的事件在 event_handler 中处理, 可确保访问与 loop 线程一致!
    virtual bool event_handler() = 0;

    //一次性调用的事件放在这里!!
    //若对象未初始化, 则通过 uv_xxx_init(loop_caller, x) 来进行对象的分配及初始化!!
    //init object in loop_caller, api uv_xxx_init!
    virtual bool event_start(void* loop_caller) = 0;
    //virtual bool event_stop(void* loop_caller) = 0;
};



#include "stdx/uvw_list_t.h"
class uvw_call_by_loop_lists : public uvw_list_t<uvw_call_by_loop*>
{
public:
    void event_start(void* loop_caller)
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_call_by_loop *to_call = (*iter);
            if(to_call) {
                to_call->event_start(loop_caller);
            }

            iter++;
        }

        m_tlists.clear();
    }

    bool event_handler()
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        bool has_write = false;
        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_call_by_loop *to_call = (*iter);
            if(to_call) {
                bool has_wr = to_call->event_handler();
                if(has_wr && (!has_write))
                    has_write = true;
            }

            iter++;
        }

        return has_write;
    }
};

#endif
