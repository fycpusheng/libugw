
#ifndef UVW_H
#define UVW_H

#ifdef _WIN32
  /* Windows - set up dll import/export decorators. */
# if defined(BUILDING_UVW_SHARED)
    /* Building shared library. */
#   define UVW_EXTERN __declspec(dllexport)
# elif defined(USING_UVW_SHARED)
    /* Using shared library. */
#   define UVW_EXTERN __declspec(dllimport)
# else
    /* Building static library. */
#   define UVW_EXTERN /* nothing */
# endif

#elif __GNUC__ >= 4
# define UVW_EXTERN __attribute__((visibility("default")))
#else
# define UVW_EXTERN /* nothing */
#endif

#endif
