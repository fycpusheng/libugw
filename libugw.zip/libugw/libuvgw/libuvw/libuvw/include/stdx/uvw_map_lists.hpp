
#ifndef UVW_MAP_LIST_H
#define UVW_MAP_LIST_H

#include <mutex>
#include <list>
#include <unordered_map>

//
// find_value must be is base type/pointer/smart pointer
// find_value 必须是一个基础类型/指针/智能指针!!
template <typename find_key, typename find_value>
class uvw_map_lists
{
public:
    void push_item(find_key key_id, find_value& val)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_unorder_lists[key_id] = val;
    }

    find_key first_key()
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        find_value ptr = 0;
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.begin();
        if(iter != m_unorder_lists.end())
        {
            ptr = iter->first;
        }

        return ptr;
    }

    find_value take_item(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        find_value ptr = 0;
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.find(key_id);
        if(iter != m_unorder_lists.end())
        {
            ptr = iter->second;
            m_unorder_lists.erase(iter);
        }

        return ptr;
    }

    find_value get_item(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        find_value ptr = 0;
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.find(key_id);
        if(iter != m_unorder_lists.end())
        {
            ptr = iter->second;
        }

        return ptr;
    }

    void to_list(std::list<find_value> &lists)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.begin();
        while(iter != m_unorder_lists.end())
        {
            lists.push_back(iter->second);
            iter++;
        }
    }

    unsigned int size() {
        std::lock_guard<std::mutex> lk(m_mutex);
        return (int)(m_unorder_lists.size());
    }

    void clear()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_unorder_lists.clear();
    }

    bool erase_item(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.find(key_id);
        if(iter != m_unorder_lists.end())
        {
            m_unorder_lists.erase(key_id);
            return true;
        }

        return false;
    }

    bool contain(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        typename std::unordered_map<find_key, find_value>::iterator iter = m_unorder_lists.find(key_id);
        if(iter != m_unorder_lists.end()) {
            return true;
        }

        return false;
    }

protected:
    std::mutex  m_mutex;
    std::unordered_map<find_key, find_value> m_unorder_lists;
};

template <typename find_key>
class uvw_map_int_lists : public uvw_map_lists<find_key, int>
{
public:
    int plus_cnt(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(uvw_map_lists<find_key, int>::m_mutex);

        int ptr = 0;
        typename std::unordered_map<find_key, int>::iterator iter = uvw_map_lists<find_key, int>::m_unorder_lists.find(key_id);
        if(iter != uvw_map_lists<find_key, int>::m_unorder_lists.end())
        {
            ptr = iter->second;
            ptr++;

            uvw_map_lists<find_key, int>::m_unorder_lists[iter->first] = ptr;
        }

        return ptr;
    }

    // <0; 表示 key_id 不存在;
    //==0; 表示 计数到最后一个;
    // >0; 表示 计数未到最后一个!!
    int lack_cnt(find_key key_id)
    {
        std::lock_guard<std::mutex> lk(uvw_map_lists<find_key, int>::m_mutex);

        int ptr = -1;
        typename std::unordered_map<find_key, int>::iterator iter = uvw_map_lists<find_key, int>::m_unorder_lists.find(key_id);
        if(iter != uvw_map_lists<find_key, int>::m_unorder_lists.end())
        {
            ptr = iter->second;
            ptr--;

            uvw_map_lists<find_key, int>::m_unorder_lists[iter->first] = ptr;
        }

        return ptr;
    }
};

#endif
