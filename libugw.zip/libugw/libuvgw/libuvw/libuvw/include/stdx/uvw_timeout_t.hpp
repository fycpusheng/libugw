
#ifndef UVW_TIMOUT_LIST_T_H
#define UVW_TIMOUT_LIST_T_H

#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <memory>
#include "../uvw_tools.h"



template<typename TKey>
class uvw_timeout_t
{
public:
    uvw_timeout_t() {
        m_timeout_ms = 3500;
    }

public:
    void push_item(const TKey& path)
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_item_lists[path] = uvw_tools::get_now_ms();
    }

    void remove_item(const TKey& path)
    {
        std::lock_guard<std::mutex> lock(m_mutex);

        typename cm_file_map_lists::iterator iter = m_item_lists.begin();
        while(iter != m_item_lists.end())
        {
            if(iter->first == path)
            {
                iter = m_item_lists.erase(iter);
                break;
            }
        }
    }

    bool contain(TKey& path)
    {
        std::lock_guard<std::mutex> lock(m_mutex);

        typename cm_file_map_lists::iterator iter = m_item_lists.find(path);
        if(iter != m_item_lists.end())
        {
            return true;
        }

        return false;
    }

    bool contain_after_clear(TKey& path)
    {
        clear_timeout();
        return contain(path);
    }

    void clear()
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_item_lists.clear();
    }

    void clear_timeout()
    {
        std::lock_guard<std::mutex> lock(m_mutex);

        typename cm_file_map_lists::iterator iter = m_item_lists.begin();
        while(iter != m_item_lists.end())
        {
            long delta = uvw_tools::get_now_ms() - (iter->second);
            if(delta>m_timeout_ms)
            {
                iter = m_item_lists.erase(iter);
                if(iter == m_item_lists.end())
                    break;
            }
            else
                iter++;
        }
    }

    void take_all_timeout(std::vector<TKey>& lists)
    {
        std::lock_guard<std::mutex> lock(m_mutex);

        typename cm_file_map_lists::iterator iter = m_item_lists.begin();
        while(iter != m_item_lists.end())
        {
            long delta = uvw_tools::get_now_ms() - (iter->second);
            if(delta>m_timeout_ms)
            {
                lists.push_back(iter->first);

                iter = m_item_lists.erase(iter);
                if(iter == m_item_lists.end())
                    break;
            }
            else
                iter++;
        }
    }

public:
    void set_timeout(long ms) {
        m_timeout_ms = ms;
    }

    long timeout() {
        return m_timeout_ms;
    }

private:
    typedef std::unordered_map<TKey, long>  cm_file_map_lists;
    cm_file_map_lists  m_item_lists;

    long       m_timeout_ms;
    std::mutex m_mutex;
};


#endif
