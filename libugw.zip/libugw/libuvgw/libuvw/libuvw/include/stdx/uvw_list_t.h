
#ifndef _UVW_LIST_T_H_
#define _UVW_LIST_T_H_


#include <mutex>
#include <list>

template<typename containerT>
class uvw_list_t
{
public:
    void push_item(containerT tinst)
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        m_tlists.push_back(tinst);
    }

    void remove_item(containerT tinst)
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        typename t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            if(*iter == tinst)
            {
                m_tlists.erase(iter);
                break;
            }
            iter++;
        }
    }

    containerT header()
    {
        containerT value;
        std::lock_guard<std::mutex> lg(m_mutex);
        typename t_container_list::iterator iter = m_tlists.begin();
        if(iter != m_tlists.end())
            value = *iter;

        return value;
    }

    containerT take_header()
    {
        containerT value;
        std::lock_guard<std::mutex> lg(m_mutex);
        typename t_container_list::iterator iter = m_tlists.begin();
        if(iter != m_tlists.end())
        {
            value = *iter;
            m_tlists.erase(iter);
        }

        return value;
    }

    bool contain(containerT tinst)
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        typename t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            if(*iter == tinst)
                return true;
            iter++;
        }

        return false;
    }

    void remove_all()
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        m_tlists.clear();
    }

    int size()
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        return m_tlists.size();
    }


public:
    typedef bool (*handle_iterator)(typename std::list<containerT>::iterator iter);

public:
    //break if handle return true
    void start_iterator(handle_iterator handle)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        typename std::list<containerT>::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            if(handle(iter))
                break;

            iter++;
        }
    }

    //取走符合 handle_iterator 条件的项!!
    containerT take_iterator(handle_iterator handle)
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        containerT value;
        typename std::list<containerT>::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            if(handle(iter))
            {
                value = (*iter);
                m_tlists.erase(iter);
                break;
            }

            iter++;
        }

        return value;
    }

public:
    typedef std::list<containerT> t_container_list;

protected:
    std::mutex  m_mutex;
    t_container_list m_tlists;
};

#endif
