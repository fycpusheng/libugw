#ifndef UVW_THREAD_H
#define UVW_THREAD_H


#include <uv.h>
#include <uvw.h>


typedef void (*uvw_thread_cb)(void *arg);

class uvw_thread
{
public:
    uvw_thread();

public:
    void start(uvw_thread_cb cb, void* param);
    void join();

private:
    uv_thread_t m_tid;
};

#endif
