
#ifndef  _UVM_LOOP_MGR_H_
#define  _UVM_LOOP_MGR_H_

#include <stdio.h>
#include <uv.h>
#include <uvw.h>
#include <unordered_map>
#include <mutex>
#include "uvw_thread_group.h"
#include "stdx/uvw_map_lists.hpp"


#if 1
#define  uvw_thread_t   std::thread::id
#define  uvw_thread_id  std::this_thread::get_id
#else
#define  uvw_thread_t   uv_thread_t
#define  uvw_thread_id  uv_thread_self
#endif


/* m_is_svr_mode :
 * listen mode use this variable, client mode call start_loop_thread that dont set it;
 *
 * */
class uvw_loop;
class UVW_EXTERN uvw_loop_lists
{
public:
    uvw_loop_lists() {
        m_load_index = 0;
    }

    ~uvw_loop_lists() {
        printf("this is uvw_loop_lists deconstructor \r\n");
    }

public:
    void push_loop_item(uvw_thread_t tid, uvw_loop* uloop)
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        m_loop_lists[tid] = uloop;
    }

    void remove_loop_item(uvw_thread_t tid)
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        uvw_loop_map::iterator iter = m_loop_lists.find(tid);
        if(iter != m_loop_lists.end())
        {
            m_loop_lists.erase(iter);
        }
    }

    //notice:
    //get_loop绝对不能自动创建 uvw_loop; 必须由用户主动 new uvwloop;
    //以避免回调与 uvw_loop 不在一个线程的情况..
    //
    //若没有loop则证明线程不是我们创建的 uvloop, 可能是系统回调产生的线程,
    //或者自己创建但没有用uvloop(这种情况下的线程有其独立的作用);;
    uvw_loop*  get_loop(uvw_thread_t tid);
    uvw_loop*  get_loop(uv_loop_t* tid);
    uv_loop_t* get_loop_t(uvw_thread_t tid);

public:
    uvw_loop*  get_free_loop();
    uv_loop_t* get_free_loop_t();

public:
    //trds : 启动多少个loop线程??
    void start_loop_thread(int trds);
    void stop_loops();
    void join();

public:
    //读写在一个线程投递时, 启用此模式!!
    bool is_svr_mode() { return m_is_svr_mode; }

public:
    typedef  std::unordered_map<uvw_thread_t, uvw_loop*>  uvw_loop_map;
    typedef  uvw_map_lists<uvw_thread_t, std::thread*>    uvw_loop_threads;

protected:
    uvw_loop_threads  m_group_threads;
    uvw_loop_map      m_loop_lists;
    std::mutex        m_mutex;
    bool              m_is_svr_mode;

private:
    //client use it
    unsigned int      m_load_index;
};


class UVW_EXTERN uvw_loop_mgr : public uvw_loop_lists
{
public:
    static uvw_loop_mgr* Instance();

public:
    //start_loop_task_thread 仅针对 listen socket 有效; 即服务器有效!!!
    void start_loop_task_thread(int trds);
};


#endif
