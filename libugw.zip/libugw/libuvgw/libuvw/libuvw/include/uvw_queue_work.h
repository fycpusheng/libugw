
#ifndef  _UVW_QUEUE_WORK_H_
#define  _UVW_QUEUE_WORK_H_

#include <stdio.h>
#include <uv.h>
#include <uvw.h>
#include <unordered_map>
#include <mutex>


class UVW_EXTERN uvw_queue_work
{
public:
    uvw_queue_work();
    virtual ~uvw_queue_work();

public:
    virtual void work_cb(void* udata) = 0;
    virtual void after_work_cb(void* udata, int status) = 0;

public:
    void  work(uv_loop_t *loop_t, void *udata);
    void* user_data() { return m_udata; }

private:
    uv_work_t *m_work_t;
    void*      m_udata;
};


#endif
