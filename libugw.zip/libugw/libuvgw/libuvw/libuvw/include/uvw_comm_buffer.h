#ifndef UVW_COMMON_BUFFER_H
#define UVW_COMMON_BUFFER_H

#include <memory>
#include <memory.h>
#include <vector>
#include <atomic>


#pragma pack(8)
namespace uvw
{
struct comm_buffer
{
public:
    char *buffer;
    int   size;

    //std::atomic<int> cnt;
    //comm_buffer *next;

public:
    comm_buffer() {
    }
    comm_buffer( int sz)
    {
        buffer = new char[sz];
        size = sz;
        //next = 0;

        memset(buffer,0,sz);
    }

    comm_buffer(const char* data, int sz)
    {
#if 1
        buffer = new char[sz];
        memcpy(buffer, data, sz);
#else
        if(data)
            buffer = data;
        else {
            buffer = new char[sz];
            memset(buffer, 0, sz);
        }
#endif
        size = sz;
        //next = 0;
    }

    comm_buffer(comm_buffer &buf)
    {
        this->buffer = buf.buffer;
        this->size = buf.size;

        buf.detach();
    }

    ~comm_buffer()
    {
        if(buffer)
        {
            delete []buffer;
            buffer = 0;
        }
    }

    void attach(char *data, int sz)
    {
        buffer = data;
        size = sz;
    }

    void detach()
    {
        size = 0;
        buffer = 0;
    }

    char* data_ptr() { return buffer; }
};

}

typedef uvw::comm_buffer             uvw_buffer;
typedef std::vector<uvw_buffer>      uvw_buffer_array;
typedef std::shared_ptr<uvw_buffer>  uvw_buffer_ptr;

namespace uvw {
    struct link_buffer
    {
        uvw_buffer_ptr buffer_ptr;
        link_buffer *next;

        link_buffer()           { next = 0; }
        char* data_ptr()        { return buffer_ptr->data_ptr(); }
        void* off_ptr(int off)  { return data_ptr() + off; }
    };
}
typedef uvw::link_buffer  uvw_link_buffer;


// //////////////////////////////////////////////////////////////////////////////// //
// //////////////////////////////////////////////////////////////////////////////// //
//
#include <mutex>
#include <list>

class uvw_buffer_lists
{
public:
    void push_item(uvw_buffer_ptr ptr)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_write_lists.push_back(ptr);
    }

    void remove_all()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_write_lists.clear();
    }

    uvw_buffer_ptr take_header()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        if(m_write_lists.size()<=0)
            return 0;

        uvw_buffer_ptr ptr = m_write_lists.front();
        m_write_lists.pop_front();
        return ptr;
    }

    int size() {
        std::lock_guard<std::mutex> lk(m_mutex);
        return (int)(m_write_lists.size());
    }

protected:
    std::mutex m_mutex;
    std::list<uvw_buffer_ptr> m_write_lists;
};

#pragma pack()

#endif
