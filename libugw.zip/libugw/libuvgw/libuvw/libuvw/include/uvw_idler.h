
#ifndef  _UVM_IDLER_H_
#define  _UVM_IDLER_H_

#include <uv.h>
#include <uvw.h>

class UVW_EXTERN uvw_idler
{
public:
    uvw_idler() {
        m_idler_t = 0;
    }
    virtual ~uvw_idler();

public:
    void start_idler(uv_loop_t *loop_t);
    void stop_idler();

public:
    virtual void wait_for_idler() = 0;

private:
    void init(uv_loop_t *loop_t);
    void close();

private:
    uv_idle_t* m_idler_t;
};


#endif
