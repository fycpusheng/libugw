﻿#ifndef _UVW_THREAD_GROUP_H
#define _UVW_THREAD_GROUP_H

#include <thread>
#include <mutex>
#include <list>
#include <memory>
#include <algorithm>


namespace uvw
{
    //兼容boost::thread_group
    //使用std::thread代替boost::thread, std::mutex代替boost::shared_mutex
    class thread_group
    {
    private:
        thread_group(thread_group const&);
        thread_group& operator=(thread_group const&);

    public:
        thread_group() {}
        ~thread_group()
        {
            for(auto it = m_threads.begin(); it != m_threads.end(); ++it)
            {
                delete *it;
            }
        }

        template<typename F>
        std::thread* create_thread(F threadfunc)
        {
            std::lock_guard<std::mutex> guard(m_mutex);
            std::thread *thd = new std::thread(threadfunc);
            m_threads.push_back(thd);
            return thd;
        }

        void add_thread(std::thread* thrd)
        {
            if(thrd)
            {
                //mark:
                //assert(std::find(m_threads.begin(), m_threads.end(), thrd) != m_threads.end());
                std::lock_guard<std::mutex> guard(m_mutex);
                m_threads.push_back(thrd);
            }
        }

        void remove_thread(std::thread* thrd)
        {
            std::lock_guard<std::mutex> guard(m_mutex);
            auto iter = std::find(m_threads.begin(), m_threads.end(), thrd);
            if(iter != m_threads.end())
            {
                m_threads.erase(iter);
            }
        }

        void join_all()
        {
            std::lock_guard<std::mutex> guard(m_mutex);
            for(auto iter = m_threads.begin(); iter != m_threads.end(); ++iter)
            {
                (*iter)->join();
            }
        }

        size_t size() const
        {
            std::lock_guard<std::mutex> guard(m_mutex);
            return m_threads.size();
        }

    private:
        std::list<std::thread*> m_threads;
        mutable std::mutex m_mutex;
    };
}

#endif
