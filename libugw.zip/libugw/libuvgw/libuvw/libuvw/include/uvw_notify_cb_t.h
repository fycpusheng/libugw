#ifndef UVW_NOTIFY_CB_T_H
#define UVW_NOTIFY_CB_T_H

#include "uvw_notify_cb.h"
#include <vector>
#include <memory>
#include <assert.h>


template <class CommHeader, int READ_BUFFER_MAX_LEN>
class uvw_notify_cb_t : public uvw_notify_cb
{
public:
    uvw_notify_cb_t() {
       m_t_had_bytes  = 0;
       m_t_buffer_ptr = new char[READ_BUFFER_MAX_LEN];
    }

    virtual ~uvw_notify_cb_t() {
        if(m_t_buffer_ptr)
        {
            delete m_t_buffer_ptr;
            m_t_buffer_ptr = 0;
        }
    }

public:
    virtual void prepare_buffer(cb_buffer &buffer)
    {
        if(m_t_had_bytes>0)
        {
            buffer.buf_size = READ_BUFFER_MAX_LEN - m_t_had_bytes;
            buffer.buf_pos = m_t_buffer_ptr + m_t_had_bytes;
        }
        else
        {
            buffer.buf_size = READ_BUFFER_MAX_LEN;
            buffer.buf_pos = m_t_buffer_ptr;
        }
    }

    virtual void read_finished(const char *data, int size)
    {
        if(m_t_had_bytes>0)
        {
            tmp_assert(size+m_t_had_bytes <= READ_BUFFER_MAX_LEN);
            data = m_t_buffer_ptr;
            size += m_t_had_bytes;
        }

        //理论上不可能出现, 仅读取几个字节的情况!!
        if(size < sizeof(CommHeader))
            break;

        CommHeader *wrapper = (CommHeader*)data;
        if(wrapper->size == size)
        {
            m_t_had_bytes  = 0;
            on_read_data(data, size);
        }
        else if(wrapper->size < size)
        {
            on_read_data(data, wrapper->size);

            CommHeader *wrapper2 = wrapper;
            while(true)
            {
                data += wrapper2->size;
                size -= wrapper2->size;

                if(size < sizeof(CommHeader))
                    break;

                wrapper2 = (CommHeader*)data;
                if(wrapper2->size <= size)
                {
                    on_read_data(data, wrapper2->size);
                }
                else
                    break;
            }

            //不对具体数据进行分析, 按固定大小来读取, 减小难度//
            if(size>0)
            {
                m_t_had_bytes = size;
                memcpy(m_t_buffer_ptr, data, size);
            }
            else
                m_t_had_bytes = 0;
        }
        else
        {
            //特殊情况:
            //一个数据包, 接收了多次才接收全!!!
            m_t_had_bytes = size;

            //note:
            //@1: 所有协议的数据包最大不能超过 READ_BUFFER_MAX_LEN//
            //@2: wrapper->size > size, 但小于 READ_BUFFER_MAX_LEN, 继续读取//
        }
    }

    virtual void on_read_data(const char *data, int bytes) = 0;

public:
    //m_t_had_bytes: 已读取字节数;
    int   m_t_had_bytes;
    char *m_t_buffer_ptr;
};


#endif
