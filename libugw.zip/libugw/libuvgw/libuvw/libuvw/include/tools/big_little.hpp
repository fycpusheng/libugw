#ifndef _UVW_SHARE_BIG_ENDIAN_HPP
#define _UVW_SHARE_BIG_ENDIAN_HPP

namespace uvw_share
{
    class big_endian
    {
    public:
        big_endian()
        {
            m_big_endian = is_big_endian_test();
        }

        //高字节保存在低位, 是大端..
        bool is_big_endian_test()
        {
            short int x = 0x1122;
            char x0;
            x0 = *((char *)&x);      //把x的低位地址的值赋给x0;
            if(x0 == 0x11)
                return true;

            return false;
        }

    public:
        inline bool is_big_endian()
        {
            return m_big_endian;
        }

    protected:
        bool m_big_endian;
    };

    template<class dtype>
    dtype swap_big_little(dtype data)
    {
        dtype new_data;
        char *new_char = (char*)(&new_data);
        char *old_char = (char*)(&data);

        int end_flag = sizeof(dtype)-1;
        for(int i=0; i<=end_flag; i++)
        {
            new_char[end_flag-i] = old_char[i];
        }
        return new_data;
    }
}

#endif