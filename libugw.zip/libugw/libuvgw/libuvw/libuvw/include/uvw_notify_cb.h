
#ifndef  _UVM_DATA_NOTIFY_H_
#define  _UVM_DATA_NOTIFY_H_

#include "uvw_comm_buffer.h"
#include <list>
#include <mutex>
#include <memory>
#include "uvw.h"
#include "mpool/uvw_mem_pool_real.hpp"


//在uvw_tcp_instance 关闭时, uvw_notify_cb 将自己加入 cb_mgr;
//uvw_notify_cb 的释放, 由 uvw_notify_cb_mgr 负责;
class UVW_EXTERN uvw_notify_cb
{
public:
    typedef struct cb_buffer_x
    {
        char *buf_pos;
        int   buf_size;
    }
    cb_buffer;

public:
    //下列函数由 uvw_tcp_instance 回调..
    //read_finished 中的数据为静态数据, 若不能立即返回, 请拷贝出来!!!
    //
    //will_close :
    // -- 此函数被为SOCKET 关闭时调用,
    // -- 标志着 uvw_notify_cb 对象指针不再被 uvw_tcp_instance 使用,
    // -- 函数实现中 应将自身加入 uvw_notify_cb_mgr 中进行释放管理,
    // -- 因为 uvw_tcp_instance 并不对 uvw_notify_cb 进行释放.//
    //
    //header_bytes :
    // -- 用于每个完整包头的字节数读取, 此种方案效率不如现在的高, 未用;
    // -- 现在的方案, 解析上略复杂, 但效率更高//
public:
    virtual void prepare_buffer(cb_buffer &buffer) = 0;
    virtual void write_finished(int status) = 0;
    virtual void read_finished(const char *data, int size) = 0;
    virtual void will_close() = 0;
    virtual bool is_can_free() = 0;

public:
    // ////////////////////////////////////////////////////////////////////// //
    // ////////////////////////////////////////////////////////////////////// //
    // //////////////////////// 待发送缓冲队列 ///////////////////////////////// //
    // // push_pure:
    // // 用户可直接对原数据进行操作, 以便在进行协议封装时减少不必要的损耗;
    // // 封装后调用 push_item 添加到队列中(封装用于 TCP 之外的互联网协议; 如 websocket!!)
    // // 默认情况下 push_pure 直接将 数据拷贝到新New 的智能指针中; 然后调用 push_item!!
    // // 故, push_pure 必会调用 push_item; 若无须协议封装(或已封装好)可直接调用 push_item !!
    // //
    virtual void push_pure(const char* data, int size);
    virtual void push_item(uvw_buffer_ptr ptr);
    virtual void remove_all();

public:
    uvw_buffer_ptr take_header();

protected:
    uvw_buffer_lists m_write_lists;
    //
    // ////////////////////////////////////////////////////////////////////// //
    // ////////////////////////////////////////////////////////////////////// //
    //
public:
    // -- ---------------------------------------------------------------- -- //
    // -- ---------------------------------------------------------------- -- //
    // -- 将关闭放在回调当中, 可以让用户在自己的扩展中控制TCP链接!!
    // -- heart beat !!
    uvw_notify_cb()          { m_close_bits = false; }
    virtual ~uvw_notify_cb() { }

public:
    void set_close_bits() { m_close_bits = true;  }
    void cls_close_bits() { m_close_bits = false; }
    bool is_close_bits()  { return m_close_bits;  }

private:
    bool m_close_bits;
    // -- ---------------------------------------------------------------- -- //
    // -- ---------------------------------------------------------------- -- //
};

class UVW_EXTERN uvw_notify_cb2 : public uvw_notify_cb
{
public:
    uvwpool::object_pool_bytes& m_pool_ptr;
};


#endif
