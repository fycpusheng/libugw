
#ifndef  _UVM_LOOP_H_
#define  _UVM_LOOP_H_

#include <stdio.h>
#include <uv.h>
#include <uvw.h>
#include <unordered_map>
#include <mutex>

//notice:
//uvw_loop 需要至少一个事件, 否则将退出循环!!
//uvw_loop needs at least one event, or it will exit the loop
//
class UVW_EXTERN uvw_loop
{
    friend class uvw_loop_lists;
    friend class uvw_loop_mgr;
protected:
    uvw_loop();
    uvw_loop(uv_loop_t *loop);  //will get of ownership to loop
    virtual ~uvw_loop();

public:
    uv_loop_t *get_loop_t() { return m_loop_t; }

public:
    virtual void run();
    virtual void stop();

private:
    void close();

protected:
    uv_loop_t  *m_loop_t;
};


#include "uvw_idler.h"
class uvw_loop_idler_base : public uvw_loop, uvw_idler
{
public:
    void start_idler() {
        uvw_idler::start_idler(m_loop_t);
    }
    void stop_idler() {
        uvw_idler::stop_idler();
    }

public:
    virtual void wait_for_idler() = 0;
    virtual void stop() {  stop_idler(); uvw_loop::stop(); }
};


// -- ------------------------------------------------ --//
// -- uvw_loop_idler 具有通用性, 它是在实现 uvw_loop_async 之后实现的;
// -- 所以没有对 uvw_loop_async 的相关代码进行修改!!
// -- ------------------------------------------------ --//
#include <uvw_loop_callback.hpp>
class uvw_loop_idler : public uvw_loop_idler_base
{
public:
    virtual void wait_for_idler();
    virtual void run();

public:
    uvw_call_by_loop_lists m_call_lists;
    uvw_call_by_loop_lists m_once_lists;
};

// -- ---------------------------------------------- -- //
/* ** uvw_loop_async: server use it !! ** */
// -- ---------------------------------------------- -- //

#include "uvw_tcp_instance.h"
class uvw_loop_async : public uvw_loop_idler_base
{
public:
    uvw_loop_async();

private:
    void async_send();
    void async_read();

public:
    virtual void wait_for_idler();
    virtual void run();

public:
    //m_async_lists : 进入读写状态的 socket 列表!!!
    //m_ready_lists : 准备调用 read_start 的列表!!!
    uvw_tcp_instance_lists m_async_lists;
    uvw_tcp_instance_lists m_ready_lists;
};


#endif
