﻿#ifndef UVW_TMP_LOG_H
#define UVW_TMP_LOG_H


#include "assert.h"


#ifdef Q_OS_WIN

#ifdef _DEBUG
#define  tmp_printf(format, ...)   printf(format, __VA_ARGS__); printf("\r\n");
#define  tmp_assert(art)           assert(art)
#else
#define  tmp_printf(format, ...)   printf("%s, %d", __FILE__, __LINE__); printf(format, __VA_ARGS__); printf("\r\n");
#define  tmp_assert(art)
#endif

#else

//linux 必需添加 ##, 才能在不传变量参数的情况下, 实现正确的解析//
//
#ifdef _DEBUG
#define  tmp_printf(format, ...)   printf(format, ##__VA_ARGS__); printf("\r\n");
#define  tmp_assert(art)           assert(art)
#else
#define  tmp_printf(format, ...)   printf(format, ##__VA_ARGS__); printf("\r\n");
#define  tmp_assert(art)
#endif

#endif


#endif
