
#ifndef  _UVM_TCP_SVR_H_
#define  _UVM_TCP_SVR_H_

#include <stdio.h>
#include <uv.h>
#include <uvw.h>
#include <unordered_map>
#include <mutex>


class uvw_loop_mgr;
class uvw_tcp_instance;
class UVW_EXTERN uvw_tcp_svr
{
public:
    uvw_tcp_svr(uv_loop_t *loop_t);
    virtual ~uvw_tcp_svr();

private:
    uvw_tcp_svr();

private:
    void init(uv_loop_t *loop_t);

public:
    bool bind_v4(std::string ipstr, int port, unsigned int flags);
    bool bind_v6(std::string ipstr, int port, unsigned int flags);

    //lmgr : client allocator
    bool listen(int backlog);
    void close();

    virtual void new_instance_cb(uvw_tcp_instance *instance) = 0;

private:
    void listen_accept_connect_cb(void* loop_caller);
    void listen_accept_connect_cb();

private:
    uv_tcp_t* m_server;

    bool   m_is_v4;
    struct sockaddr_in  m_addr_v4;
    struct sockaddr_in6 m_addr_v6;

    // ///////////////////////////////// //
    // add new 2022.8.10
public:
    void set_loop_mgr(uvw_loop_mgr* loop_mgr) {
        m_loop_mgr = loop_mgr;
    }

    uvw_loop_mgr* get_loop_mgr() {
        return m_loop_mgr;
    }

private:
    uvw_loop_mgr* m_loop_mgr;
};


#endif
