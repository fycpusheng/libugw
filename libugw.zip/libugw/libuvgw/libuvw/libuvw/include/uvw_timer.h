
#ifndef  _UVM_TIMER_H_
#define  _UVM_TIMER_H_

#include <uv.h>
#include <uvw.h>


class UVW_EXTERN uvw_timer
{
public:
    uvw_timer();
    uvw_timer(uv_loop_t *loop_t);
    virtual ~uvw_timer();

public:
    void init(uv_loop_t *loop_t);

public:
    bool has_init();
    void init_if_need(void* loop_t)
    {
        if(!has_init()) {
            uvw_timer::init((uv_loop_t*)loop_t);
        }
    }

public:
    void start_timer(int fts, int repeat);
    void stop_timer();

public:
    virtual void timer_cb() = 0;

private:
    bool m_is_start;
    uv_timer_t* m_timer_t;
};


class UVW_EXTERN uvw_timer_heartbeat : public uvw_timer
{
public:
    uvw_timer_heartbeat() { m_timeout_cnt = 3; }
    uvw_timer_heartbeat(uv_loop_t *loop_t) : uvw_timer(loop_t) {}

public:
    virtual void timer_cb() = 0;

protected:
    int  m_timeout_cnt;
};

#endif
