
#ifndef  _UVM_DATA_H_
#define  _UVM_DATA_H_

#include <uv.h>

typedef struct {
    uv_write_t req;
    uv_buf_t buf;
}
uvw_write_t;



#endif
