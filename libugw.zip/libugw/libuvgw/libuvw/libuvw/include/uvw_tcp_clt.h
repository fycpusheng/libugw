
#ifndef  _UVM_TCP_CLT_H_
#define  _UVM_TCP_CLT_H_

#include "assert.h"
#include "uvw_tools.h"
#include "uvw_notify_cb.h"
#include "uvw_data.h"
#include "uvw_def.h"
#include <string>
#include "uvw_loop_mgr.h"
#include "uvw_connect_status.h"


#undef   UV_ERRNO_H_
#include <uv/errno.h>


class uvw_tcp_clt
{
private:
    //forbid call it
    uvw_tcp_clt() {}

public:
    uvw_tcp_clt(uv_loop_t *loop_t)
    {
        m_is_v4 = true;
        m_client = 0;

        if(loop_t) {
            init(loop_t);
        }
    }

    virtual ~uvw_tcp_clt()
    {
        close();

        if(m_notify_cb) {
            delete m_notify_cb;
            m_notify_cb = 0;
        }
    }

public:
    uv_loop_t* get_loop_t()
    {
        if(m_client) {
            return m_client->loop;
        }

        return 0;
    }

    void attach_notify_cb(uvw_notify_cb* cb) {
        m_notify_cb = cb;
    }

public:
    bool bind_v4(std::string ipstr, int port, unsigned int flags)
    {
        m_is_v4 = true;
        uv_ip4_addr(ipstr.data(), port, &m_addr_v4);
        return (uv_tcp_bind(m_client, (const struct sockaddr*)&m_addr_v4, flags) == 0);
    }

    bool bind_v6(std::string ipstr, int port, unsigned int flags)
    {
        m_is_v4 = false;
        uv_ip6_addr(ipstr.data(), port, &m_addr_v6);
        return (uv_tcp_bind(m_client, (const struct sockaddr*)&m_addr_v6, flags) == 0);
    }

protected:
    void init(uv_loop_t *loop_t)
    {
        m_notify_cb = 0;

        m_client = new uv_tcp_t;
        m_client->data = this;
        uv_tcp_init(loop_t, m_client);

        m_connect_t = new uv_connect_t;
        m_connect_t->data = this;
        m_is_connected.set_error();
    }

    //close at read error
    void only_close()
    {
        m_notify_cb->will_close();

        if(m_client)
        {
            uv_tcp_t *tcp_t = m_client;
            m_client = 0;

            uv_close((uv_handle_t*)(tcp_t), [](uv_handle_t* handle)
            {
                //delete m_client
                delete ((uv_tcp_t*)handle);
            });
        }
    }

public:
    void close()
    {
        shut_down();
        only_close();
    }

public:
    bool is_closed()     { return (m_client==0); }
    bool is_connected()  { return m_is_connected.is_ok();  }
    bool is_connecting() { return m_is_connected.is_ing(); }

public:
    //connect will block util done..
    bool connect_v4(std::string ipstr, int port){
        return connect_to(ipstr, port, true);
    }
    bool connect_v6(std::string ipstr, int port) {
        return connect_to(ipstr, port, false);
    }

public:
    void read_start()
    {
        uv_read_start((uv_stream_t*)(m_client), [](uv_handle_t *handle, size_t suggested_size, uv_buf_t *buf){
            uvw_tcp_clt *instance = (uvw_tcp_clt*)handle->data;
            if(instance)
            {
                //typename uvw_notify_cb::cb_buffer cbuf;
                uvw_notify_cb::cb_buffer cbuf;
                instance->m_notify_cb->prepare_buffer(cbuf);

                buf->base = cbuf.buf_pos;
                buf->len  = cbuf.buf_size;
            }
            return;
        },
        [](uv_stream_t *client, ssize_t nread, const uv_buf_t *buf)
        {
            if (nread > 0)
            {
                uvw_tcp_clt *instance = (uvw_tcp_clt*)client->data;
                if(instance)
                {
                    instance->m_notify_cb->read_finished(buf->base, nread);
                }
            }
            else if (nread < 0)
            {
                uvw_tcp_clt *instance = (uvw_tcp_clt*)client->data;
                if(instance)
                {
                    //标记是否需要调用uv_shutdown//
                    if((nread == UV__ECONNRESET) || (nread == UV__EOF)) {
                        instance->m_is_connected.set_error();
                    }
                    instance->close();
                }
            }
        });
    }

    //mark://
    //close and write need add lock??//
    bool write_if_has_data()
    {
        //if(m_client && uv_is_writable((uv_stream_t*)(m_client)))
        if(m_client && m_is_connected.is_ok())
        {
            if(uv_is_writable((uv_stream_t*)(m_client)))
            {
                uvw_buffer_ptr ptr = m_notify_cb->take_header();
                if(ptr)
                {
                    write_to_uv(ptr->buffer, ptr->size);
                    ptr->detach();
                    return true;
                }
            }
        }

        return false;
    }

    //传递进来的数据将被 write_to_cache 独占!!
    //write_to_cache will get ownership of data
    //data will was get uvw_tcp_clt!!
    void write_to_cache(char* data, int size)
    {
        uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>();
        ptr->attach((char*)data, size);
        m_notify_cb->push_item(ptr);
    }

    //will copy str memory
    void write_to_cache(std::string str)
    {
        char *buffer = new char[str.size()];
        memcpy(buffer, str.data(), str.size());
        write_to_cache(buffer, str.size());
    }

    //传递进来的数据将被 write_to_socket 独占!!
    //write_to_socket will get ownership of data
    void write_to_socket(char* data, int size)
    {
        write_to_uv(data, size);
    }

private:
    void write_to_uv(char* data, int size)
    {
        //m_client 奇怪关闭? 查询是未加入心跳导致服务端将链接关闭导致, 加入心跳即可..
        //if(m_client == 0) return;

        uvw_write_t *req = (uvw_write_t*)(new uvw_write_t);
        req->buf = uv_buf_init(data, size);
        req->req.data = this;

        uv_write((uv_write_t*)req, (uv_stream_t*)(m_client), &req->buf, 1, [](uv_write_t *req, int status){
            uvw_write_t *uvw_req = (uvw_write_t*)(req);
            if(uvw_req)
            {
                uvw_tcp_clt *instance = (uvw_tcp_clt*)req->data;
                if(instance)
                {
                    instance->m_notify_cb->write_finished(status);
                }

                delete []uvw_req->buf.base;
                delete uvw_req;
            }
        });
    }

protected:
    void shut_down()
    {
        if(m_is_connected.is_ok())
        {
            m_is_connected.set_error();
            assert(m_connect_t);

            uv_connect_t *tconnect_t = m_connect_t;
            m_connect_t = 0;

            bool is_shut_down = false;
            uv_shutdown_t sdt;
            sdt.data = &is_shut_down;
            uv_shutdown(&sdt, tconnect_t->handle, [](uv_shutdown_t* req, int status){
                bool *is_sdown = (bool *)(req->data);
                *is_sdown = true;
            });
            while(!is_shut_down) uvw_tools::ms_sleep(100);
            delete tconnect_t;
        }
        else
        {
            if(m_connect_t)
            {
                delete m_connect_t;
                m_connect_t = 0;
            }
        }
    }

    bool connect_to(std::string ipstr, int port, bool is_v4)
    {
        int ret = 0;
        m_connect_t->data = this;

        m_is_connected.set_ing();
        if(is_v4)
        {
            uv_ip4_addr(ipstr.data(), port, &m_addr_v4);
            ret = uv_tcp_connect(m_connect_t, m_client, (const struct sockaddr*)&m_addr_v4, [](uv_connect_t* req, int status) {
                uvw_tcp_clt *ndata = (uvw_tcp_clt*)req->data;
                if(status < 0)
                    ndata->m_is_connected.set_error();
                else {
                    ndata->m_is_connected.set_ok();
                    ndata->on_connect_ok();
                }
            });
        }
        else
        {
            uv_ip6_addr(ipstr.data(), port, &m_addr_v6);
            ret = uv_tcp_connect(m_connect_t, m_client, (const struct sockaddr*)&m_addr_v6, [](uv_connect_t* req, int status) {
                uvw_tcp_clt *ndata = (uvw_tcp_clt*)req->data;
                if(status < 0)
                    ndata->m_is_connected.set_error();
                else {
                    ndata->m_is_connected.set_ok();
                    ndata->on_connect_ok();
                }
            });
        }

        //若 ret 返回值为失败, 证明平台 api, connect 失败; 此时, 将不会发生回调!!
        //注意: close 后, 句柄释放, 此对象将不再可用!!
        if(ret != 0) {
            m_is_connected.set_error();
            close();
        }

        //wait_result(1500);
#ifdef  _DEBUG
        std::string error = std::string(" connect to ");
        error = error + ipstr + std::string(":");
        error = error + std::to_string(port) + std::string("  query !!! \r\n");
        printf(error.data());
#endif

        return m_is_connected.is_ok();
    }

    virtual void on_connect_ok() = 0;

public:
    bool wait_result(int ms)
    {
        //wait return of uv_tcp_connect
        int  max_wait = 0;
        while(m_is_connected.is_ing())
        {
            uvw_tools::ms_sleep(300);
            max_wait++;
            if((max_wait*300) >= ms)
            {
                m_is_connected.set_error();
                break;
            }
        }

        //restore data field
        return m_is_connected.is_ok();
    }

protected:
    uv_tcp_t*      m_client;
    uv_connect_t  *m_connect_t;
    uvw_notify_cb *m_notify_cb;

    bool   m_is_v4;
    uvw_connect_status  m_is_connected;
    struct sockaddr_in  m_addr_v4;
    struct sockaddr_in6 m_addr_v6;
};


#include "stdx/uvw_list_t.h"
class uvw_tcp_clt_lists : public uvw_list_t<uvw_tcp_clt*>
{
public:
    bool async_send()
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        bool has_write = false;
        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_clt *to_client = (*iter);
            if(to_client)
            {
                bool has_wr = to_client->write_if_has_data();
                if(has_wr && (!has_write))
                    has_write = true;
            }

            iter++;
        }

        return has_write;
    }

    void async_read_start()
    {
        std::lock_guard<std::mutex> lg(m_mutex);

        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_clt *to_client = (*iter);
            if(to_client) {
                to_client->read_start();
            }

            iter++;
        }

        m_tlists.clear();
    }

    void erase_invalid_instance()
    {
        std::lock_guard<std::mutex> lg(m_mutex);
        t_container_list::iterator iter = m_tlists.begin();
        while(iter != m_tlists.end())
        {
            uvw_tcp_clt *to_client = (*iter);
            if(to_client && to_client->is_closed())
            {
                delete to_client;
                iter = m_tlists.erase(iter);
            }
            else
                iter++;
        }
    }

};


#endif
