
#ifndef UVW_MATH_H
#define UVW_MATH_H


#define uvw_min(a, b)  (a>b?b:a)
#define uvw_max(a, b)  (a<b?b:a)


#endif
