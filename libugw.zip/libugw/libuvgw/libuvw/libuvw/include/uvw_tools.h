
#ifndef  _UVM_TOOLS_H_
#define  _UVM_TOOLS_H_

#include <uvw.h>
#include "tools/big_little.hpp"


class UVW_EXTERN uvw_tools
{
public:
    uvw_tools() {}

public:
    static void ms_sleep(long ms);
    static long get_now_ms();

public:
    static bool is_big_endian();
};


#endif
