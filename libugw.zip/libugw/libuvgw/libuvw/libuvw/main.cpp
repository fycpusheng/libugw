#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <uv.h>


#if 0

#else
#include "uvw_tcp_clt.h"
#include "uvw_loop.h"
#include "assert.h"
#include "uvw_tools.h"
#include "uvw_notify_cb.h"
#include "uvw_notify_mgr.h"
#include "uvw_data.h"
#include "uvw_loop_mgr.h"
#include "uvw_tcp_svr.h"

//#######################################################################
//uvw_tcp_clt examples
class uvw_notify_cb_ex : public uvw_notify_cb
{
public:
    virtual void write_finished(int status) {}
    virtual void read_finished(const char *data, int size){
        char *reack = new char[size];
        memcpy(reack, data, size);
        uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>(reack, size);
        push_item(ptr);
        delete []reack;

        OutputDebugStringA(std::string(data, size).data());
    }
    virtual void will_close(){}
    virtual bool is_can_free() { return false; }
};

class uvw_tcp_client : public uvw_tcp_clt<uvw_notify_cb_ex>, uvw_timer
{
public:
    virtual void timer_cb() {}
};

// /////////////////////////////////////////////////////////////////////////////////// //
//server examples
class uvw_notify_cb_svr : public uvw_notify_cb_ex
{
    //通知回调管理器进行释放..
    virtual void will_close() { uvw_notify_cb_mgr::Instance()->push_item(this); }
    virtual bool is_can_free() { return true; }  //cb member will free by uvw_notify_cb_mgr..
};

class my_tcp_svr : public uvw_tcp_svr
{
public:
    my_tcp_svr(uv_loop_t *loop_t) : uvw_tcp_svr(loop_t) {}

public:
    virtual void new_instance_cb(uvw_tcp_instance *instance) {
        instance->set_notify_cb(new uvw_notify_cb_svr);
    }
};

//#######################################################################

int main()
{
    uvw_loop_mgr::Instance()->start_loop_task_thread(10);

#if 1
    uvw_notify_cb_mgr::Instance()->start_free();
    uvw_loop loop;
    my_tcp_svr svr(loop.get_loop_t());
    svr.bind_v4("127.0.0.1", 4500, 0);
    svr.listen(10);
    loop.run();

    uvw_loop_mgr::Instance()->join();
    uvw_notify_cb_mgr::Instance()->stop_free();
#else
    Sleep(3000);
    uvw_tcp_clt<uvw_notify_cb_ex> client(uvw_loop_mgr::Instance()->get_free_loop_t());
    if(client.connect_v4("127.0.0.1", 4500))
    {
        char *reack = new char[15];
        memcpy(reack, "aaaaaaadddddaaaaa", 15);

        client.write_to_cache(reack, 15);
        client.read_start();

        while(true){
            Sleep(1000);
            client.write_if_has_data();
        }
    }

    uvw_loop_mgr::Instance()->join();
#endif
}


#endif
