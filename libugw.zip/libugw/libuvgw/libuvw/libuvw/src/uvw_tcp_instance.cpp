
#include "uvw_tcp_instance.h"
#include "uvw_loop.h"
#include "uvw_loop_mgr.h"
#include "assert.h"
#include "uvw_notify_cb.h"
#include "uvw_data.h"
#include "uvw_def.h"
#include "dbg/uvw_tmp_log.h"


// //////////////////////////////////////////////////////////////////////////////////////// //
// //////////////////////////////////////////////////////////////////////////////////////// //
//
uvw_tcp_instance::uvw_tcp_instance(uv_loop_t *loop_t) : uvw_timer_heartbeat(loop_t)
{
    init((uv_loop_t*)loop_t);
}

uvw_tcp_instance::~uvw_tcp_instance()
{
    close();
}

void uvw_tcp_instance::init(uv_loop_t *loop_t)
{
    m_is_writing = false;
    m_instance = new uv_tcp_t;
    m_instance->data = this;
    uv_tcp_init(loop_t, m_instance);

    m_notify_cb = 0;
    m_can_close = false;

    m_timeout_cnt = 3;
}

void uvw_tcp_instance::heartbeat()
{
    start_timer(UVW_TIMER_START_MS, UVW_TIMER_REPEAT_MS);
}

void uvw_tcp_instance::close()
{
    if(m_instance == 0)
        return;

    uv_tcp_t *tcp_ptr_t = m_instance;
    m_instance = 0;

    stop_timer();
    uv_read_stop((uv_stream_t*)(tcp_ptr_t));

    //note:
    //清除 CB 的数据及值, 但不释放, 释放由 CB 自己内部决定!!
    //实际 CB 在 will_close 将自己添加到 cb_mgr 来释放!!!
    if(m_notify_cb)
    {
        m_notify_cb->remove_all();
        m_notify_cb->will_close();
        m_notify_cb = 0;
    }

    //socket of server create, dont need uv_shutdown//
    uv_close((uv_handle_t*)(tcp_ptr_t), [](uv_handle_t* handle) {
        uv_tcp_t *tcp_t = (uv_tcp_t*)handle;
        if(tcp_t)
        {
            uvw_tcp_instance *instance = (uvw_tcp_instance*)handle->data;
            if(instance) instance->m_can_close = true;
            delete tcp_t;
        }
    });
}

void uvw_tcp_instance::shutdown()
{
    uv_shutdown_t *sdt = new uv_shutdown_t;
    sdt->data = this;

    uv_stream_t* tcp_ptr_t = (uv_stream_t*)m_instance;
    uv_shutdown(sdt, tcp_ptr_t, [](uv_shutdown_t* req, int status) {
        uvw_tcp_instance* instance = (uvw_tcp_instance*)(req->data);
        if(instance)
            instance->close();

        delete req;
    });
}

bool uvw_tcp_instance::write_if_has_data()
{
    //2020.5.10 注:
    //write_if_has_data 的调用与 read_start 是在同一线程;
    //原因看 uvw_loop_async::async_send;
    uvw_notify_cb *notify_cb = m_notify_cb;
    if(notify_cb)
    {
        if(uv_is_writable((uv_stream_t*)(m_instance)))
        {
            uvw_buffer_ptr ptr = notify_cb->take_header();
            if(ptr)
            {
                write_to_uv(ptr->buffer, ptr->size);
                ptr->detach();
                return true;
            }
        }
    }

    return false;
}

bool uvw_tcp_instance::write_buffer(char* data, int size)
{
    uvw_notify_cb *notify_cb = m_notify_cb;
    if(notify_cb)
    {
        uvw_buffer_ptr wptr = std::make_shared<uvw::comm_buffer>();
        wptr->attach((char*)data, size);
        notify_cb->push_item(wptr);
        return true;
    }

    return false;
}

bool uvw_tcp_instance::write_buffer(std::string str)
{
    char *buffer = new char[str.size()];
    return write_buffer(buffer, str.size());
}

bool uvw_tcp_instance::write_to_uv(char* data, int size)
{
    uvw_write_t *req = (uvw_write_t*)(new uvw_write_t);
    req->buf = uv_buf_init(data, size);
    req->req.data = this;

    m_is_writing = true;
    int ret = uv_write((uv_write_t*)req, (uv_stream_t*)(m_instance), &req->buf, 1, [](uv_write_t *req, int status)
    {
        uvw_write_t *uvw_req = (uvw_write_t*)(req);
        if(uvw_req)
        {
            uvw_tcp_instance *instance = (uvw_tcp_instance*)req->data;
            if(status < 0)
            {
                //if(instance) instance->close();
            }
            else
            {
                if(instance)
                {
                    uvw_notify_cb *notify_cb = instance->m_notify_cb;
                    if(notify_cb)
                    {
                        notify_cb->write_finished(status);
                        //instance->write_if_has_data(); //2020-11-23, Comment out this line code
                    }
                }
            }

            //if(uvw_req->buf.len>0)
            delete []uvw_req->buf.base;
            delete uvw_req;

            instance->m_is_writing = false;
        }
    });

    return ret==0;
}

void uvw_tcp_instance::read_start()
{
    uv_read_start((uv_stream_t*)(m_instance), [](uv_handle_t *handle, size_t suggested_size, uv_buf_t *buf){
        uvw_tcp_instance *instance = (uvw_tcp_instance*)handle->data;
        if(instance)
        {
            uvw_notify_cb *notify_cb = instance->m_notify_cb;
            tmp_assert(notify_cb);

            uvw_notify_cb::cb_buffer cbuf;
            notify_cb->prepare_buffer(cbuf);

            buf->base = cbuf.buf_pos;
            buf->len  = cbuf.buf_size;
        }
        return;
    },
    [](uv_stream_t *client, ssize_t nread, const uv_buf_t *buf)
    {
        uvw_tcp_instance *instance = (uvw_tcp_instance*)client->data;
        if (nread > 0)
        {
            if(instance)
            {
                uvw_notify_cb *notify_cb = instance->m_notify_cb;
                if(notify_cb)
                {
                    notify_cb->read_finished(buf->base, nread);
                    //instance->write_if_has_data();

                    if(instance->m_timeout_cnt<3)
                        instance->m_timeout_cnt = 3;
                }
            }
        }
        else if (nread < 0)
        {
            if(instance)
            {
                instance->close();
            }
        }
    });
}


// ////////////////////////////////////////////////////////////////////////////////////////// //
//
void uvw_tcp_instance::timer_cb()
{
    m_timeout_cnt--;
    if(m_timeout_cnt<=0)
    {
        shutdown();
        return;
    }

    if(m_notify_cb->is_close_bits())
    {
        shutdown();
    }
}

