
#include "uvw_idler.h"
#include "uvw_loop.h"
#include "uvw_loop_mgr.h"


void wait_for_a_idler(uv_idle_t* handle)
{
    uvw_idler *idler = (uvw_idler*)(handle->data);
    if(idler)
    {
        idler->wait_for_idler();
    }
}

uvw_idler::~uvw_idler()
{
    if(m_idler_t)
        stop_idler();
}

void uvw_idler::start_idler(uv_loop_t *loop_t)
{
    init(loop_t);
    uv_idle_start(m_idler_t, wait_for_a_idler);
}

void uvw_idler::stop_idler()
{
    uv_idle_stop(m_idler_t);
    close();
}

void uvw_idler::init(uv_loop_t *loop_t)
{
    if(loop_t == 0)
        loop_t = uvw_loop_mgr::Instance()->get_loop_t( uvw_thread_id() );

    if(loop_t)
    {
        m_idler_t = new uv_idle_t;
        m_idler_t->data = this;
        uv_idle_init(loop_t, m_idler_t);
    }
}

void uvw_idler::close()
{
    //uv_close 前不能释放 m_timer_t;
    //uv_close 会将相应句柄从 loop 的 handle queue 中移除, 此时才能确保不对指定 _t 内容进行访问, 才允许释放..
    uv_close((uv_handle_t*)(m_idler_t), [](uv_handle_t* handle) {
        uv_idle_t* idler_t = (uv_idle_t*)(handle);
        if(idler_t) delete idler_t;
    });

    m_idler_t = 0;
}
