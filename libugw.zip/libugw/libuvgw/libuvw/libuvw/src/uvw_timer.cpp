
#include "uvw_timer.h"
#include "uvw_loop.h"
#include "uvw_loop_mgr.h"


void timer_callback(uv_timer_t *handle)
{
    uvw_timer *timer = (uvw_timer*)(handle->data);
    if(timer)
        timer->timer_cb();
}

uvw_timer::uvw_timer()
{
    uv_loop_t *loop_t = uvw_loop_mgr::Instance()->get_loop_t( uvw_thread_id() );
    if(loop_t)
    {
        init(loop_t);
    }
}

uvw_timer::uvw_timer(uv_loop_t *loop_t)
{
    m_timer_t = 0;

    if(loop_t) {
        init(loop_t);
    }
}

void uvw_timer::init(uv_loop_t *loop_t)
{
    m_is_start = false;

    m_timer_t = new uv_timer_t;
    m_timer_t->data = this;
    uv_timer_init(loop_t, m_timer_t);
}

bool uvw_timer::has_init()
{
    if(m_timer_t) {
        return m_timer_t->loop != 0;
    }

    return false;
}

uvw_timer::~uvw_timer()
{
    if(m_timer_t == 0)
        return;

    if(m_is_start)
    {
        m_is_start = false;
        stop_timer();
    }

    //uv_close 前不能释放 m_timer_t;
    //
    //uv_close 会将 timer 句柄 标记为移除, 导致 loop 在下一次循环时将句柄从 handle queue 中移除,
    //此时才能确保不对指定 uv_timer_t 内容进行访问, 才允许释放..
    //
    //unix: uv_close --> uv__timer_close --> uv_timer_stop;
    //win : uv_close --> uv_timer_stop;
    //即 uv_close 将主动停止定时器, 并标记其为移除(UV_HANDLE_CLOSING).
    //
    uv_timer_t *timer_t = m_timer_t;
    m_timer_t = 0;
    uv_close((uv_handle_t*)(timer_t), [](uv_handle_t* handle) {
        uv_timer_t* timer = (uv_timer_t*)(handle);
        if(timer) delete timer;
    });
}

void uvw_timer::start_timer(int fts, int repeat)
{
    uv_timer_start(m_timer_t, timer_callback, fts, repeat);
}

void uvw_timer::stop_timer()
{
    //除第一次调用成功外, 其余将直接被 uv__is_active 返回..
    uv_timer_stop(m_timer_t);
}
