
#include "uvw_tools.h"
#include <thread>
#include <chrono>
#include <time.h>


static uvw_share::big_endian m_cpu_is_big;

void uvw_tools::ms_sleep(long ms)
{
    std::chrono::milliseconds dura(ms);
    std::this_thread::sleep_for(dura);
}

long uvw_tools::get_now_ms()
{
#ifdef Q_OS_WIN
    long tick_per_ms = CLOCKS_PER_SEC/1000;
    clock_t cur_tms = clock()/tick_per_ms;
    return cur_tms;
#else
    //CLOCK_REALTIME 统当前时间，从1970年1.1日算起
    //CLOCK_MONOTONIC 系统的启动时间，不能被设置
    //CLOCK_PROCESS_CPUTIME_ID 本进程运行时间
    //CLOCK_THREAD_CPUTIME_ID 本线程运行时间
    //
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return(ts.tv_sec*1000 + ts.tv_nsec/1000000);
#endif
}

bool uvw_tools::is_big_endian()
{
    return m_cpu_is_big.is_big_endian();
}
