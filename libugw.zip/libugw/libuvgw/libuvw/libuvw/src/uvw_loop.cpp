
#include "uvw_loop.h"
#include <thread>
#include <uvw_tools.h>
#include "uvw_crash_core.h"


uvw_loop::uvw_loop()
{
    m_loop_t = (uv_loop_t*)malloc(sizeof(uv_loop_t));
    uv_loop_init(m_loop_t);
}

uvw_loop::uvw_loop(uv_loop_t *loop)
{
    if(loop)
        m_loop_t = loop;
    else
    {
        m_loop_t = (uv_loop_t*)malloc(sizeof(uv_loop_t));
        uv_loop_init(m_loop_t);
    }
}

void uvw_loop::close()
{
    if(m_loop_t)
    {
        uv_loop_close(m_loop_t);
        free(m_loop_t);
        m_loop_t = 0;
    }
}

uvw_loop::~uvw_loop()
{
    close();
}

void uvw_loop::run()
{
#ifdef Q_OS_WIN
    __try {
        uv_run(m_loop_t, UV_RUN_DEFAULT);
    }
    __except(unhandled_exception_filter(GetExceptionInformation()))
    {
    }
#else
    try {
        uv_run(m_loop_t, UV_RUN_DEFAULT);
    }
    catch(...)
    {
    }
#endif
    close();
}

void uvw_loop::stop()
{
    uv_stop(m_loop_t);
}
//
// //////////////////////////////////////////////////////////////////////////// //
// //////////////////////////////////////////////////////////////////////////// //
//
void uvw_loop_idler::wait_for_idler()
{
    m_once_lists.event_start(m_loop_t);

    bool has_write = m_call_lists.event_handler();
    if(!has_write)
        uvw_tools::ms_sleep(1);
}

void uvw_loop_idler::run()
{
    uvw_loop::run();

    //wait std::thread quit..
    uvw_tools::ms_sleep(2000);
}
//
// //////////////////////////////////////////////////////////////////////////// //
//
uvw_loop_async::uvw_loop_async()
{
    m_loop_t->data = this;
}

void uvw_loop_async::wait_for_idler()
{
    async_read();
    async_send();
}

void uvw_loop_async::async_read()
{
    //理论上 close 事件, 必须与 read_start 在同一线程触发!!!
    m_ready_lists.erase_invalid_instance();
    m_ready_lists.async_read_start();
}

void uvw_loop_async::async_send()
{
    m_async_lists.erase_invalid_instance();

    bool has_write = m_async_lists.async_send();
    if(!has_write)
        uvw_tools::ms_sleep(1);
}

void uvw_loop_async::run()
{
    uvw_loop::run();

    //wait std::thread quit..
    uvw_tools::ms_sleep(3000);
}
