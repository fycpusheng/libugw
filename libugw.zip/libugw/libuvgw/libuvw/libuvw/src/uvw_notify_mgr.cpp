
#include "uvw_notify_mgr.h"
#include "uvw_tools.h"
#include "uvw_notify_cb.h"
#include <thread>


void uvw_notify_cb_lists::free()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    std::list<uvw_notify_cb*>::iterator iter = m_notify_cb_mgr.begin();
    while(iter != m_notify_cb_mgr.end())
    {
        uvw_notify_cb* notify_cb = (*iter);
        if(notify_cb && notify_cb->is_can_free())
        {
            iter = m_notify_cb_mgr.erase(iter);
            delete notify_cb;
        }
        else
            iter++;
    }
}

uvw_notify_cb_mgr  g_uvw_notify_cb_mgr;
uvw_notify_cb_mgr* uvw_notify_cb_mgr::Instance()
{
    return &g_uvw_notify_cb_mgr;
}


void uvw_notify_cb_mgr::start_free()
{
    std::thread([=]() {
        while(!m_bquit)
        {
            uvw_tools::ms_sleep(1500);
            free();
        }
    }).detach();
}
