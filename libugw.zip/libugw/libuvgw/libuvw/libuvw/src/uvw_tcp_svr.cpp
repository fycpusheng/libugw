
#include "uvw_tcp_svr.h"
#include "uvw_loop_mgr.h"
#include "uvw_loop.h"
#include "assert.h"
#include "uvw_tcp_instance.h"


struct uvw_svr_data
{
    void* this_ptr;
    void* loop_ptr;

    uvw_svr_data(void *tptr)
    {
        this_ptr = tptr;
        loop_ptr = 0;
    }

    uvw_svr_data(void *tptr, void* lptr)
    {
        this_ptr = tptr;
        loop_ptr = lptr;
    }
};

uvw_tcp_svr::uvw_tcp_svr()
{
    m_is_v4 = true;
    uv_loop_t *loop_t = uvw_loop_mgr::Instance()->get_loop_t( uvw_thread_id() );
    if(loop_t)
    {
        init(loop_t);
        m_loop_mgr = uvw_loop_mgr::Instance();
    }
    else
        assert(false);
}

uvw_tcp_svr::uvw_tcp_svr(uv_loop_t *loop_t)
{
    init(loop_t);
    m_loop_mgr = uvw_loop_mgr::Instance();
}

void uvw_tcp_svr::init(uv_loop_t *loop_t)
{
    m_server = new uv_tcp_t;
    m_server->data = new uvw_svr_data(this, loop_t);
    uv_tcp_init(loop_t, m_server);
}

uvw_tcp_svr::~uvw_tcp_svr()
{
    close();
}

// //////////////////////////////////////////////////////////////////////////////////////////////////// //
//
void uvw_tcp_svr::close()
{
    if(m_server)
    {
        uvw_svr_data *sdata = (uvw_svr_data*)(m_server->data);
        if(sdata) delete sdata;

        uv_close((uv_handle_t*)(m_server), [](uv_handle_t* handle) {
            if(handle) delete handle;
        });

        m_server = 0;
    }
}

bool uvw_tcp_svr::bind_v4(std::string ipstr, int port, unsigned int flags)
{
    m_is_v4 = true;
    uv_ip4_addr(ipstr.data(), port, &m_addr_v4);
    return (uv_tcp_bind(m_server, (const struct sockaddr*)&m_addr_v4, flags) == 0);
}

bool uvw_tcp_svr::bind_v6(std::string ipstr, int port, unsigned int flags)
{
    m_is_v4 = false;
    uv_ip6_addr(ipstr.data(), port, &m_addr_v6);
    return (uv_tcp_bind(m_server, (const struct sockaddr*)&m_addr_v6, flags) == 0);
}

void uvw_tcp_svr::listen_accept_connect_cb(void* loop_caller)
{
    uv_stream_t* server = (uv_stream_t*)m_server;
    uv_loop_t *loop_t = (uv_loop_t*)(loop_caller);
    uvw_tcp_instance *instance = new uvw_tcp_instance(loop_t);
    if (uv_accept(server, (uv_stream_t*)(instance->get_instance())) == 0)
    {
        new_instance_cb(instance);

        uvw_loop* tloop_ptr = (uvw_loop*)(loop_caller);
        uvw_loop_async* async_ptr = dynamic_cast<uvw_loop_async*>(tloop_ptr);
        if(async_ptr)
        {
            async_ptr->m_async_lists.push_item(instance);
            async_ptr->m_ready_lists.push_item(instance);
        }
        else {
            instance->read_start();
        }
    }
    else
    {
        instance->close();
        delete instance;
    }
}

void uvw_tcp_svr::listen_accept_connect_cb()
{
    uvw_loop_mgr* loop_mgr = get_loop_mgr();
    if(loop_mgr)
    {
        uv_stream_t* server = (uv_stream_t*)m_server;
        if(loop_mgr->is_svr_mode())
        {
            uvw_loop_async *loop_ptr = (uvw_loop_async*)(loop_mgr->get_free_loop());
            uvw_tcp_instance *instance = new uvw_tcp_instance(loop_ptr->get_loop_t());
            if (uv_accept(server, (uv_stream_t*)(instance->get_instance())) == 0)
            {
                new_instance_cb(instance);
                loop_ptr->m_async_lists.push_item(instance);
                loop_ptr->m_ready_lists.push_item(instance);
            }
            else
            {
                instance->close();
                delete instance;
            }
        }
        else
        {
            uvw_loop *loop_ptr = (uvw_loop*)(loop_mgr->get_free_loop());
            uvw_tcp_instance *instance = new uvw_tcp_instance(loop_ptr->get_loop_t());
            if (uv_accept(server, (uv_stream_t*)(instance->get_instance())) == 0)
            {
                new_instance_cb(instance);
                instance->read_start();
            }
            else
            {
                instance->close();
                delete instance;
            }
        }
    }
}

bool uvw_tcp_svr::listen(int backlog)
{
    int r = uv_listen((uv_stream_t*) m_server, backlog, [](uv_stream_t* server, int status) {
        //client;;
        uvw_svr_data *sdata = (uvw_svr_data*)(server->data);
        if(sdata)
        {
            uvw_tcp_svr *svr_t = (uvw_tcp_svr*)(sdata->this_ptr);
            if(svr_t) {
#ifdef Q_OS_WIN
                svr_t->listen_accept_connect_cb();
#else
                svr_t->listen_accept_connect_cb(sdata->loop_ptr);
#endif
            }
        }
    });

    if(r!=0) {
        close();
    }

    return (r==0);
}

#if 0
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#define container_of(ptr, type, member)  ({ const typeof( ((type *)0)->member ) *__mptr = (ptr);  (type *)( (char *)__mptr - offsetof(type,member) ); })
#endif
