#include "uvw_thread.h"

uvw_thread::uvw_thread()
{
    m_tid = 0;
}

void uvw_thread::start(uvw_thread_cb cb, void *param)
{
    uv_thread_create(&m_tid, cb, param);
}

void uvw_thread::join()
{
    uv_thread_join(&m_tid);
}
