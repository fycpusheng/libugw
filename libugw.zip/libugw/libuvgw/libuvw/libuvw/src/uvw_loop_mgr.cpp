
#include "uvw_loop_mgr.h"
#include "uvw_loop.h"
#include "uvw_tools.h"

// /////////////////////////////////////////////////////////////////////////// //
//
uvw_loop_mgr  g_uvw_loop_mgr;
uvw_loop_mgr* uvw_loop_mgr::Instance()
{
    return &g_uvw_loop_mgr;
}

void uvw_loop_mgr::start_loop_task_thread(int trds)
{
    int run_trd_num = 0;

    m_is_svr_mode = true;
    for(int i=0; i<trds; i++)
    {
        bool id_ok = false;
        uvw_thread_t trd_id;
        std::thread* trd_obj = new std::thread([=, &run_trd_num, &trd_id, &id_ok]()
        {
            uvw_loop_async loop;
            loop.start_idler();

            uvw_thread_t tid = uvw_thread_id();
            push_loop_item(tid, &loop);

            trd_id = tid;
            id_ok = true;
            run_trd_num++;

            loop.run();
            remove_loop_item(tid);

            std::thread* self = m_group_threads.get_item(tid);
            m_group_threads.erase_item(tid);

            if(self) {
                self->detach();
                delete self;
            }
        });

        while(!id_ok) uvw_tools::ms_sleep(2);
        m_group_threads.push_item(trd_id, trd_obj);
    }

    while(run_trd_num<trds) uvw_tools::ms_sleep(50);
}


// /////////////////////////////////////////////////////////////////////////// //
// /////////////////////////////////////////////////////////////////////////// //
//
void uvw_loop_lists::start_loop_thread(int trds)
{
    //notice:
    //here, svr_mode must be false
    m_is_svr_mode = false;

    int run_trd_num = 0;
    for(int i=0; i<trds; i++)
    {
        bool id_ok = false;
        uvw_thread_t trd_id;
        std::thread* trd_obj = new std::thread([=, &run_trd_num, &trd_id, &id_ok]()
        {
            uvw_loop_idler loop;
            loop.start_idler();

            uvw_thread_t tid = uvw_thread_id();
            push_loop_item(tid, &loop);

            trd_id = tid;
            id_ok = true;
            run_trd_num++;

            //若 uv_run 没有事件, 将会自动退出;
            loop.run();
            remove_loop_item(tid);

            std::thread* self = m_group_threads.get_item(tid);
            m_group_threads.erase_item(tid);

            if(self) {
                self->detach();
                delete self;
            }
        });

        while(!id_ok) uvw_tools::ms_sleep(2);
        m_group_threads.push_item(trd_id, trd_obj);
    }

    while(run_trd_num<trds) uvw_tools::ms_sleep(50);
}

void uvw_loop_lists::stop_loops()
{
    std::lock_guard<std::mutex> lg(m_mutex);
    uvw_loop_map::iterator iter = m_loop_lists.begin();
    while(iter != m_loop_lists.end())
    {
        uvw_loop *loop_ptr = (uvw_loop*)(iter->second);
        if(loop_ptr) loop_ptr->stop();
        iter++;
    }
}

void uvw_loop_lists::join()
{
    if(m_group_threads.size()>0)
        uvw_tools::ms_sleep(2);
}

uvw_loop* uvw_loop_lists::get_loop(uvw_thread_t tid)
{
    std::lock_guard<std::mutex> lg(m_mutex);
    uvw_loop_map::iterator iter = m_loop_lists.find(tid);
    if(iter != m_loop_lists.end())
    {
        return (uvw_loop*)iter->second;
    }

    return 0;
}

uvw_loop* uvw_loop_lists::get_loop(uv_loop_t* lptr)
{
    uvw_loop_map::iterator iter = m_loop_lists.begin();
    while(iter != m_loop_lists.end())
    {
        uvw_loop *looptr = (uvw_loop*)iter->second;
        if(looptr)
        {
            if(looptr->get_loop_t() == lptr)
                return looptr;
        }

        iter++;
    }

    return 0;
}

uv_loop_t* uvw_loop_lists::get_loop_t(uvw_thread_t tid)
{
    uvw_loop *loop_t = get_loop(tid);
    if(loop_t)
        return loop_t->m_loop_t;

    return 0;
}

static uvw_loop* get_free_loop_by_size(uvw_loop_lists::uvw_loop_map &loops, unsigned int& cur_index)
{
    cur_index++;
    if(cur_index >= loops.size())
        cur_index = 0;

    uvw_loop_lists::uvw_loop_map::iterator iter = loops.begin();
    if(iter != loops.end())
    {
        for(int i=0; i<cur_index; i++)
            iter++;

        return (uvw_loop*)iter->second;
    }

    return 0;
}

uvw_loop* uvw_loop_lists::get_free_loop()
{
    std::lock_guard<std::mutex> lg(m_mutex);

    if(m_is_svr_mode)
    {
        int min_num = 0x7fffffff;
        uvw_loop_async *ret_loop = 0;

        uvw_loop_map::iterator iter = m_loop_lists.begin();
        while(iter != m_loop_lists.end())
        {
            uvw_loop_async *async_loop = dynamic_cast<uvw_loop_async*>(iter->second);
            if(async_loop)
            {
                int size = async_loop->m_async_lists.size();
                if(min_num>size)
                {
                    min_num = size;
                    ret_loop = async_loop;
                }
            }
            iter++;
        }

        return ret_loop;
    }

    return get_free_loop_by_size(m_loop_lists, m_load_index);
}

uv_loop_t* uvw_loop_lists::get_free_loop_t()
{
    uvw_loop *loop_t = get_free_loop();
    if(loop_t)
        return loop_t->m_loop_t;

    return 0;
}
