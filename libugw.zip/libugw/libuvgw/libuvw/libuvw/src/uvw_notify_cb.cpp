
#include "uvw_notify_cb.h"
#include "uvw_tools.h"


void uvw_notify_cb::push_pure(const char* data, int size)
{
    //allocate new buffer and copy data to it
    push_item(std::make_shared<uvw::comm_buffer>(data, size));
}

void uvw_notify_cb::push_item(uvw_buffer_ptr ptr)
{
    m_write_lists.push_item(ptr);
}

uvw_buffer_ptr uvw_notify_cb::take_header()
{
    return m_write_lists.take_header();
}

void uvw_notify_cb::remove_all()
{
    m_write_lists.remove_all();
}
