
#include "uvw_queue_work.h"
#include "uvw_loop_mgr.h"



static void work_func(uv_work_t* req)
{
    uvw_queue_work* work = (uvw_queue_work*)(req->data);
    if(work)
        work->work_cb(work->user_data());
}

static void after_work_func(uv_work_t* req, int status)
{
    uvw_queue_work* work = (uvw_queue_work*)(req->data);
    if(work)
        work->after_work_cb(work->user_data(), status);
}

// //////////////////////////////////////////////////////////////////////////////// //
//
uvw_queue_work::uvw_queue_work()
{
    m_work_t = new uv_work_t;
}

uvw_queue_work::~uvw_queue_work()
{
    if(m_work_t)
    {
        delete m_work_t;
        m_work_t = 0;
    }
}

void uvw_queue_work::work(uv_loop_t *loop_t, void *udata)
{
    m_udata = udata;
    m_work_t->data = this;
    uv_queue_work(loop_t, m_work_t, work_func, after_work_func);
}


