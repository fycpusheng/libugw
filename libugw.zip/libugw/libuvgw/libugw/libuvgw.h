
#ifndef UVGW_H
#define UVGW_H

#ifdef _WIN32
  /* Windows - set up dll import/export decorators. */
# if defined(BUILDING_UVGW_SHARED)
    /* Building shared library. */
#   define UVGW_EXTERN __declspec(dllexport)
# elif defined(USING_UVGW_SHARED)
    /* Using shared library. */
#   define UVGW_EXTERN __declspec(dllimport)
# else
    /* Building static library. */
#   define UVGW_EXTERN /* nothing */
# endif

#elif __GNUC__ >= 4
# define UVGW_EXTERN __attribute__((visibility("default")))
#else
# define UVGW_EXTERN /* nothing */
#endif

#endif
