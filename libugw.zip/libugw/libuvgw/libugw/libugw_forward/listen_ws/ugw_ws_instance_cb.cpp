#include "ugw_ws_instance_cb.h"
#include "uvw_tools.h"
#include <share_type_def.h>
#include <memory>


ugw_ws_instance_cb::ugw_ws_instance_cb()
{
    m_bin_had_bytes = 0;
    m_bin_cache_size = UVW_READ_BUFFER_MAX_LEN;
    m_bin_read_ptr = new char[m_bin_cache_size];
}

void ugw_ws_instance_cb::read_finished(const char *data, int size)
{
    if(m_had_bytes>0)
    {
        //prepare_buffer 已经把接收缓冲设置为 m_buffer_ptr + m_had_bytes!!!
        tmp_assert(size+m_had_bytes <= m_bin_cache_size);
        data = m_buffer_ptr;
        size += m_had_bytes;
    }

    if(m_ws.m_had_shake)
    {
        bool is_need_move = false;
        while(true)
        {
            if(m_ws.is_disconnect((unsigned char*)data, size))
            {
                ack_disconnect();
                break;
            }

            ws_size sz = { 1, 0, 0 };
            if(m_ws.parse_package_size((unsigned char*)data, size, sz))
            {
                int pack_size = sz.header_size + sz.data_size;

#ifdef ENABLE_GW_LARGE_PACKAGE_WAY
                //websocket 客户端的包大小不能超过3M!
                if(pack_size > 3*1024*1024) {
                    ack_disconnect();
                }

                //包大小, 大于缓存大小时, 更新内存大小!!
                if(pack_size > m_bin_cache_size )
                {
                    m_bin_cache_size = pack_size;
                    char* pNew = new char[m_bin_cache_size];
                    memcpy(pNew, m_bin_read_ptr, size);
                    delete []m_bin_read_ptr;
                    m_bin_read_ptr = pNew;
                }
#endif

                if(size >= pack_size)
                {
                    char* out_ptr = m_bin_read_ptr + m_bin_had_bytes;
                    if(m_ws.denpackage((unsigned char*)data, size, out_ptr)) {
                        if(sz.fin_code == 1) {
                            on_read_data(m_bin_read_ptr, sz.data_size);
                            m_bin_had_bytes = 0;
                        }
                        else {
                            m_bin_had_bytes += sz.data_size;
                        }
                    }

                    data += pack_size;
                    size -= pack_size;

                    if(!is_need_move)
                        is_need_move = true;

                    continue;
                }
            }

            break;
        }

        if(size>0)
        {
            m_had_bytes = size;
            if(is_need_move)
                memcpy(m_buffer_ptr, data, size);
        }
        else
            m_had_bytes = 0;
    }
    else
    {
        if(size > 50)
        {
            //握手应答的字段大小; 本程序只发了200多字节; 这里写 512 足够了!!
            int shake_size = 512;
            uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>(shake_size);
            ptr->size = m_ws.build_shake_buffer(data, ptr->data_ptr(), shake_size);
            uvw_notify_cb::push_item(ptr);

            m_ws.m_had_shake = true;
        }
    }
}

void ugw_ws_instance_cb::push_pure(const char* data, int size)
{
    int nsize = m_ws.enpackage_size(size, OPCODE_BINDATA);
    uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>(nsize);
    m_ws.enpackage_type(data, size, OPCODE_BINDATA, ptr->data_ptr(), ptr->size);
    uvw_notify_cb::push_item(ptr);
}

void ugw_ws_instance_cb::ack_disconnect()
{
    int nsize = m_ws.enpackage_size(0, OPCODE_DISCONN);
    uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>(nsize);
    m_ws.enpackage_type(0, 0, OPCODE_DISCONN, ptr->data_ptr(), ptr->size);
    uvw_notify_cb::push_item(ptr);
}

bool ugw_ws_instance_cb::is_can_free()
{
    return true;
}
