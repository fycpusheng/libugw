#ifndef UGW_WS_INSTANCE_CB_H
#define UGW_WS_INSTANCE_CB_H

#include "uvw_notify_cb.h"
#include "uvw_notify_mgr.h"
#include <vector>
#include <memory>
#include "ugw_ws_proto.h"
#include "../listen_c/uvw_gw_instance_cb.h"


class ugw_ws_instance_cb : public uvw_gw_instance_cb
{
public:
    ugw_ws_instance_cb();

public:
    virtual void read_finished(const char *data, int bytes);
    virtual bool is_can_free(); //cb member will free by uvw_notify_cb_mgr..

public:
    virtual void push_pure(const char* data, int size);

public:
    void ack_disconnect();

private:
    ugw_ws_proto m_ws;

    //m_bin_read_ptr: 解析数据后, 存储在此缓冲区中!!
    //m_bin_had_bytes: 已经读取的 websocket 缓冲数据!!!
    char* m_bin_read_ptr;
    int   m_bin_had_bytes;
    int   m_bin_cache_size;
};


#endif
