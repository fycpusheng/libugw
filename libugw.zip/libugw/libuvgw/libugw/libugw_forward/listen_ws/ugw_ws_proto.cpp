
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include "ugw_ws_proto.h"
#include "ugw_ws_proto.cc"


/**
* RFC6455 Websocket 帧格式, Payload data only accept UTF-8 octs.
* 0                   1                   2                   3
* 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
* +-+-+-+-+-------+-+-------------+-------------------------------+
* |F|R|R|R| opcode|M| Payload len |    Extended payload length    |
* |I|S|S|S|  (4)  |A|     (7)     |             (16/64)           |
* |N|V|V|V|       |S|             |   (if payload len==126/127)   |
* | |1|2|3|       |K|             |                               |
* +-+-+-+-+-------+-+-------------+ - - - - - - - - - - - - - - - +
* |     Extended payload length continued, if payload len == 127  |
* + - - - - - - - - - - - - - - - +-------------------------------+
* |                               |Masking-key, if MASK set to 1  |
* +-------------------------------+-------------------------------+
* | Masking-key (continued)       |          Payload Data         |
* +-------------------------------- - - - - - - - - - - - - - - - +
* :                     Payload Data continued ...                :
* + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
* |                     Payload Data continued ...                |
* +---------------------------------------------------------------+
*
*/


#define MAXRECVBUF_LEN     512
#define MAXSHAKE_ACK_LEN   512
#define MAXSHAKE_LEN       30



//websocket根据data[0]判别数据包类型; 比如0x81 = 0x80 | 0x1 为一个txt类型数据包!
// 0x0：标识一个中间数据包!!!
// 0x1：标识一个txt类型数据包!!
// 0x2：标识一个bin类型数据包!!
// 0x8：标识一个断开连接类型数据包!!
// 0x9：标识一个断开连接类型数据包!!
// 0xA：表示一个pong类型数据包!!
//typedef enum {
//    OPCODE_NULL = 0x00,
//    OPCODE_TXTDATA = 0x01,
//    OPCODE_BINDATA = 0x02,
//    //
//    //reserve, 3-7
//    OPCODE_03T07 = 0x07,
//    //
//    OPCODE_DISCONN = 0x08,
//    OPCODE_PING = 0x09,
//    OPCODE_PONG = 0x0A,
//    //reserve, 0B-0F
//    OPCODE_RESERVE = 0x0B
//}
//w_com_type;


#define PAYLOAD_WORD_FLAG   0x7E
#define PAYLOAD_LLONG_FLAG  0x7F



int ugw_ws_proto::tolower(int c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return c + 'a' - 'A';
    }

    return c;
}

int ugw_ws_proto::htoi(const char s[], int start, int len)
{
    int i, j;
    int n = 0;

    /*判断是否有前导0x或者0X*/
    if (s[0] == '0' && (s[1]=='x' || s[1]=='X')) {
        i = 2;
    } else {
        i = 0;
    }

    i += start;
    j = 0;
    for (; (s[i] >= '0' && s[i] <= '9') || (s[i] >= 'a' && s[i] <= 'f') || (s[i] >='A' && s[i] <= 'F');++i)
    {
        if(j>=len) {
            break;
        }

        if (tolower(s[i]) > '9') {
            n = 16 * n + (10 + tolower(s[i]) - 'a');
        } else {
            n = 16 * n + (tolower(s[i]) - '0');
        }
        j++;
    }

    return n;
}

//返回 build 的数据大小!!
//Access-Control-Allow-Origin: 若为 * 表示允许所有域的访问!!
//Access-Control-Allow-Credentials : 表示是否允许Cookie 包含在 CORS 请求中!!
//Access-Control-Allow-Methods : 资源访问时允许使用的 API 方法; HEAD/GET/POST/PUT; AND SO ON!!
//Access-Control-Allow-Headers : 服务器支持的字段!!
//注:
//Sec-WebSocket-Accept: %s\r\n 中 %s 后面不能带空格, 否则 QT PC 版本的 websocket 将无法识别!!
//wasm 版本, 后面带空格不受影响!!
//
//"Access-Control-Allow-Origin: *\r\n"
//"Access-Control-Allow-Credentials: false\r\n"
//"Access-Control-Allow-Methods: GET\r\n"
//"Access-Control-Allow-Headers: content-type\r\n"
//"Content-Encoding: gzip\r\n"
//"Sec-WebSocket-Protocol: binary\r\n"
int ugw_ws_proto::build_respone_header(char *shake_key, char *out_buf, int out_len)
{
    const char respone_header[] = "HTTP/1.1 101 Switching Protocols\r\n"
                                  "Upgrade: websocket\r\n"
                                  "Sec-WebSocket-Version: 13\r\n"
                                  "Connection: Upgrade\r\n"
                                  "Server: websocket_server\r\n"
                                  "Sec-WebSocket-Accept: %s\r\n"
                                  "Access-Control-Allow-Origin: *\r\n"
                                  "\r\n";
    const char guid[] = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    char shake_mix_key[MAXSHAKE_ACK_LEN] = {0};
    strcat(shake_mix_key, shake_key);
    strcat(shake_mix_key, guid);

    char sha1_data_temp[128] = {0,0};
    char sha1_data[128] = {0,0};
    int n, i;

    sha1_hash(shake_mix_key, sha1_data_temp, sizeof(sha1_data_temp));
    n = strlen(sha1_data_temp);

    for(i = 0; i < n; i += 2) {
        sha1_data[i/2] = htoi(sha1_data_temp, i, 2);
    }

    n = base64_encode((const ut8byte*)sha1_data, (char *)shake_mix_key, (n / 2));
    sprintf(out_buf, respone_header, shake_mix_key);

    return strlen(out_buf);
}

//函数作用: 解析 shake_buf,将值输出到 out 缓冲区, out_len 指定缓冲区大小!!
//返回值: 为应答的数据大小; <= 0 意味着失败!!
int ugw_ws_proto::build_shake_buffer(const char *shake_buf, char* out, int out_len)
{
    char *p;
    if ((p = strstr((char *)shake_buf, (const char *)"Sec-WebSocket-Key: ")) != 0)
    {
        /* 握手 */
        char shake_key[MAXSHAKE_LEN] = {0, 0};
        sscanf(p, "Sec-WebSocket-Key: %s\r\n", shake_key);
        return build_respone_header((char *)shake_key, (char *)out, out_len);
    }

    return 0;
}

bool ugw_ws_proto::is_disconnect(const unsigned char* data, int size)
{
    if(size<2)
        return false;

    return ((data[0] & OPCODE_DISCONN) == OPCODE_DISCONN);
}

//解析客户端包大小!!
bool ugw_ws_proto::parse_package_size(const unsigned char *data, int size, ws_size &sz)
{
    if(size < 2)
        return false;

    /* 第一位 fin */
    int fin_code = ((data[0] & 0x80) == 0x80);
    sz.fin_code = fin_code;

    //int is_bin_code = (data[0] & OPCODE_BINDATA) == OPCODE_BINDATA;

    /*是否包含掩码*/
    int mask_key_len = 0;
    int mask = (data[1] & 0x80) == 0x80;
    if(mask)
        mask_key_len = 4;

    /*数据长度*/
    //payload flag 仅有7位, 故,126/127两个数值具有特殊的含义:
    //小于126时, 直接用 flag 的7位来指定 payload 的长度;
    //否则用接下来的两个字节(flag==126)或8个字节(flag==127)指定 payload length!!
    int payload_len = 0;
    unsigned long payload_flag = data[1] & 0x7F;
    if(payload_flag == PAYLOAD_WORD_FLAG)
        payload_len = 2;
    else if(payload_flag == PAYLOAD_LLONG_FLAG)
        payload_len = 8;

    //头部2字节, 包含 FIN/x/x/x/opcode(4bit)/mask flag/payload flag(7bit)
    int header_size = 2 + payload_len + mask_key_len;
    if(size < header_size)
        return false;

    /* 数据长度 */
    int data_len = 0;
    if (payload_len == 2)
    {
        int len = data[2];
        data_len = (len << 8) + data[3];
    }
    else if (payload_len == 8)
    {
        //忽略前4位, 默认情况不可能传输这么大的单个数据包!!
        //data[2]/3/4/5
        int len = data[6];
        len = (len << 8) + data[7];
        len = (len << 8) + data[8];
        len = (len << 8) + data[9];
        data_len = len;
    }
    else
    {
        data_len = payload_flag;
    }

    //返回当前 websocket 的包大小!!
    sz.header_size = header_size;
    sz.data_size = data_len;

    return true;
}

bool ugw_ws_proto::denpackage(const unsigned char *recv_buf, int size, char *bin_data)
{
    if (size < 2) {
        return false;
    }

    /* 第一位fin */
    //int fin = (recv_buf[0] & 0x80) == 0x80;
    //if (!fin) {
    //    return false;
    //}

    /* 是否包含掩码 */
    int mask = (recv_buf[1] & 0x80) == 0x80;
    if (!mask)
        return false;

    unsigned char mask_key[4];
    memset(mask_key, 0, 4);

    /*数据长度*/
    unsigned long n, payload_len = recv_buf[1] & 0x7F;
    const unsigned char *payload_data = 0;
    if (payload_len == 126)
    {
        //mask offset pos, 4bytes;
        const unsigned char* mask_pos = (recv_buf + 4);
        memcpy(mask_key, mask_pos, 4);
        payload_len = ((int(recv_buf[2])) << 8) + recv_buf[3];

        //payload data offset
        payload_data = mask_pos + sizeof(mask_key);
    }
    else if (payload_len == 127)
    {
        //mask offset pos, 10bytes;
        const unsigned char* mask_pos = (recv_buf + 10);
        memcpy(mask_key, mask_pos, 4);

        int len = recv_buf[6];
        len = (len << 8) + recv_buf[7];
        len = (len << 8) + recv_buf[8];
        len = (len << 8) + recv_buf[9];

        payload_len = len;
        payload_data = mask_pos + sizeof(mask_key);
    }
    else
    {
        //mask offset pos, 2bytes;
        const unsigned char* mask_pos = (recv_buf + 2);
        memcpy(mask_key, mask_pos, 4);
        payload_data = mask_pos + sizeof(mask_key);
    }

    for(int i = 0; i < payload_len; i ++)
    {
        bin_data[i] = (char) (payload_data[i] ^ mask_key[i % 4]);
    }

    return true;
}

int ugw_ws_proto::enpackage_size(int data_len, int type)
{
    //此函数将 mask 设置为空!!
    //char mask_flag = 0x80;
    //int mask_key_len = 4;
    //
    char mask_flag = 0x00;
    int  mask_key_len = 0;
    //
    //payload flag 仅有7位, 故,126/127两个数值具有特殊的含义: 用来指定payload length!!
    int payload_len = 0;
    if(data_len >= 0xffff)
        payload_len = 8;
    else if(data_len >= 126)
        payload_len = 2;

    //头部2字节, 包含 FIN/x/x/x/opcode(4bit)/mask flag/payload flag(7bit)
    int need_len = 2 + payload_len + mask_key_len + data_len;
    return need_len;
}

//将用户数据构造成 ws 协议数据, 并填充到 buffer 中!!
int ugw_ws_proto::enpackage_type(const char* udata, int data_len, int type, char *buffer, int buffer_len)
{
    //*buffer++ = (0x80|type);
    switch(type)
    {
    case OPCODE_TXTDATA:
        *buffer++ = 0x81;
        break;
    case OPCODE_BINDATA:
        *buffer++ = 0x82;
        break;
    case OPCODE_PING:
        *buffer++ = 0x89;
        break;
    case OPCODE_PONG:
        *buffer++ = 0x8A;
        break;
    case OPCODE_DISCONN:
        *buffer++ = 0x88;
        break;
    }

    //此函数将 mask 设置为空!!
    //char mask_flag = 0x80;
    //int mask_key_len = 4;
    //
    char mask_flag = 0x00;
    int  mask_key_len = 0;
    //
    //payload flag 仅有7位, 故,126/127两个数值具有特殊的含义: 用来指定payload length!!
    int payload_len = 0;
    if(data_len >= 0xffff)
        payload_len = 8;
    else if(data_len >= 126)
        payload_len = 2;

    //头部2字节, 包含 FIN/x/x/x/opcode(4bit)/mask flag/payload flag(7bit)
    int need_len = 2 + payload_len + mask_key_len + data_len;
    if(buffer_len < need_len)
        return 0;

    if(data_len >= 0xffff)
    {
        *buffer++ = mask_flag|PAYLOAD_LLONG_FLAG;

        //函数仅发送4GB以内大小!!
        *buffer++ = 0;
        *buffer++ = 0;
        *buffer++ = 0;
        *buffer++ = 0;

        *buffer = (char)((data_len >> 24) & 0xFF);  buffer++;
        *buffer = (char)((data_len >> 16) & 0xFF);  buffer++;
        *buffer = (char)((data_len >> 8) & 0xFF);   buffer++;
        *buffer = (char)((data_len >> 0) & 0xFF);   buffer++;
        memcpy(buffer, udata, data_len);
    }
    else if(data_len >= 126)
    {
        *buffer++ = mask_flag|PAYLOAD_WORD_FLAG;

        *buffer = (char)((data_len >> 8) & 0xFF);   buffer++;
        *buffer = (char)((data_len >> 0) & 0xFF);   buffer++;
        memcpy(buffer, udata, data_len);
    }
    else {
        //小于126的长度, 直接赶往 payload flag!
        *buffer++ = mask_flag|data_len;

        //大小可能为0!!
        if(data_len > 0)
            memcpy(buffer, udata, data_len);
    }

    return need_len;
}

int ugw_ws_proto::enpackage(char *recv_text, char *send_buf)
{
    //send_buf length of 512
    int len = strlen(recv_text);
    return enpackage_type(recv_text, len, OPCODE_TXTDATA, send_buf, 512);
}

#if 0
int build_send_buf(char *recv_buf, char *send_buf)
{
    if(!m_had_shake)
    {
        if(build_shake_buffer(recv_buf, send_buf, MAXSHAKE_LEN)>0)
            m_had_shake = true;
    }
    else
    {
        char *recv_text = calloc(1, MAXRECVBUF_LEN);
        /*解包*/
        if (denpackage((char *)recv_buf, (char *)recv_text) == -1) {
            return -1;
        }
        int i;
        for (i = 0; i < strlen(recv_text); i ++) {
            recv_text[i] = toupper(recv_text[i]);
        }
        if (enpackage((char *)recv_text, (char *)send_buf) == -1) {
            return -1;
        }
        free(recv_text);
    }

    return 0;
}
#endif
