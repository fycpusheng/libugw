
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>


typedef enum {
    OPCODE_NULL = 0x00,
    OPCODE_TXTDATA = 0x01,
    OPCODE_BINDATA = 0x02,
    //
    //reserve, 3-7
    OPCODE_03T07 = 0x07,
    //
    OPCODE_DISCONN = 0x08,
    OPCODE_PING = 0x09,
    OPCODE_PONG = 0x0A,
    //reserve, 0B-0F
    OPCODE_RESERVE = 0x0B
}
OPCODE_TYPE;

struct ws_size
{
    int fin_code;
    int header_size;
    int data_size;
};

class ugw_ws_proto
{
    friend class ugw_ws_instance_cb;
private:
    bool  m_had_shake;

    //m_had_rbytes : 已读大小!!
    //m_pack_size  : 当前包大小!!
    int m_had_rbytes;
    int m_pack_size;


public:
    ugw_ws_proto() {
        m_had_shake = false;
        m_had_rbytes = 0;
        m_pack_size = 0;
    }

    ~ugw_ws_proto() {
    }

    int tolower(int c);
    int htoi(const char s[], int start, int len);

    //返回 build 的数据大小!!
    int build_respone_header(char *shake_key, char *out_buf, int out_len);

    //解析客户端包大小!!
    bool is_disconnect(const unsigned char* data, int size);
    bool parse_package_size(const unsigned char *data, int size, ws_size &sz);
    bool denpackage(const unsigned char *recv_buf, int size, char *bin_data);

    //将用户数据构造成 ws 协议数据, 并填充到 buffer 中!!
    int enpackage_size(int data_len, int type);
    int enpackage_type(const char *udata, int data_len, int type, char *buffer, int buffer_len);
    int enpackage(char *recv_text, char *send_buf);

    //函数作用: 解析 shake_buf,将值输出到 out 缓冲区, out_len 指定缓冲区大小!!
    //返回值: 为应答的数据大小; <= 0 意味着失败!!
    int build_shake_buffer(const char *shake_buf, char* out, int out_len);
};

