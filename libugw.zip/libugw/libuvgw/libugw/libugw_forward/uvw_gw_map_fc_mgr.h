#ifndef UVW_GW_INSTANCE_C_LISTS_H
#define UVW_GW_INSTANCE_C_LISTS_H

#include <memory>
#include <mutex>
#include <unordered_map>
#include <share_type_def.h>
#include "../libuvgw.h"


class uvw_gw_instance_cb;
class uvw_gw_instance_lists;
class uvw_gw_tcp_forward_mgr;


/* *********************************************************************************************
 * 服务器有多个, 根据功能的不同分为每个服务器定义一种类型, 每种类型的服务器都要创建一个 uvw_gw_tcp_forward_mgr,
 * uvw_gw_tcp_forward_mgr 的作用是:
 * 生成数个 forward客户端 到 业务服务器的链接, 为每个链接创建多个通道; 一个终端用户连接上来就为其分配一个通道!!
 * uvw_gw_tcp_forward_mgr 就是用来管理所有 forward客户端 到 某个业务服务器 的通道映射的;
 * ****************************************************************************************** */

/* *********************************************************************************************
 * forward_item:
 * 将 uvw_gw_instance_lists 与 uvw_gw_tcp_forward_mgr 绑定起来, 即将所有连接上来的客户与forward 通道绑定起来!!
 * ****************************************************************************************** */
struct forward_item
{
    uvw_gw_instance_lists *instance_lists = 0;
    uvw_gw_tcp_forward_mgr *forward_mgr = 0;
};


//READ_USER_DATA_HEADER_YTE 表示需要继续读取,至少要有头部大小的数据;
//CHECK_USER_DATA_HEADER_ERROR 表示已经有>= 头部大小的数据, 但检验错误, 需要关闭连接!!
#define  READ_USER_DATA_HEADER_YTE     -1
#define  CHECK_USER_DATA_HEADER_ERROR  -2


#ifndef  USE_SAME_AISLE_ID
#define  USE_SAME_AISLE_ID   1
#endif

// uvw_gw_map_fc_mgr:
// 此类最确切的命名应是: ** uvw_gw_instance_list_mgr ** 管理 client 到 forward 的映射.
//
typedef std::shared_ptr<forward_item> forward_item_ptr;
typedef std::unordered_map<int, forward_item_ptr>  uvw_to_forward_lists;
class UVGW_EXTERN uvw_gw_map_fc_mgr
{
public:
    static uvw_gw_map_fc_mgr *Instance();

public:
    forward_item_ptr new_forward_item(int fward_type);
    void clear_forward_item();

public:
    uvw_gw_tcp_forward_mgr *get_forward_mgr(int fward_type);

public:
    //添加到/移除从 所有的 forward item;
    void push_to_forward_item(uvw_gw_instance_cb *inst_ptr);
    void erase_from_forward_item(uvw_gw_instance_cb* inst_ptr);

    //server crash/server forbid client connect
    void close_client_because_of_svr_crash();
    void close_client_because_of_svr_forbid(int fward_type, st64 aisle_id);

public:
    //注: write_to_xx 将获得data的所有权并交给内部调用函数; 调用者不得再使用 data pointer..
    void write_to_client(int fward_type,  st64 aisle_id, const char *data, int size);
    void write_to_client2(int fward_type, st64 aisle_id, const char *data, int size);
    void write_to_forward(int fward_type, st64 aisle_id, const char *data, int size);

#ifndef  USE_SAME_AISLE_ID
    //通过客户端中已经存在的通道 ID, 获取已经存在的另一种类型的通道 ID !!
    //客户端为每个业务服务器(类型), 都创建了一个通道 ID!!
    //注: get_clt_asile_id 函数, 目前仅在一键登录时使用, 客户端只发一条登录指令即可!!
    st64 get_clt_asile_id(int fward_type,  st64 aisle_id, int get_type);
#endif

private:
    std::mutex m_mutex;
    uvw_to_forward_lists m_forward_lists;

// -- ------------------------------------------------------------------------ -- //
// -- ------------------------------------------------------------------------ -- //
// -- 用户需要设置的部分!!
public:
    //m_parse_integrality_ptr 用于检测客户发来的数据格式是否是完整包; 以决定包是否可以处理!!
    //m_parse_frward_ptr 用于检测数据要到达的目标服务器!!!
    //注: 拦截函数需要自己判断大小端, 并进行相关转换!!!
    //
    typedef int (*uvw_parse_forward_type_ptr)(const char *data, int size);
    typedef int (*uvw_parse_integrality_ptr)(const char *data, int size, int& pack_size);
    uvw_parse_forward_type_ptr m_parse_frward_ptr = 0;
    uvw_parse_integrality_ptr  m_parse_integrality_ptr = 0;

    uvw_parse_forward_type_ptr get_parse_frward_ptr()      { return m_parse_frward_ptr; }
    uvw_parse_integrality_ptr  get_parse_integrality_ptr() { return m_parse_integrality_ptr; }

    void set_parse_frward_ptr(uvw_parse_forward_type_ptr acc_ptr) {
        m_parse_frward_ptr = acc_ptr;
    }
    void set_parse_integrality_ptr(uvw_parse_integrality_ptr acc_ptr) {
        m_parse_integrality_ptr = acc_ptr;
    }

public:
    //用户部分的软件协议头的大小!!
    void set_proto_header_size(int sz) {
        m_proto_header_size = sz;
    }
    int proto_header_size() {
        return m_proto_header_size;
    }

protected:
    static int m_proto_header_size;

#ifdef LOGIN_BY_GETWAY_AGENT
public:
    //
    //向客户端的转发过滤; 反向代理隐藏了真实的服务器地址; 正向代理隐藏了客户端地址!!
    enum {  w_to_null, w_to_client, w_to_close };
    typedef int (*uvw_parse_to_client_type)(int fward_type, st64 aisle_id, const char *data, int size);

    uvw_parse_to_client_type get_parse_to_clt_ptr() { return m_parse_client_ptr; }
    void set_parse_to_clt_ptr(uvw_parse_to_client_type toc_ptr) {
        m_parse_client_ptr = toc_ptr;
    }
private:
    uvw_parse_to_client_type m_parse_client_ptr = 0;
#endif
// -- ------------------------------------------------------------------------ -- //
// -- ------------------------------------------------------------------------ -- //
};

#endif
