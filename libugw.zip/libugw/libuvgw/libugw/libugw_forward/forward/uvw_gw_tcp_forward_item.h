
#ifndef UVW_GW_TCP_FORWARD_ITEM_H
#define UVW_GW_TCP_FORWARD_ITEM_H

#include "uvw_gw_tcp_forward.h"
#include <list>
#include <unordered_map>
#include "uvw_loop_callback.hpp"


// /////////////////////////////////////////////////////////////////////////// //
// 说明:
// -- 用来控制每个转发sokcet 的通道数量, 及起始通道ID, 终止通道ID//
// -- 被 uvw_gw_tcp_forward_mgr 的私有类调用//
// /////////////////////////////////////////////////////////////////////////// //
//
struct uvw_gw_tcp_forward_item_base : public uvw_call_by_loop
{
    // -- ---------------------------------------------- -- //
    // derive/inherit
    virtual bool event_handler() = 0;
    virtual bool event_start(void* loop_caller) = 0;

protected:
    int m_port;
    std::string m_ip;
    uv_loop_t* m_loop_caller;

public:
    void set_addr(std::string ip, int port) {
        m_ip = ip;
        m_port = port;
    }

public:
    uv_loop_t* get_loop_t() { return m_loop_caller; }

    // -- ---------------------------------------------- -- //
public:
    uvw_gw_tcp_forward_item_base()  { m_loop_caller = 0; }
};

struct uvw_gw_tcp_forward_item : public uvw_gw_tcp_forward_item_base
{
    // -- ---------------------------------------------- -- //
    // derive/inherit
    virtual bool event_handler()
    {
        if(ptr)
        {
            if(ptr->is_connected()) {
                return ptr->write_if_has_data();
            }

            if(ptr->is_closed())
            {
                ptr = uvw_gw_tcp_client_ptr( new uvw_gw_tcp_forward((uv_loop_t*)m_loop_caller) );
                ptr->set_type(get_forward_type());
                ptr->connect_v4(m_ip, m_port);

                tmp_printf("create_connect_forward, forward type: %d", get_forward_type());
            }
        }
    }

    virtual bool event_start(void* loop_caller)
    {
        if(ptr == 0)
        {
            ptr = uvw_gw_tcp_client_ptr( new uvw_gw_tcp_forward((uv_loop_t*)loop_caller) );
            ptr->set_type(get_forward_type());
            ptr->connect_v4(m_ip, m_port);

            m_loop_caller = (uv_loop_t*)loop_caller;
        }

        return true;
    }

    // -- ---------------------------------------------- -- //
public:
    uvw_gw_tcp_forward_item()  { ptr = 0; fr_type = 0; user_num = 0; }

public:
    uvw_gw_tcp_client_ptr ptr;

private:
    std::unordered_map<st64, bool> free_status;
    st64 start_id;
    st64 end_id;
    int  user_num;

private:
    int   fr_type;

public:
    void set_forward_type(int type) {
        fr_type = type;
    }
    int  get_forward_type() {
        return fr_type;
    }

public:
    void init_aisle_id(st64 sid, st64 eid)
    {
        start_id = sid;
        end_id = eid;

        user_num = 0;
        while(sid <= eid)
        {
            free_status[sid] = false;
            sid++;
        }
    }

    void reinit_aisle_id()
    {
        st64 sid = start_id;
        st64 eid = end_id;

        user_num = 0;
        while(sid <= eid)
        {
            free_status[sid] = false;
            sid++;
        }
    }

    bool contain(st64 lid) {
        return (lid>=start_id) && (lid<=end_id);
    }

    //will mark aisle id
    st64 get_aisle_id()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        std::unordered_map<st64, bool>::iterator iter = free_status.begin();
        st64 free_id = 0;
        for(; iter != free_status.end(); iter++)
        {
            if(iter->second == false)
            {
                free_id = iter->first;
                iter->second = true;
                user_num++;
                break;
            }
        }

        return free_id;
    }

    //will mark aisle id
    bool get_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        bool bret = false;
        std::unordered_map<st64, bool>::iterator iter = free_status.begin();
        for(; iter != free_status.end(); iter++)
        {
            if(iter->first == aisle_id)
            {
                if(iter->second == false)
                {
                    iter->second = true;
                    user_num++;
                    bret = true;
                }
                break;
            }
        }

        return bret;
    }

    //wont mark aisle id
    st64 find_free_aisle_id()
    {
        std::lock_guard<std::mutex> lk(m_mutex);

        st64 free_id = 0;
        std::unordered_map<st64, bool>::iterator iter = free_status.begin();
        for(; iter != free_status.end(); iter++)
        {
            if(iter->second == false)
            {
                free_id = iter->first;
                break;
            }
        }

        return free_id;
    }

    bool is_free_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        std::unordered_map<st64, bool>::iterator iter = free_status.find(aisle_id);
        if(iter != free_status.end())
        {
            //iter->second : 指示通道是否占用; 故要取反!!!
            return (!iter->second);
        }

        return false;
    }

    void free_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        std::unordered_map<st64, bool>::iterator iter = free_status.find(aisle_id);
        if(iter != free_status.end())
        {
            user_num--;
            iter->second = false;
        }
    }

    void free_all_aisle_id()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        std::unordered_map<st64, bool>::iterator iter = free_status.begin();
        while(iter != free_status.end())
        {
            user_num--;
            iter->second = false;
            iter++;
        }
    }

    //(end_id - start_id) 没有 +1, 所以用 > 号..
    bool is_id_break()  { return user_num >(end_id - start_id); }

    int  get_start_id() { return start_id; }
    int  get_end_id()   { return end_id;   }
    int  get_user_num() { return user_num; }

private:
    std::mutex m_mutex;
};

typedef std::shared_ptr<uvw_gw_tcp_forward_item> uvw_gw_tcp_forward_item_ptr;
typedef std::list<uvw_gw_tcp_forward_item_ptr>   uvw_gw_tcp_forward_item_lists;


#endif
