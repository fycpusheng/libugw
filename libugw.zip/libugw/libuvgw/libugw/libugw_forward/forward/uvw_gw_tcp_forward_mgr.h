
#ifndef UVW_GW_TCP_CLIENT_MGR_H
#define UVW_GW_TCP_CLIENT_MGR_H

#include <list>
#include <unordered_map>
#include <share_type_def.h>
#include "../../libuvgw.h"


//uvw_gw_tcp_forward_mgr 说明:
// -- 每个 uvw_gw_tcp_forward_mgr 实例连接一个内网服务器, 并为客户端创建连接通道;;
//write_to_aisle :
// -- 客户端 有数据到来时, 通过 write_to_aisle 转发到 内网服务器的指定通道..
class uvw_gw_tcp_client_mgr_private;
class UVGW_EXTERN uvw_gw_tcp_forward_mgr
{
public:
    uvw_gw_tcp_forward_mgr();
    ~uvw_gw_tcp_forward_mgr();

public:
    //init_aisle_loop:
    //connet_num : 启动多少 socket 连接, 此处采用一个socket 一个线程, socket 不用多..
    //aisle_num  : 每个 socket 连接的 通道数量; 小于 0x7fffffff..
    void set_ip_port(std::string ip, int port);
    bool init_aisle_loop(int connet_num, int aisle_num);
    void join();

    void set_forward_type(int type) { m_forward_type = type; }
    void fix_error_forward();
    void fix_error_forward2();

public:
    void  write_to_aisle(st64 aisle_id, const char *buffer, int size);  //buffer will copy by make_gw_data
    st64  create_aisle_id(); //return value >0 if ok; else <0;
    bool  create_aisle_id(st64 aid);

    st64  find_free_aisle_id();
    bool  is_free_aisle_id(st64 aid);

    void  delete_aisle_id(st64 aisle_id);
    void  will_delete_aisle_id(st64 aisle_id);

private:
    uvw_gw_tcp_client_mgr_private *m_private;
    int  m_forward_type;
};


#endif
