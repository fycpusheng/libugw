
#ifndef  UVW_GW_TCP_CLIENT_H
#define  UVW_GW_TCP_CLIENT_H

#include "ugw_notify_cb.h"
#include "uvw_notify_cb.h"
#include "uvw_tcp_clt.h"
#include "uvw_timer.h"
#include "share_type_def.h"


// //////////////////////////////////////////////////////////////////////////
// ugw_notify_cb::is_can_free :
//
// cb 用在 uvw_tcp_clt 时, 是与 uvw_tcp_clt 完全绑定的, 随 uvw_tcp_clt 的释放而释放;
// 故未加入任何释放管理器, 而其返回值也没有被任何管理者使用, 即 此函数及其返回可以忽略!!!
// //////////////////////////////////////////////////////////////////////////
class uvw_notify_forward_cb : public ugw_notify_cb
{
public:
    uvw_notify_forward_cb() {
    }

public:
    virtual void on_read_data(const char *data, int size);
    virtual void will_close();
    virtual bool is_can_free() { return false; }

public:
    int  get_forward_type() { return m_forward_type; }
    void set_forward_type(int type) {
        m_forward_type = type;
    }

private:
    int  m_forward_type = -1;
};




// uvw_gw_tcp_forward: 被 uvw_gw_tcp_forward_item 封装使用//
// uvw_gw_tcp_forward --> uvw_gw_tcp_forward_item --> uvw_gw_tcp_forward_mgr //
class uvw_gw_tcp_forward : public uvw_tcp_clt, public uvw_timer
{
public:
    uvw_gw_tcp_forward(uv_loop_t *loop_t) : uvw_tcp_clt(loop_t), uvw_timer(loop_t) {
        m_loop_t = loop_t;
        attach_notify_cb(new uvw_notify_forward_cb);
    }

public:
    virtual void timer_cb();

public:
    virtual void on_connect_ok();

public:
    void send_create_aisle_cmd(st64 aisle_id);
    void send_delete_aisle_cmd(st64 aisle_id);

public:
    void set_type(int type)
    {
        uvw_notify_forward_cb* cb = dynamic_cast<uvw_notify_forward_cb*>(m_notify_cb);
        if(cb) cb->set_forward_type(type);
    }

public:
    void write_to_forward(char *data , int size)
    {
#define _FORWARD_QUEUE_CACHE_
#ifdef  _FORWARD_QUEUE_CACHE_
        write_to_cache(data, size);
#else
        write_to_socket(data, size);
#endif
    }

public:
    uv_loop_t* get_loop_t() {
        return m_loop_t;
    }

private:
    uv_loop_t* m_loop_t;
};

typedef std::shared_ptr<uvw_gw_tcp_forward> uvw_gw_tcp_client_ptr;


#endif
