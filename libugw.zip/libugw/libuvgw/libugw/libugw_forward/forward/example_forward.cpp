
#if 0

#include "uvw_gw_tcp_forward_mgr.h"

void main2(int argc, char **argv)
{
    uvw_gw_tcp_forward_mgr lg_table;
    uvw_gw_tcp_forward_mgr ly_table;

    lg_table.set_ip_port("127.0.0.1", 4500);
    lg_table.init_aisle_loop(20, 200);
    lg_table.join();

    //客户端连接上来时..
    //获取登录通道ID, 并发送数据..
    llong aisle_id = lg_table.get_free_aisle_id();
    lg_table.write_to_aisle(aisle_id, "aa", 2);
    lg_table.will_delete_aisle_id(aisle_id);

    //获取大厅通道ID, 并发送数据..
    aisle_id = ly_table.get_free_aisle_id();
    ly_table.write_to_aisle(aisle_id, "aa", 2);
    ly_table.will_delete_aisle_id(aisle_id);
}
#endif
