
#include "uvw_gw_tcp_forward_mgr.h"
#include <uvw_gw_data.h>
#include "uvw_gw_tcp_forward_item.h"
#include <thread>
#include <mutex>
#include "uvw_loop.h"
#include "uvw_tools.h"
#include "uvw_def.h"
#include <uvw_comm_buffer.h>
#include "uvw_loop_mgr.h"
#include <dbg/uvw_tmp_log.h>



class uvw_gw_tcp_client_mgr_private
{
private:
    std::mutex m_mutex;
    uvw_gw_tcp_forward_item_lists m_table_lists;

    std::string m_ip;
    int m_port;

private:
    uvw_loop_lists  m_loop_mgr;

public:
    void push_item(uvw_gw_tcp_forward_item_ptr ptr)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_table_lists.push_back(ptr);
    }

    void write_to_aisle(st64 aisle_id, const char *buffer, int size)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->contain(aisle_id))
            {
                if(item_ptr->ptr)
                {
                    //mark: 此处需要判断是否能够写入..
                    GW_Data::cts_gw_data *wdata = GW_Data::cts_gw_data::make_gw_data(aisle_id, (char*)buffer, size, uvw_tools::is_big_endian());
                    item_ptr->ptr->write_to_forward((char*)wdata, wdata->size);
                }
                break;
            }
        }
    }

    // -- ----------------------------------------------------------------------- -- //
    // -- ----------------------------------------------------------------------- -- //
public:
    bool wait_forward_connect_result()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); )
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->ptr)
            {
                if(!item_ptr->ptr->is_connected())
                    return false;
            }

            iter++;
        }

        return true;
    }

    ~uvw_gw_tcp_client_mgr_private()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); )
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr)
            {
                uvw_loop_idler* loop_ev = dynamic_cast<uvw_loop_idler*>(m_loop_mgr.get_loop(item_ptr->get_loop_t()));
                if(loop_ev)
                {
                    loop_ev->m_call_lists.remove_item(item_ptr.get());
                    loop_ev->m_once_lists.remove_item(item_ptr.get());
                }
            }
        }
    }
    // -- ----------------------------------------------------------------------- -- //
    // -- ----------------------------------------------------------------------- -- //
    // mark:
    // get_free_aisle_id 无须等待业务服务器的应答;
    // 若失败, 业务服务器收到客户端数据时, 会尝试再次创建不存在的通道;
    // 即 每次有数据, 若不存在对应通道, 业务服务器都会尝试创建, 故此处无须判断是否成功;
    //
    st64 get_free_aisle_id()
    {
        int min_members = 0x7fffffff;
        uvw_gw_tcp_forward_item_ptr min_ptr = 0;

        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && (!item_ptr->is_id_break()))
            {
                //获取最小用户数量的(aisle)通道 !!!
                if(item_ptr->get_user_num()<min_members)
                {
                    min_ptr = item_ptr;
                    min_members = item_ptr->get_user_num();
                }
            }
        }

        st64 new_aisle_id = 0;
        if(min_ptr)
        {
            new_aisle_id = min_ptr->get_aisle_id();
            min_ptr->ptr->send_create_aisle_cmd(new_aisle_id);
        }

        return new_aisle_id;
    }

    bool get_free_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->contain(aisle_id))
            {
                if(item_ptr->get_aisle_id(aisle_id))
                {
                    item_ptr->ptr->send_create_aisle_cmd(aisle_id);
                    return true;
                }

                return false;
            }
        }

        return false;
    }

    //仅查找, 不占用!!!
    st64 find_free_aisle_id()
    {
        int min_members = 0x7fffffff;
        uvw_gw_tcp_forward_item_ptr min_ptr = 0;

        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && (!item_ptr->is_id_break()))
            {
                //获取最小用户数量的(aisle)通道 !!!
                if(item_ptr->get_user_num()<min_members)
                {
                    min_ptr = item_ptr;
                    min_members = item_ptr->get_user_num();
                }
            }
        }

        st64 new_aisle_id = 0;
        if(min_ptr) {
            new_aisle_id = min_ptr->find_free_aisle_id();
        }

        return new_aisle_id;
    }

    bool is_free_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->contain(aisle_id))
            {
                if(item_ptr->is_free_aisle_id(aisle_id)) {
                    return true;
                }

                return false;
            }
        }

        return false;
    }

    void delete_aisle_id(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->contain(aisle_id))
            {
                item_ptr->free_aisle_id(aisle_id);
                break;
            }
        }
    }

    void delete_all_aisle_id()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr)
            {
                item_ptr->free_all_aisle_id();
                break;
            }
        }
    }

    //向内网服务端发送删除通道指令; 待确认后再执行 delete_aisle_id
    //具体看 uvw_notify_forward_cb::on_read_data 中对通道的处理!!
    void send_delete_aisle_cmd(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        uvw_gw_tcp_forward_item_lists::iterator iter = m_table_lists.begin();
        for(; iter != m_table_lists.end(); iter++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr = (*iter);
            if(item_ptr && item_ptr->contain(aisle_id))
            {
                item_ptr->ptr->send_delete_aisle_cmd(aisle_id);
                break;
            }
        }
    }

    int size()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        return m_table_lists.size();
    }

public:
    void set_ip_port(std::string ip, int port)
    {
        m_port = port;
        m_ip = ip;
    }

    void init_aisle_loop(int forward_type, int connet_num, int aisle_num)
    {
        //connect_v4/v6 必须先启动loop循环, 因为里面对connect 结果进行了等待!!!
        m_loop_mgr.start_loop_thread(connet_num);

        int per_numbers = aisle_num;
        for(int i=0; i<connet_num; i++)
        {
            uvw_gw_tcp_forward_item_ptr item_ptr(new uvw_gw_tcp_forward_item);
            item_ptr->set_forward_type(forward_type);
            item_ptr->init_aisle_id(per_numbers*i+1, per_numbers*(i+1));
            item_ptr->set_addr(m_ip, m_port);

            push_item(item_ptr);

            uvw_loop_idler* loop_ev = dynamic_cast<uvw_loop_idler*>(m_loop_mgr.get_free_loop());
            if(loop_ev)
            {
                loop_ev->m_once_lists.push_item(item_ptr.get());
                loop_ev->m_call_lists.push_item(item_ptr.get());
            }
        }
    }

    void join()
    {
        m_loop_mgr.join();
    }
};



uvw_gw_tcp_forward_mgr::uvw_gw_tcp_forward_mgr()
{
    m_private = new uvw_gw_tcp_client_mgr_private;
    m_forward_type = 0;
}

uvw_gw_tcp_forward_mgr::~uvw_gw_tcp_forward_mgr()
{
    if(m_private)
    {
        delete m_private;
        m_private = 0;
    }
}

void uvw_gw_tcp_forward_mgr::write_to_aisle(st64 aisle_id, const char* buffer, int size)
{
    m_private->write_to_aisle(aisle_id, buffer, size);
}

st64 uvw_gw_tcp_forward_mgr::create_aisle_id()
{
    return m_private->get_free_aisle_id();
}

bool uvw_gw_tcp_forward_mgr::create_aisle_id(st64 aid)
{
    return m_private->get_free_aisle_id(aid);
}

st64 uvw_gw_tcp_forward_mgr::find_free_aisle_id()
{
    return m_private->find_free_aisle_id();
}

bool uvw_gw_tcp_forward_mgr::is_free_aisle_id(st64 aid)
{
    return m_private->is_free_aisle_id(aid);
}

void  uvw_gw_tcp_forward_mgr::delete_aisle_id(st64 aisle_id)
{
    m_private->delete_aisle_id(aisle_id);
}

void  uvw_gw_tcp_forward_mgr::will_delete_aisle_id(st64 aisle_id)
{
    m_private->send_delete_aisle_cmd(aisle_id);
}

void uvw_gw_tcp_forward_mgr::join()
{
    m_private->join();
}

void uvw_gw_tcp_forward_mgr::set_ip_port(std::string ip, int port)
{
    m_private->set_ip_port(ip, port);
}

bool uvw_gw_tcp_forward_mgr::init_aisle_loop(int connet_num, int aisle_num)
{
    //每个链接的通道数, 小于 0x7fffffff;
    assert(aisle_num < 0x7fffffff);
    m_private->init_aisle_loop(m_forward_type, connet_num, aisle_num);

    for(int i=0; i<20; i++) {
        if(!m_private->wait_forward_connect_result())
            uvw_tools::ms_sleep(500);
    }

    return (m_private->wait_forward_connect_result()) && (connet_num == m_private->size());
}

void uvw_gw_tcp_forward_mgr::fix_error_forward()
{
}

void uvw_gw_tcp_forward_mgr::fix_error_forward2()
{
}

