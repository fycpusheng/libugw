#include "uvw_gw_tcp_forward.h"
#include <uvw_gw_data.h>
#include <thread>
#include <uvw_tools.h>
#include <dbg/uvw_tmp_log.h>
#include "uvw_gw_tcp_forward_mgr.h"
#include "../uvw_gw_map_fc_mgr.h"



void uvw_gw_tcp_forward::timer_cb()
{
    GW_Data::cts_gw_data *gw_data = GW_Data::cts_gw_data::make_gw_ping(uvw_tools::is_big_endian());
    write_to_forward((char*)gw_data, gw_data->size);

    //if(m_client && uv_is_writable((uv_stream_t*)(m_client)))
    //    tmp_printf(" time_cb, can writeable");
    //tmp_printf("time_cb, forward type : %d \r\n", m_notify_cb.get_forward_type());
    //
    //make: 在定时中发送数据队列, 使 RW 在同一个 loop 线程中!!
    //while(true) { if(!write_if_has_data()) break; }
}

void uvw_gw_tcp_forward::send_create_aisle_cmd(st64 aisle_id)
{
    GW_Data::cts_gw_data *gw_data = GW_Data::cts_gw_data::make_gw_cmd(aisle_id, cmd_gw_create_aisle, uvw_tools::is_big_endian());
    if(gw_data)
        write_to_forward((char*)gw_data, gw_data->size);
}

void uvw_gw_tcp_forward::send_delete_aisle_cmd(st64 aisle_id)
{
    GW_Data::cts_gw_data *gw_data = GW_Data::cts_gw_data::make_gw_cmd(aisle_id, cmd_gw_delete_aisle, uvw_tools::is_big_endian());
    if(gw_data)
        write_to_forward((char*)gw_data, gw_data->size);

    if(m_client && uv_is_writable((uv_stream_t*)(m_client)))
        tmp_printf(" time_cb, can writeable");

    uvw_notify_forward_cb* cb = dynamic_cast<uvw_notify_forward_cb*>(m_notify_cb);
    if(cb) {
        tmp_printf("send_delete_aisle_cmd, forward type : %d \r\n", cb->get_forward_type());
    }
}

void uvw_gw_tcp_forward::on_connect_ok()
{
    read_start();
    start_timer(UVW_TIMER_START_MS, UVW_TIMER_REPEAT_MS);
}

/* *******************************************************************
 * ******************************************************************/
void uvw_notify_forward_cb::will_close()
{
    tmp_printf(" uvw_notify_forward_cb, will_close \r\n");
    remove_all();

    /* *******************************************************************
    //关闭 与 客户端对应的 socket(socket class cb is uvw_gw_instance_cb);
    //uvw_gw_instance_cb/will_close 将主动调用 uvw_gw_map_fc_mgr 擦除 forward item
    ******************************************************************* */
    //mark:
    //socket close 不一定是服务端崩溃造成, 不能关闭所有的客户端;
    //暂时采用客户端超时设置的方式, 来应对服务端响应超时的问题;
    //uvw_gw_map_fc_mgr::Instance()->close_client_because_of_svr_crash();
}

void uvw_notify_forward_cb::on_read_data(const char *data, int size)
{
    GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
    if(wrapper->is_valid_link_id())
    {
        if(wrapper->is_create_aisle_ack())
        {
            tmp_printf("create aisle ok; aisle id: %lld \r\n", wrapper->link_id);
        }
        else if(wrapper->is_delete_aisle_ack())
        {
            tmp_printf("delete aisle ok; aisle id: %lld \r\n", wrapper->link_id);
            uvw_gw_tcp_forward_mgr *fmgr = uvw_gw_map_fc_mgr::Instance()->get_forward_mgr(m_forward_type);
            if(fmgr) fmgr->delete_aisle_id(wrapper->link_id);
        }
        else
        {
            //传递到 listen_c 模块, 由 listen_c 转发给客户端, write_to_client 负责内存的拷贝与释放;;
            const char *buffer = wrapper->data_header();
            uvw_gw_map_fc_mgr::Instance()->write_to_client2(m_forward_type, wrapper->link_id, buffer, wrapper->data_size());
        }
    }
}
