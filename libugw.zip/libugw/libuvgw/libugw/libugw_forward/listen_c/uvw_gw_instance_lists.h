
#ifndef _UVW_GW_INSTNACE_LISTS_H
#define _UVW_GW_INSTNACE_LISTS_H

#include <unordered_map>
#include "uvw_gw_instance_cb.h"


class uvw_gw_instance_cb;
typedef std::unordered_map<st64, uvw_gw_instance_cb*>  to_c_lists;
class uvw_gw_instance_lists
{
public:
    uvw_gw_instance_lists() {}

public:
    void push_item(st64 aisle_id, uvw_gw_instance_cb* inst_ptr)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_to_c_lists[aisle_id] = inst_ptr;
    }

    void erase_item(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        to_c_lists::iterator iter = m_to_c_lists.find(aisle_id);
        if(iter != m_to_c_lists.end())
            m_to_c_lists.erase(iter);
    }

    void erase_all()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_to_c_lists.clear();
    }

    //Transfer of/Change ownership of data to write_to_client
    void write_to_client(st64 aisle_id, const char *data, int size)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        to_c_lists::iterator iter = m_to_c_lists.find(aisle_id);
        if(iter != m_to_c_lists.end())
        {
            uvw_gw_instance_cb *to_c_ptr = (iter->second);
            if(to_c_ptr)
            {
                //uvw::comm_buffer will copy data of size
                //to_c_ptr->push_item(std::make_shared<uvw::comm_buffer>(data, size));
                to_c_ptr->push_pure(data, size); //support websocket wrapper
            }
        }
    }

    void write_close_to_client(st64 aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        to_c_lists::iterator iter = m_to_c_lists.find(aisle_id);
        if(iter != m_to_c_lists.end())
        {
            uvw_gw_instance_cb *to_c_ptr = (iter->second);
            if(to_c_ptr)
            {
                to_c_ptr->set_close_bits();
            }
        }
    }

    void write_close_to_client()
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        to_c_lists::iterator iter = m_to_c_lists.begin();
        while(iter != m_to_c_lists.end())
        {
            uvw_gw_instance_cb *to_c_ptr = (iter->second);
            if(to_c_ptr)
            {
                to_c_ptr->set_close_bits();
            }

            iter++;
        }
    }

    bool get_cb_aisle_lists(st64 aisle_id, aisle_map_lists::aisle_item_lists &lists)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        to_c_lists::iterator iter = m_to_c_lists.find(aisle_id);
        if(iter != m_to_c_lists.end())
        {
            uvw_gw_instance_cb *to_c_ptr = (iter->second);
            if(to_c_ptr)
            {
                lists = to_c_ptr->m_aisle_map_lists.m_aisle_lists;
                return true;
            }
        }

        return false;
    }

private:
    std::mutex m_mutex;
    to_c_lists m_to_c_lists;
};

#endif
