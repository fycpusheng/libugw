#ifndef UVW_GW_INSTANCE_C_H
#define UVW_GW_INSTANCE_C_H

#include "uvw_notify_cb.h"
#include "uvw_notify_mgr.h"
#include <vector>
#include <memory>
#include "aisle_forward_lists.h"
#include "ugw_notify_cb.h"


//uvw_gw_instance_cb 直接处理客户端发来的数据, 不包含网关相关信息, 故需要对网关类进行重写!!!
//uvw_gw_tcp_svr_c --> uvw_tcp_instance 使用..
class uvw_gw_instance_cb : public ugw_notify_cb_base
{
public:
    uvw_gw_instance_cb();

public:
    virtual void on_read_data(const char *data, int bytes);
    virtual void read_finished(const char *data, int bytes);
    //virtual void read_finished(const char *data, int bytes) {
    //    return on_read_data(data, bytes);
    //}

    // -- -------------------------------------------------------------------- -- //
    // -- 在 will_close 中用 push_item 通知回调管理器进行释放检测..
    // -- will_close 后 uvw_tcp_instance 将不再使用 uvw_notify_cb 的句柄...
    // -- 然后将 cb 句柄 加入 uvw_notify_cb_mgr 中等待释放, 只要 is_can_free 返回 true..
    // -- -------------------------------------------------------------------- -- //
    virtual void will_close();
    virtual bool is_can_free(); //cb member will free by uvw_notify_cb_mgr..

public:
    aisle_map_lists m_aisle_map_lists;
};


#endif
