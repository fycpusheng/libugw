
#include "uvw_loop.h"
#include "uvw_data.h"
#include "uvw_loop_mgr.h"
#include "uvw_gw_tcp_svr_c.h"
#include "../uvw_gw_map_fc_mgr.h"
#include "../forward/uvw_gw_tcp_forward_mgr.h"


#if 0
struct comm_header
{
    int size;
    int cmd = 0;
};

int uvw_parse_forward_type(char *data, int size)
{
    if(size>=sizeof(comm_header))
    {
        comm_header *header = (comm_header*)data;
        if(header)
        {
            if(header->cmd>=1 && header->cmd <=10)
                return 1;

            if(header->cmd>=11 && header->cmd <=20)
                return 2;
        }
    }

    return 0;
}

void main_to_c(int port, int thrds)
{
    //forward 类型的默认值应当大于0..
    uvw_loop_mgr::Instance()->start_loop_task_thread(thrds);
    uvw_gw_map_fc_mgr::Instance()->set_parse_frward_ptr(uvw_parse_forward_type);
    forward_item_ptr ptr = uvw_gw_map_fc_mgr::Instance()->new_forward_item(1); //loggin type;
    ptr->forward_mgr->set_ip_port("127.0.0.1", 4500);
    ptr->forward_mgr->init_aisle_loop(20, 200);
    ptr->forward_mgr->join();

    ptr = uvw_gw_map_fc_mgr::Instance()->new_forward_item(2); //lobby type;
    ptr->forward_mgr->set_ip_port("127.0.0.2", 4500);
    ptr->forward_mgr->init_aisle_loop(20, 200);
    ptr->forward_mgr->join();

    uvw_notify_cb_mgr::Instance()->start_free();
    uvw_loop loop;
    uvw_gw_tcp_svr_c svr(loop.get_loop_t());
    svr.bind_v4("127.0.0.1", port, 0);
    svr.listen(10);
    loop.run();

    uvw_loop_mgr::Instance()->join();
    uvw_notify_cb_mgr::Instance()->stop_free();
}
#endif


