#ifndef AISLE_FORWARD_LISTS_H
#define AISLE_FORWARD_LISTS_H

#include <mutex>
#include <share_type_def.h>
#include <vector>
#include <memory>

//
//每个链接 foward 的通道类型列表;
//一个客户端会将数据 foward to 多个业务服务器..
class aisle_map_lists
{
    struct aisle_item
    {
        st_int32 fward_type;
        st64 aisle_id;

        aisle_item(int type, st64 id)
        {
            fward_type = type;
            aisle_id = id;
        }
    };


public:
    typedef std::shared_ptr<aisle_item> aisle_item_ptr;
    struct aisle_item_lists : protected std::vector<aisle_item_ptr>
    {
    public:
        st64 get_aisle_id_by_type(int fward_type)
        {
            for(int i=0; i<this->size(); i++)
            {
                aisle_item_ptr iptr = this->at(i);
                if(iptr->fward_type == fward_type)
                    return iptr->aisle_id;
            }

            return 0;
        }

        void add_aisle_map_item(int ftype, int aisle_id)
        {
            this->push_back(aisle_item_ptr(new aisle_item(ftype, aisle_id)));
        }

        aisle_item_ptr item_at(int i)
        {
            if(i < this->size())
                return at(i);

            return aisle_item_ptr(0);
        }
    };

public:
    st64 get_aisle_id_by_type(int fward_type)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        return m_aisle_lists.get_aisle_id_by_type(fward_type);
    }

    void add_aisle_map_item(int ftype, int aisle_id)
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_aisle_lists.add_aisle_map_item(ftype, aisle_id);
    }

public:
    std::mutex m_mutex;
    aisle_item_lists m_aisle_lists;
};


#endif
