#include "uvw_gw_instance_cb.h"
#include "uvw_tools.h"
#include "../uvw_gw_map_fc_mgr.h"
#include <share_type_def.h>
#include <uvw_gw_data.h>


uvw_gw_instance_cb::uvw_gw_instance_cb()
{
    uvw_gw_map_fc_mgr::Instance()->push_to_forward_item(this);

#ifdef ENABLE_GW_LARGE_PACKAGE_WAY
    m_header_size = uvw_gw_map_fc_mgr::Instance()->proto_header_size();
#endif
}

void uvw_gw_instance_cb::read_finished(const char *data, int size)
{
    tmp_printf("xxxxxxxxxxx forward listen: read client buffer size: %d", size);

#ifdef ENABLE_GW_LARGE_PACKAGE_WAY
    if(m_header_size > 0)
    {
        m_had_bytes += size;

        //最少需要读取到网关的头部才能正常解析数据!!
        if(m_had_bytes < m_header_size)
        {
            return;
        }

        if(m_had_bytes == m_header_size)
        {
            char* header_ptr = m_buffer_ptr;

            //理论上这里必须能获取到头部大小!!
            int pack_size = 0;
            uvw_gw_map_fc_mgr::uvw_parse_integrality_ptr integrality_ptr = uvw_gw_map_fc_mgr::Instance()->get_parse_integrality_ptr();
            int ret = integrality_ptr(header_ptr, m_header_size, pack_size);
            if(ret == CHECK_USER_DATA_HEADER_ERROR)
            {
                will_close();
                return;
            }

            //是一个仅有网关数据的包??
            if(pack_size <= m_had_bytes)
            {
                on_read_data(header_ptr, pack_size);

                //pack_size == m_had_bytes == m_header_size
                m_had_bytes -= pack_size;
                return;
            }

            m_total_size = pack_size;

            //需要分配大内存??!
            if(m_total_size > UVW_READ_BUFFER_MAX_LEN)
                alloc_large();
        }
        else
        {
            //m_had_bytes == m_total_size, only!
            //m_had_bytes 只会等于 m_total_size; 不会大于!!
            if(m_had_bytes >= m_total_size)
            {
                char* header_ptr = 0;
                if(m_total_size > UVW_READ_BUFFER_MAX_LEN)
                {
                    header_ptr = m_large_buffer;
                }
                else {
                    header_ptr = m_buffer_ptr;
                }

                int pack_size = 0;
                uvw_gw_map_fc_mgr::uvw_parse_integrality_ptr integrality_ptr = uvw_gw_map_fc_mgr::Instance()->get_parse_integrality_ptr();
                integrality_ptr(header_ptr, m_header_size, pack_size);

                on_read_data(header_ptr, pack_size);
                free_large();

                m_had_bytes -= m_total_size;
            }
        }

        return;
    }
#endif

    if(true)
    {
        if(m_had_bytes>0)
        {
            //prepare_buffer 已经把接收缓冲设置为 m_buffer_ptr + m_had_bytes!!!
            tmp_assert(size+m_had_bytes <= UVW_READ_BUFFER_MAX_LEN);
            data = m_buffer_ptr;
            size += m_had_bytes;
        }

        //若 integrality_ptr is true, 则使用用户指定的包解析函数, 按用户指定的大小来转发包数据!!
        uvw_gw_map_fc_mgr::uvw_parse_integrality_ptr integrality_ptr = uvw_gw_map_fc_mgr::Instance()->get_parse_integrality_ptr();
        if(integrality_ptr)
        {
            //返回值 <= 0, 证明数据不完整, 大于0, 证明至少有一个完整的数据包!!!
            bool is_need_move = false;
            int  next_off = 0;

            int  pack_size = 0;
            int  ret = integrality_ptr(data, size, pack_size);
            //包大小被解析出来!!
            if(ret >= 0) {
                if(size >= pack_size)
                    next_off = pack_size;
            }
            else if(ret == CHECK_USER_DATA_HEADER_ERROR)
            {
                will_close();
                return;
            }

            while(next_off > 0)
            {
                if(!is_need_move)
                    is_need_move = true;

                on_read_data(data, size);

                data += next_off;
                size -= next_off;

                //包大小被解析出来!!
                next_off = 0;
                ret = integrality_ptr(data, size, pack_size);
                if(ret >= 0) {
                    //有一个包??
                    if(size >= pack_size)
                        next_off = pack_size;
                }
                else if(ret == CHECK_USER_DATA_HEADER_ERROR)
                {
                    will_close();
                    return;
                }
            }

            if(size>0)
            {
                m_had_bytes = size;

                if(is_need_move)
                    memcpy(m_buffer_ptr, data, size);
            }
            else
                m_had_bytes = 0;
        }
        else {
            //用户未设置包解析函数, 则收到多少数据, 转发多少数据!!!
            on_read_data(data, size);
        }
    }
}

void uvw_gw_instance_cb::on_read_data(const char *data, int bytes)
{
    tmp_printf("xxxxxxxxxxx forward listen: write_to_forward buffer size: %d", bytes);

    int type = 0;
    uvw_gw_map_fc_mgr::uvw_parse_forward_type_ptr forward_ptr = uvw_gw_map_fc_mgr::Instance()->get_parse_frward_ptr();
    if(forward_ptr)
        type = forward_ptr(data, bytes);

    if(type>=0)
    {
        //封装客户端的数据为网关数据, 并通过forward 模块转发到业务服务器;;
        st64 aisle_id = m_aisle_map_lists.get_aisle_id_by_type(type);
        uvw_gw_map_fc_mgr::Instance()->write_to_forward(type, aisle_id, data, bytes);
    }
}

void uvw_gw_instance_cb::will_close()
{
    //释放 CB 保存的通道!!
    uvw_gw_map_fc_mgr::Instance()->erase_from_forward_item(this);
    uvw_notify_cb_mgr::Instance()->push_item(this);
}

bool uvw_gw_instance_cb::is_can_free()
{
    return true;
}
