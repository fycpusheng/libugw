
#include "uvw_gw_tcp_svr_c.h"
#include "uvw_tcp_instance.h"
#include "uvw_loop.h"
#include "uvw_loop_mgr.h"
#include "../listen_ws/ugw_ws_instance_cb.h"


void uvw_gw_tcp_svr_c::new_instance_cb(uvw_tcp_instance *instance)
{
    //uvw_gw_instance_cb 将自身加入 uvw_gw_map_fc_mgr, //
    //uvw_gw_map_fc_mgr 为 uvw_gw_instance_cb 创建一个通道//
    if(m_is_websocket)
        instance->set_notify_cb(new ugw_ws_instance_cb);
    else
        instance->set_notify_cb(new uvw_gw_instance_cb);
}

void start_gw_listen_run(std::string ip, int port, int td_num, bool is_websocket)
{
    uvw_loop_mgr::Instance()->start_loop_task_thread(td_num);
    uvw_notify_cb_mgr::Instance()->start_free();

    uvw_loop_async loop;
    uvw_gw_tcp_svr_c svr(loop.get_loop_t());
    if(svr.bind_v4(ip.data(), port, 0))
    {
        if(is_websocket)
            svr.set_websocket();

        if(svr.listen(10))
        {
            loop.start_idler();
            loop.run();
        }
    }

    uvw_loop_mgr::Instance()->stop_loops();
    uvw_loop_mgr::Instance()->join();
    uvw_notify_cb_mgr::Instance()->stop_free();
}
