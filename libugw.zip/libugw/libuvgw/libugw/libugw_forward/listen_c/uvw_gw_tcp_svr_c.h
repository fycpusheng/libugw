#ifndef _UVW_GW_TCP_SVR_C_H_
#define _UVW_GW_TCP_SVR_C_H_

#include "uvw_tcp_svr.h"
#include "uvw_gw_instance_cb.h"
#include "../../libuvgw.h"


class uvw_tcp_instance;
class UVGW_EXTERN uvw_gw_tcp_svr_c : public uvw_tcp_svr
{
public:
    uvw_gw_tcp_svr_c(uv_loop_t *loop_t) : uvw_tcp_svr(loop_t) {
        m_is_websocket = false;
    }

public:
    virtual void new_instance_cb(uvw_tcp_instance *instance);
    virtual void set_websocket() {
        m_is_websocket = true;
    }

private:
    bool m_is_websocket;
};


UVGW_EXTERN void start_gw_listen_run(std::string ip, int port, int td_num, bool is_websocket);


#endif
