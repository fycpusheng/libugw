#include "uvw_gw_map_fc_mgr.h"
#include "listen_c/uvw_gw_instance_cb.h"
#include "listen_c/uvw_gw_instance_lists.h"
#include "forward/uvw_gw_tcp_forward_mgr.h"


uvw_gw_map_fc_mgr  g_uvw_gw_instance_cmgr;
uvw_gw_map_fc_mgr *uvw_gw_map_fc_mgr::Instance()
{
    return &g_uvw_gw_instance_cmgr;
}

int uvw_gw_map_fc_mgr::m_proto_header_size = 0;
forward_item_ptr uvw_gw_map_fc_mgr::new_forward_item(int fward_type)
{
    //此函数, 初始化时调用一次, 故无须互斥 !!!
    forward_item_ptr item(new forward_item);
    item->instance_lists = new uvw_gw_instance_lists;
    item->forward_mgr = new uvw_gw_tcp_forward_mgr;
    item->forward_mgr->set_forward_type(fward_type);
    m_forward_lists[fward_type] = item;
    return item;
}

void uvw_gw_map_fc_mgr::clear_forward_item()
{
    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            item_ptr->instance_lists->erase_all();
            delete item_ptr->instance_lists;
            delete item_ptr->forward_mgr;
        }

        iter++;
    }

    m_forward_lists.clear();
}

uvw_gw_tcp_forward_mgr *uvw_gw_map_fc_mgr::get_forward_mgr(int fward_type)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        return item_ptr->forward_mgr;
    }

    return 0;
}

void uvw_gw_map_fc_mgr::push_to_forward_item(uvw_gw_instance_cb *inst_ptr)
{
    std::lock_guard<std::mutex> lk(m_mutex);

#ifdef USE_SAME_AISLE_ID
    st64 asid = 0;
    while(true)
    {
        bool is_ok = true;

        uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
        while(iter != m_forward_lists.end())
        {
            forward_item_ptr item_ptr = (iter->second);
            if(item_ptr->instance_lists)
            {
                if(asid <= 0)
                {
                    asid = item_ptr->forward_mgr->find_free_aisle_id();
                    if(asid <= 0) {
                        is_ok = false;
                        break;
                    }
                }
                else
                {
                    if(!item_ptr->forward_mgr->is_free_aisle_id(asid))
                    {
                        asid = item_ptr->forward_mgr->find_free_aisle_id();
                        is_ok = false;
                        break;
                    }
                }
            }

            iter++;
        }

        if(is_ok)
            break;
    }

    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            //将与内网服务器建立的通道, 添加到 uvw_gw_instance_cb !!
            item_ptr->forward_mgr->create_aisle_id(asid);
            item_ptr->instance_lists->push_item(asid, inst_ptr);
            inst_ptr->m_aisle_map_lists.add_aisle_map_item(iter->first, asid);
        }

        iter++;
    }
#else

    //为了在 write_to_client2 时, 对数据是否需要发送到客户端进行控制, 需要客户端在所有业务服务器的通道一致!!
    //具体看 m_parse_client_ptr, 的数据解析分析; 若 m_parse_client_ptr 指针为空;
    //则 write_to_client2 == write_to_client ;
    //
    //通道从1开始 !!!
    st64 asid = 0;
    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            asid = item_ptr->forward_mgr->create_aisle_id();
            item_ptr->instance_lists->push_item(asid, inst_ptr);
            inst_ptr->m_aisle_map_lists.add_aisle_map_item(iter->first, asid);
        }

        iter++;
    }
#endif
}

void uvw_gw_map_fc_mgr::erase_from_forward_item(uvw_gw_instance_cb* inst_ptr)
{
    std::lock_guard<std::mutex> lk(m_mutex);

    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            st64 aisle_id = inst_ptr->m_aisle_map_lists.get_aisle_id_by_type(iter->first);
            item_ptr->instance_lists->erase_item(aisle_id);
            item_ptr->forward_mgr->will_delete_aisle_id(aisle_id);
        }

        iter++;
    }
}

//当服务端出错误时调用??
//业务服务端崩溃时, 网关服务器仍然保留通道及对应客户端的链接;
//当业务服务器重启后 :
//处理数据时, 若找不到对应通道, 则自动创建通道, 无须网关发送创建通道命令!!
void uvw_gw_map_fc_mgr::close_client_because_of_svr_crash()
{
    std::lock_guard<std::mutex> lk(m_mutex);

    bool is_first = true;
    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            item_ptr->instance_lists->erase_all();
            if(is_first)
            {
                item_ptr->instance_lists->write_close_to_client();
                is_first = false;
            }
        }

        iter++;
    }
}

void uvw_gw_map_fc_mgr::close_client_because_of_svr_forbid(int fward_type, st64 aisle_id)
{
    std::lock_guard<std::mutex> lk(m_mutex);

    //write_close_to_client must be call first;
    //first set close to socket of bind client
    uvw_to_forward_lists::iterator iter2 = m_forward_lists.find(fward_type);
    if(iter2 != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter2->second);
        if(item_ptr->instance_lists)
        {
            item_ptr->instance_lists->write_close_to_client(aisle_id);
        }
    }

    //aisle invalid after erase_item
#ifdef USE_SAME_AISLE_ID
    uvw_to_forward_lists::iterator iter = m_forward_lists.begin();
    while(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            item_ptr->instance_lists->erase_item(aisle_id);
        }
        iter++;
    }
#else
    aisle_map_lists::aisle_item_lists lists;
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
            item_ptr->instance_lists->get_cb_aisle_lists(aisle_id, lists);
    }

    int ipos = 0;
    while(true)
    {
        aisle_map_lists::aisle_item_ptr iptr = lists.item_at(ipos);
        if(iptr)
        {
            uvw_to_forward_lists::iterator iter = m_forward_lists.find(iptr->fward_type);
            if(iter != m_forward_lists.end())
            {
                forward_item_ptr item_ptr = (iter->second);
                if(item_ptr->instance_lists)
                {
                    item_ptr->instance_lists->erase_item(iptr->aisle_id);
                }
            }
            ipos++;
        }
        else
            break;
    }
#endif
}

void uvw_gw_map_fc_mgr::write_to_client(int fward_type, st64 aisle_id, const char *data, int size)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            item_ptr->instance_lists->write_to_client(aisle_id, data, size);
        }
    }
}

void uvw_gw_map_fc_mgr::write_to_client2(int fward_type, st64 aisle_id, const char *data, int size)
{
#ifdef LOGIN_BY_GETWAY_AGENT
    int to_var = w_to_client;
    if(m_parse_client_ptr)
    {
        to_var = m_parse_client_ptr(fward_type, aisle_id, data, size);
        if(to_var == w_to_null)
            return;

        //网关部分不能直接决定是否 close; close 必然是来自用户增加的某个业务逻辑!!
        if(to_var == w_to_close)
        {
            close_client_because_of_svr_forbid(fward_type, aisle_id);
        }
    }

    std::lock_guard<std::mutex> lk(m_mutex);
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            if(to_var == w_to_client)
            {
                tmp_printf("write_to_client -- type: %d, link id : %lld, data size : %d ", fward_type, aisle_id, size)
                item_ptr->instance_lists->write_to_client(aisle_id, data, size);
            }
        }
    }
#else
    write_to_client(fward_type, aisle_id, data, size);
#endif
}

void uvw_gw_map_fc_mgr::write_to_forward(int fward_type, st64 aisle_id, const char *data, int size)
{
    tmp_printf("xxxxxx uvw_gw_map_fc_mgr::write_to_forward");

    //m_forward_lists 的类型是固定的; 服务启动时创建完毕; 内容运行期间无变更, 所以理论上无须互斥!!
    std::lock_guard<std::mutex> lk(m_mutex);
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->forward_mgr)
        {
            tmp_printf("write_to_forward -- type: %d, link id : %lld, data size : %d ", fward_type, aisle_id, size)
            item_ptr->forward_mgr->write_to_aisle(aisle_id, data, size);
        }
    }
}

#ifndef  USE_SAME_AISLE_ID
//通过已知的类型和通道ID, 获取另一种类型的通道ID!!
st64 uvw_gw_map_fc_mgr::get_clt_asile_id(int fward_type, st64 aisle_id, int get_type)
{
    uvw_to_forward_lists::iterator iter = m_forward_lists.find(fward_type);
    if(iter != m_forward_lists.end())
    {
        forward_item_ptr item_ptr = (iter->second);
        if(item_ptr->instance_lists)
        {
            aisle_map_lists::aisle_item_lists lists;
            if(item_ptr->instance_lists->get_cb_aisle_lists(aisle_id, lists))
            {
                return lists.get_aisle_id_by_type(get_type);
            }
        }
    }

    return 0;
}
#endif
