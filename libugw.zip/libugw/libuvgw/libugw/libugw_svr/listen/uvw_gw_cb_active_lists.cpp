#include "uvw_gw_cb_active_lists.h"
#include "uvw_gw_aisle_mgr.h"


uvw_gw_cb_active_lists  g_uvw_gw_cb_active_lists;
uvw_gw_cb_active_lists* uvw_gw_cb_active_lists::Instance()
{
    return &g_uvw_gw_cb_active_lists;
}

uvw_gw_cb_active_lists::uvw_gw_cb_active_lists()
{

}

void uvw_gw_cb_active_lists::add_broadcast(const char* data, int size)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    cb_int_lists::iterator iter = m_cb_lists.begin();
    while(iter != m_cb_lists.end())
    {
        uvw_gw_aisle_mgr *cb = iter->first;
        if(cb)
            cb->add_out_data(data, size);
        iter++;
    }
}
