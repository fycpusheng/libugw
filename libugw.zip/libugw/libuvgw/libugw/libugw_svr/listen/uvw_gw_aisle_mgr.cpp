#include "uvw_gw_aisle_mgr.h"
#include "uvw_gw_data.h"
#include "uvw_gw.h"
#include "dbg/uvw_tmp_log.h"
#include "uvw_tools.h"
#include <thread>


void uvw_gw_aisle_mgr::send_ping_data()
{
    uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>(sizeof(GW_Data::cts_gw_data));
    GW_Data::cts_gw_data *wrapper_ptr = (GW_Data::cts_gw_data*)ptr->buffer;
    if(wrapper_ptr)
    {
        wrapper_ptr->size = ptr->size;
        wrapper_ptr->set_ping();
        push_item(ptr);
    }
}

void uvw_gw_aisle_mgr::send_create_aisle_ok(st64 aisle_id)
{
    GW_Data::cts_gw_data *gw_data = GW_Data::cts_gw_data::make_gw_cmd(aisle_id, cmd_gw_create_aisle_ack, uvw_tools::is_big_endian());
    if(gw_data)
    {
        uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>();
        ptr->attach((char*)gw_data, gw_data->size);
        push_item(ptr);
    }
}

void uvw_gw_aisle_mgr::send_delete_aisle_ok(st64 aisle_id)
{
    GW_Data::cts_gw_data *gw_data = GW_Data::cts_gw_data::make_gw_cmd(aisle_id, cmd_gw_delete_aisle_ack, uvw_tools::is_big_endian());
    if(gw_data)
    {
        uvw_buffer_ptr ptr = std::make_shared<uvw::comm_buffer>();
        ptr->attach((char*)gw_data, gw_data->size);
        push_item(ptr);
        tmp_printf("send_delete_aisle_ok to gw \n");
    }
}

bool uvw_gw_aisle_mgr::generate_aisle_id(st64 aisle_id)
{
    //note:
    //有通道ID, 就不能 push_item, 否则 aisle 对象关联的旧智能指针将被释放;
    //从而导致通道被释放; 而通道对象, 必须在 is_can_free 返回 true 时才能释放;
    //
    //故, 发现有未释放的相同 aisle id object; 应直接返回失败, 或者 复用上一个 ID !!!
    //
    tmp_printf("xx : generate_aisle_id : %lld", aisle_id)
    if(m_priv_lists.has_aisle_id(aisle_id))
        return true;

    tmp_printf("xx : generate_aisle_id push item : %lld", aisle_id)
    static uvw_new_accept_ptr uvw_accept_ptr = uvw_gw::Instance()->get_accept_ptr();
    if(uvw_accept_ptr)
    {
        type_gw_aisle_ptr priv_ptr(uvw_accept_ptr());
        if(priv_ptr)
        {
            m_priv_lists.push_item(aisle_id, priv_ptr);
            return true;
        }
    }

    return false;
}

void uvw_gw_aisle_mgr::start_aisle_thread()
{
    m_aisle_thr_running = true;
    std::thread([=]
    {
        while(!m_aisle_stop)
        {
            //注, @@sa:
            // 一个链接可能含有多个通道, 故通道的释放应在这个伴生线程中, 而不应在 uvw_gw_aisle_mgr::is_can_free 中;
            // uvw_gw_aisle_mgr::is_can_free 是一个网络链接断开时 对数据回调类进行释放时 调用的;
            // ** 而网关的链接通常是一直有效的; ** 而网关的链接通常是一直有效的; **
            // 所以, 若在里面释放通道, 会导致无效通道链接过多, 占用通道数量; //
            //
            //先擦除已经失效的通道, 通道也有 is_can_free 函数..
            type_gw_aisle_ptr_lists aslists;
            m_will_lists.take_free_aisle(aslists);

            type_gw_aisle_ptr_lists::iterator asiter = aslists.begin();
            while(asiter != aslists.end())
            {
                tmp_printf("xx : is_delete_aisle_ok : %lld", asiter->first)
                send_delete_aisle_ok(asiter->first);
                asiter++;
            }

            //获取 所有通道 要发送的首个数据包..
            comm_buffer_lists lists;
            m_priv_lists.get_cache_data(lists);

            comm_buffer_lists::iterator iter = lists.begin();
            while(iter != lists.end())
            {
                uvw_buffer_ptr ptr = (iter->second);
                if(ptr)
                {
                    //封装成网关数据, 再送入发送队列...
                    GW_Data::cts_gw_data *data = GW_Data::cts_gw_data::make_gw_data(iter->first, ptr->buffer, ptr->size, uvw_tools::is_big_endian());
                    uvw_buffer_ptr wptr = std::make_shared<uvw::comm_buffer>();
                    wptr->attach((char*)data, data->size);
                    push_item(wptr);
                }

                iter++;
            }

            if(lists.size()<=0)
                uvw_tools::ms_sleep(2);
        }

        //notice:
        //线程退出意味着对应的 getway socket 关闭, 将此信息告诉通道, 以便通道为释放做准备!!!
        m_priv_lists.tell_aisle_will_close();

        //notice:
        //getway socket 关闭, 释放队列中的所有通道; 此处无需将通道数据拷贝到 m_will_lists!!
        while(m_priv_lists.size()>0)
        {
            type_gw_aisle_ptr_lists aslists;
            m_priv_lists.take_free_aisle(aslists);
            uvw_tools::ms_sleep(1);

            /* socket had close, dont need send delete_aisle command!!
            type_gw_aisle_ptr_lists::iterator asiter = aslists.begin();
            while(asiter != aslists.end())
            {
                send_delete_aisle_ok(asiter->first);
                asiter++;
            }
            */
        }

        //等待 will 队列释放完毕!!
        while(m_will_lists.size()>0)
        {
            type_gw_aisle_ptr_lists aslists;
            m_will_lists.take_free_aisle(aslists);
            uvw_tools::ms_sleep(1);
        }

        //清除所有应答完成后待发送的缓存!!!
        remove_all();

        //place it at bottom
        m_aisle_thr_running = false;
    }).detach();
}

void uvw_gw_aisle_mgr::on_read_data(const char *data, int bytes)
{
    GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
    if(wrapper->is_valid_link_id())
    {
        if(wrapper->is_create_aisle())
        {
            if(generate_aisle_id(wrapper->link_id)) {
                send_create_aisle_ok(wrapper->link_id);
            }
        }
        else if(wrapper->is_delete_aisle())
        {
            tmp_printf("is_delete_aisle start: %lld", wrapper->link_id)
            type_gw_aisle_ptr gw_ptr = m_priv_lists.take_item(wrapper->link_id);
            if(gw_ptr)
            {
                gw_ptr->will_close();
                //send_delete_aisle_ok(wrapper->link_id); //这里不能发送, 因为相关数据并未释放; 一旦重用可能有数据冲突!!!!

                //将待关闭的通道放到 m_will_lists 中, 不再读取其数据!!
                //通道删除意味着对端关闭, 数据已经无法回发, throw data!
                m_will_lists.push_item(wrapper->link_id, gw_ptr);
            }
        }
        else
        {
            tmp_printf("uvw_gw_aisle_mgr buffer size: %d", wrapper->data_size());

            //pass data to asile for handling
            type_gw_aisle_ptr gw_ptr = m_priv_lists.get_item(wrapper->link_id);
            if(gw_ptr)
            {
                gw_ptr->read_finished(wrapper->data_header(), wrapper->data_size());
            }
            else
            {
                generate_aisle_id(wrapper->link_id);
                type_gw_aisle_ptr gw_ptr = m_priv_lists.get_item(wrapper->link_id);
                if(gw_ptr)
                {
                    gw_ptr->read_finished(wrapper->data_header(), wrapper->data_size());
                }
            }
        }
    }
}

bool uvw_gw_aisle_mgr::is_can_free()
{
    //see @@sa:
    return (m_priv_lists.size()<=0) && (!m_aisle_thr_running);
}
