
#include "uvw_gw_tcp_svr.h"
#include "uvw_gw_aisle_mgr.h"


void uvw_gw_tcp_svr::new_instance_cb(uvw_tcp_instance *instance)
{
    instance->set_notify_cb(new uvw_gw_aisle_mgr);
}

