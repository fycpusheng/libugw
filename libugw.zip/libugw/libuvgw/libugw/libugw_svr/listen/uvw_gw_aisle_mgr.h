#ifndef UVW_GW_AISLE_MGR_H
#define UVW_GW_AISLE_MGR_H

#include "ugw_notify_cb.h"
#include "uvw_notify_cb.h"
#include "uvw_notify_mgr.h"
#include "uvw_gw_aisle_lists.h"
#include "uvw_gw_cb_active_lists.h"


//Notice:
//@1: uvw_gw_aisle_mgr 是网络连接的回调类, 用来处理一个连接传来的所有数据;
//@2: uvw_gw_aisle_mgr 被 uvw_tcp_instance 使用..
//@3: uvw_gw_aisle_mgr 实现了对通道的管理;
//@4: uvw_gw_aisle_mgr 对通道的管理通过 uvw_gw_aisle_instance_lists 来实现..
//
//uvw_gw_aisle_mgr 将生成伴生线程, 处理所有的链接回复..
class uvw_gw_aisle_mgr : public ugw_notify_cb
{
public:
    uvw_gw_aisle_mgr() {
        m_aisle_stop = false;
        m_aisle_thr_running = false;
        start_aisle_thread();

        uvw_gw_cb_active_lists::Instance()->push_item(this);
    }

public:
    virtual void on_read_data(const char *data, int bytes);

    // ** *********************************************************************** ** //
    // -- 通知回调管理器进行释放..
    // -- will_close 后 uvw_tcp_instance 将不再使用 uvw_notify_cb 的句柄...
    // -- 然后将 cb 句柄 加入 uvw_notify_cb_mgr 中等待释放, 只要 is_can_free 返回 true..
    // ** *********************************************************************** ** //
    virtual void will_close() {
        uvw_gw_cb_active_lists::Instance()->erase_item(this);
        uvw_notify_cb_mgr::Instance()->push_item(this);
        stop_aisle_thread();
    }
    virtual bool is_can_free(); //cb member will free by uvw_notify_cb_mgr..

public:
    void send_ping_data();
    void send_create_aisle_ok(st64 aisle_id);
    void send_delete_aisle_ok(st64 aisle_id);
    bool generate_aisle_id(st64 aisle_id);

public:
    void add_out_data(const char *data, int size) {
        m_priv_lists.add_out_data(data, size);
    }

public:
    void start_aisle_thread();
    void stop_aisle_thread() { m_aisle_stop = true; }

private:
    //m_will_lists : 对应客户端已经关闭的通道; 数据需要丢弃!!
    //m_priv_lists : 新连接或正在使用的通道, 数据需要转发!!
    uvw_gw_aisle_instance_lists m_priv_lists;
    uvw_gw_aisle_instance_lists m_will_lists;

    bool m_aisle_stop;
    bool m_aisle_thr_running;
};


#endif
