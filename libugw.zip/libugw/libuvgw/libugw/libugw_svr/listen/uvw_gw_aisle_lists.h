#ifndef UVW_GW_AISLE_LIST_H
#define UVW_GW_AISLE_LIST_H

#include <share_type_def.h>
#include <memory>
#include <mutex>
#include <vector>
#include <unordered_map>
#include "uvw_comm_buffer.h"
#include "uvw_gw_aisle_instance.h"


//被 uvw_gw_aisle_mgr 使用; 用于管理某个 socket 所有链接上来的客户端..
typedef std::unordered_map<st64, uvw_buffer_ptr>  comm_buffer_lists;
class uvw_gw_aisle_instance_lists
{
public:
    void push_item(st64 link_id, type_gw_aisle_ptr inst_ptr);
    void erase_item(st64 link_id);
    void erase_all();
    bool has_aisle_id(st64 link_id);

public:
    //擦除所有已释放通道指针; 并取走其通道数据/ID !!!
    void take_free_aisle(type_gw_aisle_ptr_lists &as_lists);
    void take_free_aisle(std::vector<st64> &as_lists);
    void tell_aisle_will_close();

    //用户准备 write 的数据列表!!
    void get_cache_data(comm_buffer_lists &wlists);
    int  size();

public:
    void add_out_data(const char *data, int size);

public:
    type_gw_aisle_ptr get_item(st64 link_id);
    type_gw_aisle_ptr take_item(st64 link_id);

private:
    std::mutex m_mutex;
    type_gw_aisle_ptr_lists m_inst_lists;
};

#endif
