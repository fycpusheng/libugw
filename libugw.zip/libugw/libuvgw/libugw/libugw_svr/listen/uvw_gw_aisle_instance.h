#ifndef UVW_GW_AISLE_INSTANCE_H
#define UVW_GW_AISLE_INSTANCE_H

#include <memory>
#include <mutex>
#include <unordered_map>
#include <share_type_def.h>
#include "uvw_comm_buffer.h"
#include "../../libuvgw.h"


//server 代码使用, 用于进行广播与转发; 不支持可置空!!!
class UVGW_EXTERN uvw_gw_aisle_instance
{
public:
    virtual ~uvw_gw_aisle_instance() { }

public:
    virtual void write_finished(int status) = 0;
    virtual void read_finished(const char *data, int size) = 0;
    virtual void will_close() = 0;
    virtual bool is_can_free() = 0;

public:
    //for broadcast; forbid attach data!!!
    //data 指向的数据不可复用, 被调用者须自己分配内存来缓存数据!!!
    //data 的数据格式, 由应用者自定义; 可以最大限度的支持各种业务KEY!!!
    virtual void add_out_data(const char *data, int size) = 0;

public:
    //take write data, data will remove..
    virtual uvw_buffer_ptr take_header() = 0;
};

typedef uvw_gw_aisle_instance*                       uvw_gw_aisle_instance_ptr;
typedef std::shared_ptr<uvw_gw_aisle_instance>       type_gw_aisle_ptr;
typedef std::unordered_map<st64, type_gw_aisle_ptr>  type_gw_aisle_ptr_lists;

#endif
