#ifndef _UVW_GW_TCP_SVR_H_
#define _UVW_GW_TCP_SVR_H_

#include "uvw_loop_mgr.h"
#include "uvw_tcp_svr.h"
#include "uvw_tcp_instance.h"
#include "uvw_gw_aisle_mgr.h"


class uvw_gw_tcp_svr : public uvw_tcp_svr
{
public:
    uvw_gw_tcp_svr(uv_loop_t *loop_t) : uvw_tcp_svr(loop_t) {}

public:
    virtual void new_instance_cb(uvw_tcp_instance *instance);
};

#endif
