
#include "uvw_gw.h"
#include "uvw_loop.h"
#include "uvw_data.h"
#include "uvw_gw_tcp_svr.h"

uvw_gw  g_uvw_gw;
uvw_gw* uvw_gw::Instance()
{
    return &g_uvw_gw;
}

void uvw_gw::start_loop(std::string ip, int port, int thrds)
{
    uvw_loop_mgr::Instance()->start_loop_task_thread(thrds);
    uvw_notify_cb_mgr::Instance()->start_free();

    //for linux
    uvw_loop_async loop;
    m_svr_loop = &loop;

    uvw_gw_tcp_svr svr(loop.get_loop_t());
    if(svr.bind_v4(ip.data(), port, 0))
    {
        if(svr.listen(10))
        {
            printf(" start server listen !!!!! \r\n");
            loop.start_idler();
            loop.run();
        }
        else
            printf(" server listen failed !!!!! \r\n");
    }

    m_svr_loop = 0;
    uvw_loop_mgr::Instance()->stop_loops();
    uvw_loop_mgr::Instance()->join();
    uvw_notify_cb_mgr::Instance()->stop_free();
}

void uvw_gw::stop_loop()
{
    if(m_svr_loop)
    {
        m_svr_loop->stop();
    }
}



//examples:

#if 0
#include "uvw_tools.h"
#include "uvw_gw_aisle_instance.h"

class async_aisle_instance_ex : public uvw_gw_aisle_instance
{
public:
    virtual void write_finished(int status) {}
    virtual void read_finished(const char *data, int size)  {
        m_is_can_free = false;
        new std::thread([=]()
        {
            uvw_tools::ms_sleep(10*1000);
            m_is_can_free = true;
        });
    }
    virtual void will_close()  {}
    virtual bool is_can_free() { return m_is_can_free; }

public:
    virtual uvw_buffer_ptr take_header() { return 0; }

private:
    bool m_is_can_free = true;
};

type_gw_aisle_ptr has_new_accept_ptr(void)
{
    return type_gw_aisle_ptr(new async_aisle_instance_ex);
}

int main()
{
    //线程数不亦太多, uvw_gw_notify_cb 会生成伴生线程, 在处理网关的数据ID..
    uvw_gw gw;
    uvw_gw::set_accept_ptr(has_new_accept_ptr);
    gw.start_loop("127.0.0.1", 4500, 20);
}
#endif


