#ifndef UVW_GW_CB_ACTIVE_LISTS_H
#define UVW_GW_CB_ACTIVE_LISTS_H

#include <unordered_map>
#include <mutex>

class uvw_gw_aisle_mgr;
class uvw_gw_cb_active_lists
{
public:
    static uvw_gw_cb_active_lists* Instance();

public:
    uvw_gw_cb_active_lists();

public:
    void push_item(uvw_gw_aisle_mgr* cb) {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_cb_lists[cb] = 0;
    }

    void erase_item(uvw_gw_aisle_mgr* cb) {
        std::lock_guard<std::mutex> lk(m_mutex);
        cb_int_lists::iterator iter = m_cb_lists.find(cb);
        if(iter != m_cb_lists.end())
            m_cb_lists.erase(iter);
    }

public:
    void add_broadcast(const char* data, int size);

protected:
    typedef std::unordered_map<uvw_gw_aisle_mgr*, int>  cb_int_lists;

public:
    std::mutex m_mutex;
    cb_int_lists m_cb_lists;
};

#endif
