#ifndef LIBUVW_GW_H
#define LIBUVW_GW_H

#include "uvw_gw_aisle_instance.h"
#include "../../libuvgw.h"

typedef type_gw_aisle_ptr (*uvw_new_accept_ptr)(void);
class uvw_loop;
class UVGW_EXTERN uvw_gw
{
public:
    static uvw_gw* Instance();

public:
    uvw_gw() {
        m_svr_loop = 0;
        m_new_accept_ptr = 0;
    }

public:
    void start_loop(std::string ip, int port, int thrds);
    void stop_loop();

public:
    uvw_new_accept_ptr m_new_accept_ptr;
    uvw_new_accept_ptr get_accept_ptr() { return m_new_accept_ptr; }
    void set_accept_ptr(uvw_new_accept_ptr acc_ptr) {
        m_new_accept_ptr = acc_ptr;
    }

private:
    uvw_loop *m_svr_loop;
};




#endif
