#include "uvw_gw_aisle_lists.h"


void uvw_gw_aisle_instance_lists::push_item(st64 link_id, type_gw_aisle_ptr inst_ptr)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    m_inst_lists[link_id] = inst_ptr;
}

void uvw_gw_aisle_instance_lists::erase_item(st64 link_id)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.find(link_id);
    if(iter != m_inst_lists.end())
        m_inst_lists.erase(iter);
}

void uvw_gw_aisle_instance_lists::erase_all()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    m_inst_lists.clear();
}

bool uvw_gw_aisle_instance_lists::has_aisle_id(st64 link_id)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.find(link_id);
    if(iter != m_inst_lists.end())
        return true;

    return false;
}

void uvw_gw_aisle_instance_lists::tell_aisle_will_close()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.begin();
    while(iter != m_inst_lists.end())
    {
        type_gw_aisle_ptr gw_ptr = iter->second;
        if(gw_ptr)
        {
            gw_ptr->will_close();
        }
        iter++;
    }
}

void uvw_gw_aisle_instance_lists::take_free_aisle(type_gw_aisle_ptr_lists &as_lists)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.begin();
    while(iter != m_inst_lists.end())
    {
        bool bplus = true;
        type_gw_aisle_ptr gw_ptr = iter->second;
        if(gw_ptr)
        {
            if(gw_ptr->is_can_free())
            {
				//注意 iter 的使用顺序!!!
                bplus = false;
                as_lists[iter->first] = gw_ptr;
                iter = m_inst_lists.erase(iter);
            }
        }

        if(bplus)
            iter++;
    }
}

void uvw_gw_aisle_instance_lists::take_free_aisle(std::vector<st64> &as_lists)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.begin();
    while(iter != m_inst_lists.end())
    {
        bool bplus = true;
        type_gw_aisle_ptr gw_ptr = iter->second;
        if(gw_ptr)
        {
            if(gw_ptr->is_can_free())
            {
				//注意 iter 的使用顺序!!!
                bplus = false;
                as_lists.push_back(iter->first);
                iter = m_inst_lists.erase(iter);
            }
        }

        if(bplus)
            iter++;
    }
}

void uvw_gw_aisle_instance_lists::get_cache_data(comm_buffer_lists &wlists)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.begin();
    for(; iter != m_inst_lists.end(); iter++)
    {
        type_gw_aisle_ptr gw_ptr = iter->second;
        if(gw_ptr)
        {
            uvw_buffer_ptr ptr = gw_ptr->take_header();
            if(ptr)
            {
                wlists[iter->first] = ptr;
            }
        }
    }
}

void uvw_gw_aisle_instance_lists::add_out_data(const char *data, int size)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.begin();
    for(; iter != m_inst_lists.end(); iter++)
    {
        type_gw_aisle_ptr gw_ptr = iter->second;
        if(gw_ptr)
        {
            gw_ptr->add_out_data(data, size);
        }
    }
}

int uvw_gw_aisle_instance_lists::size()
{
    std::lock_guard<std::mutex> lk(m_mutex);
    return (int)m_inst_lists.size();
}

type_gw_aisle_ptr uvw_gw_aisle_instance_lists::get_item(st64 link_id)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.find(link_id);
    if(iter != m_inst_lists.end())
        return iter->second;

    return 0;
}

type_gw_aisle_ptr uvw_gw_aisle_instance_lists::take_item(st64 link_id)
{
    std::lock_guard<std::mutex> lk(m_mutex);
    type_gw_aisle_ptr_lists::iterator iter = m_inst_lists.find(link_id);
    if(iter != m_inst_lists.end())
    {
        type_gw_aisle_ptr gw_ptr = iter->second;
        m_inst_lists.erase(iter);
        return gw_ptr;
    }

    return 0;
}
