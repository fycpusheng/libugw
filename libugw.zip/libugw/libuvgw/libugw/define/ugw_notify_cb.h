#ifndef UGW_NOTIFY_CB_H
#define UGW_NOTIFY_CB_H


//采用读取单包读取的方式; 支持较大的数据包??
#define ENABLE_GW_LARGE_PACKAGE_WAY
#ifdef  ENABLE_GW_LARGE_PACKAGE_WAY
#include "ugw_notify_cb_malloc.h"
#else
#include "ugw_notify_cb_fix_block.h"
#endif

#endif
