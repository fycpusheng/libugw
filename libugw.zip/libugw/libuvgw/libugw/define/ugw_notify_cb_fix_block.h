#ifndef UGW_NOTIFY_CB_FIX_BLOCK_H
#define UGW_NOTIFY_CB_FIX_BLOCK_H

#include "uvw_notify_cb.h"
#include "uvw_gw_data.h"
#include "dbg/uvw_tmp_log.h"
#include "uvw_tools.h"
#include <vector>
#include <memory>


/* **************************************************************** **
 * GW_Data::cts_gw_data 中的 data 数据是附在结构尾的, 指向的是真实的业务数据;;
 * data 放在尾部的原因是网关服务器转发的任何数据需要包装成顺序 来发送,
 * 若 data 变成指针, 无法直接发送, 必须重新分配一个大的内存来拷贝 并执行发送;
 * 所以此处不能用指针来处理业务数据的指向!!!
 * ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
 * 当然, 这使 接收者 无法直接拥有 data 中的数据, 只能访问或拷贝, 不能占用此内存!!
 * **************************************************************** **/

#define  UVW_READ_BUFFER_MAX_LEN  1024*1024*2

class ugw_notify_cb_base : public uvw_notify_cb
{
public:
    ugw_notify_cb_base() {
       m_had_bytes  = 0;
       m_buffer_ptr = new char[UVW_READ_BUFFER_MAX_LEN];
    }

    virtual ~ugw_notify_cb_base() {
        if(m_buffer_ptr)
        {
            delete m_buffer_ptr;
            m_buffer_ptr = 0;
        }
    }

public:
    virtual void prepare_buffer(cb_buffer &buffer)
    {
        if(m_had_bytes>0)
        {
            buffer.buf_size = UVW_READ_BUFFER_MAX_LEN - m_had_bytes;
            buffer.buf_pos = m_buffer_ptr + m_had_bytes;
        }
        else
        {
            buffer.buf_size = UVW_READ_BUFFER_MAX_LEN;
            buffer.buf_pos = m_buffer_ptr;
        }
    }

    virtual void on_read_data(const char *data, int bytes) = 0;
    virtual void write_finished(int status) {
    }

public:
    //m_had_bytes: 已读取字节数;
    int   m_had_bytes;
    char *m_buffer_ptr;
};



class ugw_notify_cb : public ugw_notify_cb_base
{
public:
    ugw_notify_cb() {
    }
	
    virtual ~ugw_notify_cb() {
    }

public:
    ut32 get_wrap_size(char* data)
    {
        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
        ut32 wr_size = wrapper->size;

        // 调整头部大小的字节序列!!!
        bool is_big_endian = (wrapper->big_endian != 0);
        bool is_same_order = (is_big_endian == uvw_tools::is_big_endian());
        if(!is_same_order) {
            wr_size = uvw_share::swap_big_little<ut32>(wr_size);
        }

        return wr_size;
    }

    bool is_same_byte_endian(char* data)
    {
        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;

        // 调整头部大小的字节序列!!!
        bool is_big_endian = (wrapper->big_endian != 0);
        bool is_same_orderx = (is_big_endian == uvw_tools::is_big_endian());
        return is_same_orderx;
    }

public:
    virtual void read_finished(const char *data, int size)
    {
        tmp_printf("gggggggggggw read buffer size: %d", size);
        if(m_had_bytes>0)
        {
            tmp_assert(size+m_had_bytes <= UVW_READ_BUFFER_MAX_LEN);
            data = m_buffer_ptr;
            size += m_had_bytes;
        }

        //最少需要读取到网关的头部才能正常解析数据!!
        if(size < sizeof(GW_Data::cts_gw_data))
        {
            m_had_bytes += size;
            return;
        }

        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
        ut32 wr_size = wrapper->size;

        // 调整头部大小的字节序列!!!
        bool is_big_endian = (wrapper->big_endian != 0);
        bool is_same_order = (is_big_endian == uvw_tools::is_big_endian());
        if(!is_same_order) {
            wr_size = uvw_share::swap_big_little<ut32>(wr_size);
        }

        if(wr_size <= size)
        {
            // ********************************** //
            // 字节序列处理!!!
            if(!is_same_order) {
                wrapper->swap_endian();
            }
            // ********************************** //
            // 心跳无需处理, 略过此块内存!!
            if(!is_break_heart(data))
                on_read_data(data, wrapper->size);

            GW_Data::cts_gw_data *wrapper2 = wrapper;
            while(true)
            {
                data += wrapper2->size;
                size -= wrapper2->size;

                if(size < sizeof(GW_Data::cts_gw_data))
                    break;
                else {
                    wrapper2 = (GW_Data::cts_gw_data*)data;

                    // 调整头部大小的字节序列!!!
                    ut32 wrr_size = wrapper2->size;
                    if(!is_same_order) {
                        wrr_size = uvw_share::swap_big_little<ut32>(wrr_size);
                    }

                    if(wrr_size <= size)
                    {
                        // ********************************** //
                        // 字节序列处理!!!
                        if(!is_same_order) {
                            wrapper->swap_endian();
                        }
                        // ********************************** //

                        if(!is_break_heart(data))
                            on_read_data(data, wrapper2->size);
                    }
                    else
                        break;
                }
            }

            //不对具体数据进行分析, 按固定大小来读取, 减小难度//
            if(size>0)
            {
                m_had_bytes = size;
                memcpy(m_buffer_ptr, data, size);
            }
            else
                m_had_bytes = 0;
        }
        else
        {
            //特殊情况:
            //一个数据包, 接收了多次才接收全!!!
            m_had_bytes += size;

            //note:
            //@1: 所有协议的数据包最大不能超过 UVW_READ_BUFFER_MAX_LEN//
            //@2: wrapper->size > size, 但小于 UVW_READ_BUFFER_MAX_LEN时, 继续读取//
        }
    }

    virtual void on_read_data(const char *data, int bytes) = 0;

public:
    bool is_break_heart(const char *data)
    {
        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
        return wrapper->is_ping();
    }

public:
    //m_had_bytes: 已读取字节数;
    int   m_had_bytes;
    char *m_buffer_ptr;
};


#if 0
class ugw_notify_cb2 : public ugw_notify_cb
{
public:
    ugw_notify_cb2() {
       m_large_buffer = 0;
    }

    virtual ~ugw_notify_cb2() {
        if(m_large_buffer)
        {
            delete m_large_buffer;
            m_large_buffer = 0;
        }
    }

public:
    virtual void prepare_buffer(cb_buffer &buffer)
    {
        if(m_had_bytes == UVW_READ_BUFFER_MAX_LEN)
        {
            if(m_large_buffer == 0) {
                m_large_size = get_wrap_size(m_buffer_ptr);
                m_large_buffer = new char[m_large_size];
            }

            memcpy(m_large_buffer, m_buffer_ptr, UVW_READ_BUFFER_MAX_LEN);

            buffer.buf_size = m_large_size - m_had_bytes;
            buffer.buf_pos = m_large_buffer + m_had_bytes;
            return;
        }
        else if(m_had_bytes > UVW_READ_BUFFER_MAX_LEN)
        {
            buffer.buf_size = m_large_size - m_had_bytes;
            buffer.buf_pos = m_large_buffer + m_had_bytes;
            return;
        }

        ugw_notify_cb::prepare_buffer(buffer);
    }

    virtual void read_finished(const char *data, int size)
    {
        if(m_large_buffer)
        {
            m_had_bytes += size;
            if(m_had_bytes == m_large_size)
            {
                GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)m_large_buffer;
                bool is_big_endian = (wrapper->big_endian != 0);
                if((is_big_endian == uvw_tools::is_big_endian()) == false) {
                    wrapper->swap_endian();
                }

                on_read_data(data, wrapper->size);

                m_had_bytes = 0;
                clear_large_buffer();
            }
            else if(m_had_bytes > m_large_size)
            {
                //不会出现;
                //上面的逻辑, 当出现大包时, 按大包的大小来读取, 不会超过此大小!!
                clear_large_buffer();
            }

            return;
        }

        ugw_notify_cb::read_finished(data, size);
    }

    void clear_large_buffer()
    {
        delete []m_large_buffer;

        m_large_size = 0;
        m_large_buffer = 0;
    }

public:
    //大内存时使用!!
    //m_large_size 当前包的大小!!
    int   m_large_size;
    char *m_large_buffer;
};
#endif

#endif
