﻿#ifndef LIBUVW_GW_DATA_H
#define LIBUVW_GW_DATA_H


#include <share_type_def.h>
#include "swap_big_little.h"
#include <string.h>



namespace GW_Data
{
/* ***************************************************************************************************
 * *************************************************************************************************** */

//login/logout cmd
#define  cmd_gw_data              0
#define  cmd_gw_ping              1
#define  cmd_gw_create_aisle      10
#define  cmd_gw_create_aisle_ack  11
#define  cmd_gw_delete_aisle      12
#define  cmd_gw_delete_aisle_ack  13

#pragma pack(8)

/* ***************************************************************************************************
 * *************************************************************************************************** */

//记得重设 size ..
//web data|data|body| ..
struct cts_gw_data
{
    ut32  big_endian;
    ut32  size;
    st64  link_id;
    ut32  gw_cmd;
    char  data[0];

    void swap_endian()
    {
        size    = GW_Data::swap_big_little<ut32>(size);
        link_id = GW_Data::swap_big_little<st64>(link_id);
        gw_cmd  = GW_Data::swap_big_little<ut32>(gw_cmd);
    }

    //网关数据头..
    char *web_header()
    {
        return (char*)this;
    }

    //真实数据位置..
    char *data_header()
    {
        return (char*)(data);
    }

    int data_size()
    {
        return size - sizeof(cts_gw_data);
    }

    // /////////////////////////////////////// //
    // /////////////////////////////////////// //
    // get way ping cmd..
    bool is_ping()
    {
        return gw_cmd == cmd_gw_ping;
    }

    void set_ping()
    {
        gw_cmd = cmd_gw_ping;
    }

    bool is_create_aisle()
    {
        return gw_cmd == cmd_gw_create_aisle;
    }

    bool is_create_aisle_ack()
    {
        return gw_cmd == cmd_gw_create_aisle_ack;
    }

    bool is_delete_aisle()
    {
        return gw_cmd == cmd_gw_delete_aisle;
    }

    bool is_delete_aisle_ack()
    {
        return gw_cmd == cmd_gw_delete_aisle_ack;
    }

    // /////////////////////////////////////// //
    // /////////////////////////////////////// //
    bool is_valid_link_id() {
        return link_id>0;
    }

    void set_link_id(st64 link_id)
    {
        this->link_id = link_id;
    }

    void set_data(char *data, int size)
    {
        this->size = sizeof(cts_gw_data) + size;
        memcpy(this->data, data, size);
    }

    // /////////////////////////////////////// //
    // /////////////////////////////////////// //
    static cts_gw_data* make_gw_data(st64 link_id, char *data, int dsize, bool is_big)
    {
        int size = sizeof(cts_gw_data) + dsize;
        cts_gw_data *wdata = (cts_gw_data*)(new char[size]);

        wdata->big_endian = is_big? 1: 0;
        wdata->size = size;
        wdata->gw_cmd = cmd_gw_data;
        wdata->link_id = link_id;
        memcpy(wdata->data, data, dsize);
        return wdata;
    }

    static cts_gw_data* make_gw_data(st64 link_id, ut32 cmd, char *data, int dsize, bool is_big)
    {
        int size = sizeof(cts_gw_data) + dsize;
        cts_gw_data *wdata = (cts_gw_data*)(new char[size]);

        wdata->big_endian = is_big? 1: 0;
        wdata->size = size;
        wdata->gw_cmd = cmd;
        wdata->link_id = link_id;
        memcpy(wdata->data, data, dsize);
        return wdata;
    }

    static cts_gw_data* make_gw_cmd(st64 link_id, ut32 cmd, bool is_big)
    {
        int size = sizeof(cts_gw_data);
        cts_gw_data *wdata = (cts_gw_data*)(new char[size]);

        wdata->big_endian = is_big? 1: 0;
        wdata->size = size;
        wdata->gw_cmd = cmd;
        wdata->link_id = link_id;
        return wdata;
    }

    static cts_gw_data* make_gw_ping(bool is_big)
    {
        return make_gw_cmd(0, cmd_gw_ping, is_big);
    }
};

typedef  struct cts_gw_data  stc_gw_data;

#pragma pack()
}

#endif
