#ifndef SWAP_BIG_LITTLE_H
#define SWAP_BIG_LITTLE_H


namespace GW_Data
{
    template<class dtype>
    dtype swap_big_little(dtype data)
    {
        dtype new_data;
        char *new_char = (char*)(&new_data);
        char *old_char = (char*)(&data);

        int end_flag = sizeof(dtype)-1;
        for(int i=0; i<=end_flag; i++)
        {
            new_char[end_flag-i] = old_char[i];
        }
        return new_data;
    }

    template<class dtype>
    void swap_big_little_ref(dtype &data)
    {
        data = swap_big_little(data);
    }
}


#endif
