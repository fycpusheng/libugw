#ifndef SHARE_TYPE_DEF_H
#define SHARE_TYPE_DEF_H


#if 0
/**** diffrent define  *****/
#define ut_int8    unsigned char
#define ut_int32   unsigned int
#define ut_int64   unsigned long long
#define st_int8    char
#define st_int32   int
#define st_int64   long long
#else
typedef unsigned char       ut_int8;
typedef unsigned int        ut_int32;
typedef unsigned long long  ut_int64;
typedef char                st_int8;
typedef int                 st_int32;
typedef long long           st_int64;
#endif


#define s64_t    st_int64
#define u64_t    ut_int64
#define s32_t    st_int32
#define u32_t    ut_int32

#define st64    s64_t
#define ut64    u64_t
#define st32    s32_t
#define ut32    u32_t


#endif
