#ifndef UGW_NOTIFY_CB_MALLOC_H
#define UGW_NOTIFY_CB_MALLOC_H

#include "uvw_notify_cb.h"
#include "uvw_gw_data.h"
#include "dbg/uvw_tmp_log.h"
#include "uvw_tools.h"
#include <vector>
#include <memory>



#define  UVW_READ_BUFFER_MAX_LEN  250*1024

class ugw_notify_cb_base : public uvw_notify_cb
{
public:
    ugw_notify_cb_base()
    {
        m_header_size = 0;
        m_total_size = 0;
        m_had_bytes  = 0;
        m_buffer_ptr = new char[UVW_READ_BUFFER_MAX_LEN];
    }

    virtual ~ugw_notify_cb_base()
    {
        if(m_buffer_ptr)
        {
            delete m_buffer_ptr;
            m_buffer_ptr = 0;
        }
    }

public:
    virtual void prepare_buffer(cb_buffer &buffer)
    {
        buffer.buf_pos = next_buffer(buffer.buf_size);
    }

    //解析出包数据后, 交给 on_read_data 处理!!
    virtual void on_read_data(const char *data, int bytes) = 0;
    virtual void write_finished(int status) {
    }

public:
    char* next_buffer(int &next_size)
    {
        //不指定协议头只能使用固定大小的读取方式!!
        if(m_header_size <= 0)
        {
            next_size = UVW_READ_BUFFER_MAX_LEN - m_had_bytes;
            return  m_buffer_ptr + m_had_bytes;
        }

        //先读取头部大小;
        //读完后解析出包的总大小, 赋值给m_total_size!!
        char* next_ptr = 0;
        if(m_had_bytes < m_header_size)
        {
            next_size = m_header_size - m_had_bytes;
            next_ptr  = m_buffer_ptr + m_had_bytes;
        }
        else
        {
            //再读取内容大小; 若内容大于固定内存, 则分配大内存!!
            if(m_total_size > UVW_READ_BUFFER_MAX_LEN)
            {
                alloc_large();
                next_size = m_total_size - m_had_bytes;
                next_ptr = m_large_buffer + m_had_bytes;
            }
            else {
                next_size = m_total_size - m_had_bytes;
                next_ptr = m_buffer_ptr + m_had_bytes;
            }
        }

        return next_ptr;
    }

    void alloc_large()
    {
        if(m_large_buffer == 0) {
            m_large_buffer = new char[m_total_size];
            memcpy(m_large_buffer, m_buffer_ptr, m_header_size);
        }
    }

    void free_large()
    {
        if(m_large_buffer)
        {
            delete []m_large_buffer;
            m_large_buffer = 0;
        }
    }

public:
    char *m_buffer_ptr;
    char *m_large_buffer;

    //m_header_size: 需要读取的头部大小!!
    //m_had_bytes:   已读取字节数;
    //m_total_size:  包的大小!!
    int   m_header_size;
    int   m_had_bytes;
    int   m_total_size;
};

class ugw_notify_cb : public ugw_notify_cb_base
{
public:
    ugw_notify_cb() {
        m_header_size = sizeof(GW_Data::cts_gw_data);
    }

public:
    virtual void read_finished(const char *data, int size)
    {
        m_had_bytes += size;

        //最少需要读取到网关的头部才能正常解析数据!!
        if(m_had_bytes < m_header_size)
        {
            return;
        }

        if(m_had_bytes == m_header_size)
        {
            char* header_ptr = m_buffer_ptr;

            //获取要读取包的总大小; 及包的字节序与当前主机是否相同!!
            ut32 wr_size = 0;
            bool is_same_order = true;
            get_wrap_size(header_ptr, wr_size, is_same_order);

            //是一个仅有网关数据的包??
            if(wr_size <= m_had_bytes)
            {
                // ********************************** //
                // 字节序列处理!!!
                GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)header_ptr;
                if(!is_same_order) {
                    wrapper->swap_endian();
                }

                // ********************************** //
                // 心跳无需处理, 略过此块内存!!
                if(!is_break_heart(header_ptr)) {
                    on_read_data(header_ptr, wrapper->size);
                }

                //wr_size == m_had_bytes == m_header_size
                m_had_bytes -= wr_size;
                return;
            }

            m_total_size = wr_size;

            //需要分配大内存??!
            if(m_total_size > UVW_READ_BUFFER_MAX_LEN)
                alloc_large();
        }
        else
        {
            //m_had_bytes == m_total_size, only!
            //m_had_bytes 只会等于 m_total_size; 不会大于!!
            if(m_had_bytes >= m_total_size)
            {
                //头部大小会先读取到 m_buffer_ptr; 故可以从中解析头部数据!!
                ut32 wr_size = 0;
                bool is_same_order = true;
                get_wrap_size(m_buffer_ptr, wr_size, is_same_order);

                char* header_ptr = 0;
                if(m_total_size > UVW_READ_BUFFER_MAX_LEN)
                {
                    header_ptr = m_large_buffer;
                }
                else {
                    header_ptr = m_buffer_ptr;
                }

                GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)header_ptr;
                if(!is_same_order) {
                    wrapper->swap_endian();
                }

                on_read_data(header_ptr, wrapper->size);
                free_large();

                m_had_bytes -= m_total_size;
            }
        }
    }

public:
    void get_wrap_size(char* data, ut32& wr_size, bool& is_same_order)
    {
        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;

        // 调整头部大小的字节序列!!!
        bool is_big_endian = (wrapper->big_endian != 0);
        is_same_order = (is_big_endian == uvw_tools::is_big_endian());
        if(is_same_order)
            wr_size = wrapper->size;
        else {
            wr_size = uvw_share::swap_big_little<ut32>(wr_size);
        }
    }

    bool is_break_heart(const char *data)
    {
        GW_Data::cts_gw_data *wrapper = (GW_Data::cts_gw_data*)data;
        return wrapper->is_ping();
    }
};

#endif
